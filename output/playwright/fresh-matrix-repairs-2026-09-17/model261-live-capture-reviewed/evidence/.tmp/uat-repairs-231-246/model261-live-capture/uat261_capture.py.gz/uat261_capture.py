"""One-shot UAT261 request-boundary observer.

This diagnostic module is loaded outside product source.  Its factory returns
the existing FastAPI application after temporarily replacing the exact
``complete-v2`` provider seam.  It is intentionally not a logging feature.
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import os
import stat
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any

_CAPTURE_LIMIT = 2
_RECORDS_NAME = "uat261_capture.json"
_STATUS_NAME = "uat261_capture_status.json"
_FINISH_REASONS = {"stop", "length", "tool_calls", "content_filter", "function_call"}
_MESSAGE_ROLES = {"system", "developer", "user", "assistant", "tool", "function"}


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="surrogatepass")).hexdigest()


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def _settings_fingerprint(kwargs: Mapping[str, Any]) -> str:
    """Digest only documented non-secret complete-v2 dispatch controls."""
    fields = {
        "provider": kwargs.get("api_endpoint"),
        "model": kwargs.get("model"),
        "temperature": kwargs.get("temp"),
        "top_p": kwargs.get("top_p"),
        "repetition_penalty": kwargs.get("repetition_penalty"),
        "stop": kwargs.get("stop"),
        "max_tokens": kwargs.get("max_tokens"),
        "stream": kwargs.get("streaming"),
        "tools_hash": _sha256(_canonical(kwargs.get("tools"))),
        "tool_choice_hash": _sha256(_canonical(kwargs.get("tool_choice"))),
        "billing_prompt_cache_intent_hash": _sha256(
            _canonical(kwargs.get("billing_prompt_cache_intent"))
        ),
        "inference_prefix_cache_intent_hash": _sha256(
            _canonical(kwargs.get("inference_prefix_cache_intent"))
        ),
    }
    return f"sha256:{_sha256(_canonical(fields))}"


def _message_role_counts(messages: list[dict[str, Any]]) -> dict[str, int]:
    """Count only known role labels; do not retain arbitrary message values."""
    counts: dict[str, int] = {}
    for message in messages:
        role = message.get("role")
        label = role if isinstance(role, str) and role in _MESSAGE_ROLES else "other"
        counts[label] = counts.get(label, 0) + 1
    return counts


def _validated_capture_dir(value: str | None) -> Path:
    """Reject non-private or non-fresh output locations before app startup."""
    if not value:
        raise ValueError("UAT261_CAPTURE_DIR is required")
    supplied = Path(value)
    if not supplied.is_absolute() or supplied.is_symlink():
        raise ValueError("UAT261_CAPTURE_DIR must be an absolute non-symlink directory")
    try:
        capture_dir = supplied.resolve(strict=True)
        mode = stat.S_IMODE(capture_dir.stat().st_mode)
    except OSError as exc:
        raise ValueError("UAT261_CAPTURE_DIR is unavailable") from exc
    if not capture_dir.is_dir() or mode != 0o700:
        raise ValueError("UAT261_CAPTURE_DIR must be a mode-0700 directory")
    for filename in (_RECORDS_NAME, _STATUS_NAME):
        candidate = capture_dir / filename
        if candidate.exists() or candidate.is_symlink():
            raise ValueError("UAT261 capture outputs must be fresh")
    return capture_dir


def _write_new_json(path: Path, payload: Mapping[str, Any]) -> None:
    """Create a diagnostic artifact without overwriting a pre-existing file."""
    with path.open("x", encoding="utf-8") as handle:
        json.dump(payload, handle, sort_keys=True, indent=2)
        handle.write("\n")
    path.chmod(0o600)


def _write_owned_json(path: Path, payload: Mapping[str, Any]) -> None:
    """Update only the regular artifact this observer created."""
    details = path.lstat()
    if not stat.S_ISREG(details.st_mode) or details.st_nlink != 1:
        raise OSError("capture artifact is no longer a regular owned file")
    path.write_text(json.dumps(payload, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def _terminal_from_payload(payload: Mapping[str, Any]) -> dict[str, Any] | None:
    choices = payload.get("choices")
    choice = choices[0] if isinstance(choices, list) and choices else None
    if not isinstance(choice, Mapping):
        return None
    finish_reason = choice.get("finish_reason")
    if not isinstance(finish_reason, str) or finish_reason not in _FINISH_REASONS:
        return None
    usage = payload.get("usage")
    allowed_usage = ("prompt_tokens", "completion_tokens", "total_tokens")
    safe_usage = (
        {key: int(usage[key]) for key in allowed_usage}
        if isinstance(usage, Mapping)
        and all(isinstance(usage.get(key), int) for key in allowed_usage)
        else None
    )
    fingerprint = payload.get("system_fingerprint")
    return {
        "finish_reason": finish_reason,
        "usage": safe_usage,
        "system_fingerprint_hash": (
            f"sha256:{_sha256(fingerprint)}" if isinstance(fingerprint, str) else None
        ),
    }


class _ObservedSyncIterator:
    """Forward a synchronous provider iterator and expose its original close."""

    def __init__(self, observer: Any, source: Any, record: dict[str, Any]) -> None:
        self._observer = observer
        self._source = source
        self._iterator: Any | None = None
        self._record = record
        self._closed = False

    def __iter__(self) -> _ObservedSyncIterator:
        if self._iterator is None:
            self._iterator = iter(self._source)
        return self

    def __next__(self) -> Any:
        try:
            if self._iterator is None:
                self.__iter__()
            frame = next(self._iterator)
        except StopIteration:
            self._observer._complete_stream(self._record)
            raise
        except asyncio.CancelledError:
            self._record["capture_state"] = "cancelled"
            self._observer._persist_safely()
            raise
        except BaseException:
            self._record["capture_state"] = "incomplete"
            self._observer._persist_safely()
            raise
        self._observer._observe_frame(self._record, frame)
        return frame

    def close(self) -> None:
        """Close original source/iterator even if this wrapper was never started."""
        if self._closed:
            return
        self._closed = True
        first_error: BaseException | None = None
        seen: set[int] = set()
        try:
            for candidate in (self._iterator, self._source):
                if candidate is None or id(candidate) in seen:
                    continue
                seen.add(id(candidate))
                closer = getattr(candidate, "close", None)
                if not callable(closer):
                    continue
                try:
                    closer()
                except BaseException as exc:  # noqa: BLE001 - close both product-owned resources.
                    if first_error is None:
                        first_error = exc
        finally:
            self._observer._complete_stream(self._record)
        if first_error is not None:
            raise first_error


class _ObservedAsyncIterator:
    """Forward an asynchronous provider iterator and expose its original close."""

    def __init__(self, observer: Any, source: Any, record: dict[str, Any]) -> None:
        self._observer = observer
        self._source = source
        self._iterator: Any | None = None
        self._record = record
        self._closed = False

    def __aiter__(self) -> _ObservedAsyncIterator:
        if self._iterator is None:
            self._iterator = self._source.__aiter__()
        return self

    async def __anext__(self) -> Any:
        try:
            if self._iterator is None:
                self.__aiter__()
            frame = await self._iterator.__anext__()
        except StopAsyncIteration:
            self._observer._complete_stream(self._record)
            raise
        except asyncio.CancelledError:
            self._record["capture_state"] = "cancelled"
            self._observer._persist_safely()
            raise
        except BaseException:
            self._record["capture_state"] = "incomplete"
            self._observer._persist_safely()
            raise
        self._observer._observe_frame(self._record, frame)
        return frame

    async def aclose(self) -> None:
        """Await original cleanup even when the provider iterator never started."""
        if self._closed:
            return
        self._closed = True
        first_error: BaseException | None = None
        seen: set[int] = set()
        try:
            for candidate in (self._iterator, self._source):
                if candidate is None or id(candidate) in seen:
                    continue
                seen.add(id(candidate))
                closer = getattr(candidate, "aclose", None)
                if not callable(closer):
                    closer = getattr(candidate, "close", None)
                if not callable(closer):
                    continue
                try:
                    result = closer()
                    if inspect.isawaitable(result):
                        await result
                except BaseException as exc:  # noqa: BLE001 - close both product-owned resources.
                    if first_error is None:
                        first_error = exc
        finally:
            self._observer._complete_stream(self._record)
        if first_error is not None:
            raise first_error


class OneShotCapture:
    """Passively project no more than two provider seam invocations."""

    def __init__(
        self,
        *,
        sessions_module: Any,
        capture_dir: Path,
        envelope_builder: Callable[[list[dict[str, Any]]], Any],
    ) -> None:
        self._sessions_module = sessions_module
        self._original = sessions_module.perform_chat_api_call
        self._envelope_builder = envelope_builder
        self._records_path = capture_dir / _RECORDS_NAME
        self._status_path = capture_dir / _STATUS_NAME
        self._records: list[dict[str, Any]] = []
        self._closed = False
        self._persistence_available = True
        _write_new_json(self._records_path, self._evidence())
        _write_new_json(self._status_path, self._status())
        sessions_module.perform_chat_api_call = self._delegate

    def _evidence(self) -> dict[str, Any]:
        return {
            "capture_version": "uat261-live-boundary-v1",
            "diagnostic_type": "instrumented_request_boundary",
            "records": self._records,
        }

    def _status(self) -> dict[str, Any]:
        return {
            "capture_version": "uat261-live-boundary-v1",
            "diagnostic_type": "instrumented_request_boundary",
            "capture_limit": _CAPTURE_LIMIT,
            "captured_calls": len(self._records),
            "binding_restored": self._closed,
            "persistence_available": self._persistence_available,
        }

    def _persist_safely(self) -> None:
        """Never let evidence I/O change a provider call, stream, or exception."""
        if not self._persistence_available:
            return
        try:
            _write_owned_json(self._records_path, self._evidence())
            _write_owned_json(self._status_path, self._status())
        except OSError:
            self._persistence_available = False

    def _record_for(self, kwargs: Mapping[str, Any]) -> dict[str, Any]:
        record: dict[str, Any] = {
            "request_label": "A" if len(self._records) == 0 else "B",
            "capture_state": "pending",
            "input_projection_state": "complete",
            "stream_observation_state": "complete",
            "message_fingerprint_version": None,
            "message_fingerprint": None,
            "message_count": None,
            "message_role_counts": None,
            "generation_settings_fingerprint": None,
            "terminal": {
                "finish_reason": None,
                "usage": None,
                "system_fingerprint_hash": None,
            },
            # A passive stream observer cannot distinguish final content from
            # reasoning or think-tag chunks, so it must not claim an answer.
            "final_answer": None,
        }
        try:
            messages = kwargs.get("messages_payload")
            if not isinstance(messages, list):
                raise TypeError("messages payload unavailable")
            envelope = self._envelope_builder(messages)
            record.update(
                {
                    "message_fingerprint_version": str(envelope.fingerprint_version),
                    "message_fingerprint": str(envelope.aggregate_fingerprint),
                    "message_count": int(envelope.message_count),
                    "message_role_counts": _message_role_counts(messages),
                    "generation_settings_fingerprint": _settings_fingerprint(kwargs),
                }
            )
        except (AttributeError, KeyError, TypeError, ValueError, OverflowError):
            # Observer failure is diagnostic-only and intentionally opaque.
            record["capture_state"] = "incomplete"
            record["input_projection_state"] = "incomplete"
        return record

    def _observe_frame(self, record: dict[str, Any], frame: Any) -> None:
        """Read only terminal JSON fields; malformed frames remain untouched."""
        try:
            if not isinstance(frame, str):
                return
            for line in frame.splitlines():
                if not line.strip().lower().startswith("data:"):
                    continue
                text = line.partition(":")[2].strip()
                if not text or text.lower() == "[done]":
                    continue
                payload = json.loads(text)
                if isinstance(payload, Mapping):
                    terminal = _terminal_from_payload(payload)
                    if terminal is not None:
                        record["terminal"] = terminal
                        record["capture_state"] = "terminal_observed"
        except (AttributeError, KeyError, TypeError, ValueError, OverflowError):
            record["capture_state"] = "incomplete"
            record["stream_observation_state"] = "incomplete"

    def _complete_stream(self, record: dict[str, Any]) -> None:
        if record["capture_state"] == "pending":
            record["capture_state"] = "incomplete"
        self._persist_safely()

    def _delegate(self, *args: Any, **kwargs: Any) -> Any:
        """Call the original exactly once and wrap only lazy provider streams."""
        if args or len(self._records) >= _CAPTURE_LIMIT:
            return self._original(*args, **kwargs)
        record = self._record_for(kwargs)
        self._records.append(record)
        try:
            result = self._original(**kwargs)
        except asyncio.CancelledError:
            record["capture_state"] = "cancelled"
            self._persist_safely()
            self._restore_if_full()
            raise
        except BaseException:
            record["capture_state"] = "incomplete"
            self._persist_safely()
            self._restore_if_full()
            raise
        self._restore_if_full()
        if hasattr(result, "__aiter__"):
            return _ObservedAsyncIterator(self, result, record)
        if hasattr(result, "__iter__") and not isinstance(result, (str, bytes, bytearray, dict, list, tuple)):
            return _ObservedSyncIterator(self, result, record)
        if isinstance(result, Mapping):
            terminal = _terminal_from_payload(result)
            if terminal is not None:
                record["terminal"] = terminal
                record["capture_state"] = "terminal_observed"
        self._complete_stream(record)
        return result

    def _restore_if_full(self) -> None:
        if len(self._records) >= _CAPTURE_LIMIT:
            self.close()

    def close(self) -> None:
        """Restore the exact binding and write only an allowlisted final status."""
        if self._closed:
            return
        self._sessions_module.perform_chat_api_call = self._original
        self._closed = True
        for record in self._records:
            if record["capture_state"] == "pending":
                record["capture_state"] = "incomplete"
        self._persist_safely()


def install_capture(
    *, app: Any, sessions_module: Any, capture_dir: Path, envelope_builder: Callable[[list[dict[str, Any]]], Any]
) -> tuple[Any, OneShotCapture]:
    """Install the temporary observer and return the unchanged application object."""
    directory = _validated_capture_dir(str(capture_dir))
    observer = OneShotCapture(
        sessions_module=sessions_module,
        capture_dir=directory,
        envelope_builder=envelope_builder,
    )
    if hasattr(app, "add_event_handler"):
        app.add_event_handler("shutdown", observer.close)
    return app, observer


def create_app() -> Any:
    """Factory for the root-owned diagnostic launcher; no product source mutation."""
    capture_dir = _validated_capture_dir(os.environ.get("UAT261_CAPTURE_DIR"))
    from tldw_Server_API.app.main import app  # noqa: I001 - load the existing app before its seam.
    from tldw_Server_API.app.api.v1.endpoints import character_chat_sessions
    from tldw_Server_API.app.core.Chat.prompt_cost_envelope import build_prompt_cost_envelope

    observed_app, _observer = install_capture(
        app=app,
        sessions_module=character_chat_sessions,
        capture_dir=capture_dir,
        envelope_builder=build_prompt_cost_envelope,
    )
    return observed_app
