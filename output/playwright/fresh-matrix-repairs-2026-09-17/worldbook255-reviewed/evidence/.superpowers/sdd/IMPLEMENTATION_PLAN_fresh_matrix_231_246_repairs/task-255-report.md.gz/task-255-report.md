# UAT255 — PostgreSQL world-book creation and endpoint readback

**Backlog:** TASK13260.197  
**Baseline:** `6f6983b0620aae1f0892c6b0d3ae3bebfc105e02`  
**Status:** implementation and owned verification complete; parent retains independent review and native acceptance.

## Root cause

`WorldBookService.create_world_book()` opened `self.db.get_connection()` with a
`with` statement. SQLite connections support that protocol, while PostgreSQL
returns `BackendConnectionWrapper`, which does not. The endpoint then invokes
`get_world_book()` and `get_entries()` using the same unsupported pattern, so
repairing creation alone could not satisfy the endpoint's create/readback
contract. The direct cause matches the sanitized native extraction at
`.tmp/uat-repairs-231-246/native-targeted/pg-multi/worldbook255-error-cause-v2.json`.

## Change

- Use the supported `db.transaction()` boundary for the three methods on the
  actual `POST /world-books` path: create, created-book readback, and entry
  readback.
- Remove the direct commit from `create_world_book`; the transaction manager
  commits standalone work and preserves an outer caller's rollback ownership.
- Add backend-parameterized endpoint coverage for persisted metadata, flags,
  unique ID, empty entries, and `GET /world-books/{id}` readback. Add a
  rollback-ownership regression that uses a fresh service after the rollback so
  it observes persisted database state instead of the original service cache.

## Causal RED → GREEN

### RED

```sh
source .venv/bin/activate && \
TLDW_UAT_EVIDENCE_LABEL=worldbook255-red-20260917b \
node .tmp/fresh-uat-recovery-20260916/run-pg-tests-explicit-jobs.mjs \
tldw_Server_API/tests/DB_Management/test_character_world_book_reads_backends.py \
-q --tb=short
```

Exit `1`: 3 failed, 27 passed, 5 warnings. The PostgreSQL creation and
endpoint tests failed with `BackendConnectionWrapper does not support the
context manager protocol`; SQLite also proved that the direct create commit
prevented caller rollback. Sanitized output:
`.tmp/uat-repairs-231-246/worldbook255/red-official-postgres.log`.

### Final GREEN

```sh
source .venv/bin/activate && \
TLDW_UAT_EVIDENCE_LABEL=worldbook255-final-20260917b \
node .tmp/fresh-uat-recovery-20260916/run-pg-tests-explicit-jobs.mjs \
tldw_Server_API/tests/DB_Management/test_world_book_initialization_backends.py \
tldw_Server_API/tests/DB_Management/test_character_world_book_reads_backends.py \
-q --tb=short
```

Exit `0`: **36 passed, 5 warnings** in 39.36s, with no skips. This uses the
required runner and its official PostgreSQL fixture. Sanitized output:
`.tmp/uat-repairs-231-246/worldbook255/green-final-postgres.log`.

Focused GREEN before adjacent coverage: **30 passed, 5 warnings** in 30.86s;
sanitized output is `green-focused-postgres.log`. Adjacent pre-final coverage:
**36 passed, 5 warnings** in 37.86s; sanitized output is
`green-adjacent-postgres.log`.

## Static, compile, security, and self-review

| Check | Result |
| --- | --- |
| `python -m compileall -q <owned source> <owned test>` | Exit `0` |
| `git diff --check` | Exit `0` |
| `python -m ruff check <owned source> <owned test>` | Exit `1` only for the same three baseline manager findings: I001 at line 44 and SIM118 at lines 919 and 1441. The baseline run produced the same three findings. |
| `python -m bandit -r <owned source> <owned test> -f json ...` | Exit `1` because Bandit reports B101 for pytest `assert` statements. Baseline: 29 B101; current: 44 B101, with the difference coming from the new regression assertions. No non-B101 findings are present. |

Bandit comparison artifacts: `bandit-baseline.json` and `bandit-current.json`
under `.tmp/uat-repairs-231-246/worldbook255/`. A transient B105 false positive
from a literal request value was removed before final validation.

Self-review confirms the patch changes only the failing create/readback path,
does not alter schemas, RLS, roles, or endpoint contracts, and preserves the
existing duplicate conflict mapping and cache invalidation behavior.

## Final source hashes

- `tldw_Server_API/app/core/Character_Chat/world_book_manager.py`  
  `301fa7c0e6856f7489a20925aae99ade4bfac237469440b43c423bdce7e934cf`
- `tldw_Server_API/tests/DB_Management/test_character_world_book_reads_backends.py`  
  `fad8358c997e09fc7e81d3cd1e30c99ecbea504b407b8a747aa784382aa9d254`

## Concerns and handoff

- Other world-book CRUD methods still use the legacy connection-context
  pattern. They are outside this bounded UAT255 endpoint path and were not
  changed to avoid an unrelated CRUD rewrite; future native PostgreSQL coverage
  should assess them separately.
- Parent-owned independent review and original native Create/catalog/
  Character-editor readback acceptance remain required before closure.
- No commit, tracker, Backlog, browser, runtime, archive, or model-service
  files were changed by this task.

## Round 1 review repair

The round-1 review identified two gaps in the initial repair: the post-create
reads used a write transaction rather than the existing portable read-only
lifecycle, and the same service could cache a row read inside a caller-owned
transaction and return it after that caller rolled back.

### Change

- `get_world_book()` and `get_entries()` now call
  `CharactersRAGDB.execute_query(..., read_only=True)`, matching the local
  list/count read pattern. The database helper settles an owned idle PostgreSQL
  read while leaving an existing caller transaction untouched.
- A read result is cached only when the database indicates no active caller
  transaction. Standalone request caching remains enabled; reads inside a
  caller transaction are returned but cannot leave a phantom cache entry after
  rollback.
- The rollback regression now queries with the **same** `WorldBookService`
  after rollback, rather than constructing a new service.

### Causal evidence

```sh
source .venv/bin/activate && \
TLDW_UAT_EVIDENCE_LABEL=worldbook255-r1-red-20260917a \
node .tmp/fresh-uat-recovery-20260916/run-pg-tests-explicit-jobs.mjs \
tldw_Server_API/tests/DB_Management/test_character_world_book_reads_backends.py \
-q --tb=short
```

Exit `1`: **2 failed, 28 passed, 5 warnings**. Both SQLite and PostgreSQL
returned the rolled-back world book from the original service cache. Sanitized
output: `round1-red-same-service-cache.log`.

```sh
source .venv/bin/activate && \
TLDW_UAT_EVIDENCE_LABEL=worldbook255-r1-final-20260917a \
node .tmp/fresh-uat-recovery-20260916/run-pg-tests-explicit-jobs.mjs \
tldw_Server_API/tests/DB_Management/test_world_book_initialization_backends.py \
tldw_Server_API/tests/DB_Management/test_character_world_book_reads_backends.py \
-q --tb=short -r w
```

Exit `0`: **36 passed, 5 warnings, zero skips** in 38.30s. The focused
same-service-cache GREEN was **30 passed, 5 warnings** in 32.11s. Sanitized
outputs: `round1-green-focused.log` and `round1-green-final.log`.

### Warning classification

The normal configured final run's five warnings are pre-existing environment or
third-party warnings, not emitted by the owned source/test changes:

1. `StarletteDeprecationWarning` from FastAPI's `TestClient` import.
2. `PytestConfigWarning` for the pre-existing unsupported `plugins` config key.
3. Pydantic `UserWarning` for `CharacterExemplarLabels.register` shadowing a
   `BaseModel` attribute.
4. Passlib's Python `crypt` deprecation warning.
5. Pydantic `UserWarning` for `ResponseFormatJsonSchemaSpec.schema` shadowing
   a `BaseModel` attribute.

An official-run warning-classification pass with `-o addopts= -W default`
reported these five plus a sixth, normally filtered, Pydantic v2 class-based
configuration deprecation. It also passed all 36 tests. Sanitized output:
`round1-warning-classification.log`.

### Round-1 quality checks and hashes

- `python -m compileall -q <owned source> <owned test>`: exit `0`.
- `git diff --check`: exit `0`.
- Ruff: the same three pre-existing manager findings remain (I001 and two
  SIM118); no new lint finding was introduced.
- Bandit: baseline has 29 B101 test-assert findings; the current scope has 44
  B101 findings from the regression assertions and no non-B101 findings.
  `bandit-round1-current.json` retains the sanitized result.

Current owned source hashes:

- `world_book_manager.py`:
  `fbefcf2e2283b8a8ed26de6c0829e7104c53d187560713b0e833ac5e0bf90d5f`
- `test_character_world_book_reads_backends.py`:
  `fa9cb75e732d32f02a6ae210aa5e0a4b789a496624604d79abd65ea207163263`
