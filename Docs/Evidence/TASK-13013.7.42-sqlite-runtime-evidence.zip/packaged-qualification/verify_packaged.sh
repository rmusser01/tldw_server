#!/bin/sh
# Run the reviewed benign probe against files already present in each image.
set -eu
case "$1" in
  app) site_packages=/opt/tldw-venv/lib/python3.12/site-packages ;;
  worker|audio-worker) site_packages=/opt/tldw-venv/lib/python3.11/site-packages ;;
  *) exit 2 ;;
esac
case "$2" in sha256:????????????????????????????????????????????????????????????????) ;; *) exit 2 ;; esac
candidate_name=$1
candidate_subject=$2
artifact_dir=/private/tmp/task-13013-7-42-sqlite/packaged-qualification
docker image inspect "$candidate_subject" > "$artifact_dir/$candidate_name-image-inspect.json"
docker run --rm --pull never --platform linux/amd64 --name "tldw-task13013-7-42-$candidate_name-sqlite" --network none --cap-drop ALL --security-opt no-new-privileges:true --read-only --user 10001:10001 --cpus 1 --memory 512m --pids-limit 32 --no-healthcheck --tmpfs /tmp:rw,noexec,nosuid,size=64m --mount "type=bind,source=$artifact_dir/packaged_sqlite_probe.py,target=/packaged_sqlite_probe.py,readonly" --workdir /tmp --entrypoint /opt/tldw-venv/bin/python "$candidate_subject" -I -B /packaged_sqlite_probe.py "$site_packages" > "$artifact_dir/$candidate_name-packaged-sqlite.json" 2> "$artifact_dir/$candidate_name-packaged-sqlite.stderr"
if [ "$candidate_name" = app ]; then
  docker run --rm --pull never --platform linux/amd64 --name tldw-task13013-7-42-app-source-sqlite --network none --cap-drop ALL --security-opt no-new-privileges:true --read-only --user 10001:10001 --cpus 1 --memory 512m --pids-limit 32 --no-healthcheck --tmpfs /tmp:rw,noexec,nosuid,size=64m --mount "type=bind,source=$artifact_dir/packaged_sqlite_probe.py,target=/packaged_sqlite_probe.py,readonly" --workdir /tmp --entrypoint /opt/tldw-venv/bin/python "$candidate_subject" -I -B /packaged_sqlite_probe.py /app > "$artifact_dir/app-source-sqlite.json" 2> "$artifact_dir/app-source-sqlite.stderr"
fi
