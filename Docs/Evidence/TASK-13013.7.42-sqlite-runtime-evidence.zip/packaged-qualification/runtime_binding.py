"""Record the actual SQLite library mapped by isolated CPython."""

import hashlib
import json
import sqlite3
import sys
from pathlib import Path

paths = sorted(
    {line.split()[-1] for line in Path("/proc/self/maps").read_text().splitlines() if "/libsqlite3.so." in line}
)
if len(paths) != 1:
    raise RuntimeError(f"Expected one OS SQLite mapping, found {paths}")
with sqlite3.connect(":memory:") as connection:
    options = sorted(row[0] for row in connection.execute("PRAGMA compile_options"))
    source_id = connection.execute("SELECT sqlite_source_id()").fetchone()[0]
with Path(paths[0]).open("rb") as stream:
    digest = hashlib.file_digest(stream, "sha256").hexdigest()
if sys.argv[1:] not in ([], ["verify-amd64"]):
    raise ValueError("Expected no argument or verify-amd64")
if sys.argv[1:] == ["verify-amd64"]:
    if sqlite3.sqlite_version != "3.53.4":
        raise RuntimeError("Unexpected SQLite version")
    if digest != "666b2574049ed1db068b4a70837171d327c1696bf0498e6538913711c1a28370":
        raise RuntimeError("Unexpected SQLite native payload")
print(
    json.dumps(
        {
            "python_version": sys.version,
            "sqlite_version": sqlite3.sqlite_version,
            "sqlite_source_id": source_id,
            "compile_options": options,
            "mapped_library": paths[0],
            "mapped_library_sha256": digest,
        },
        indent=2,
    )
)
