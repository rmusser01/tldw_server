"""Create or restore one benign pre-upgrade SQLite database."""
import json
import sqlite3
import sys
import tempfile
from contextlib import closing
from pathlib import Path

path = Path('/legacy/source.db')
if sys.argv[1] == 'create':
    if path.exists():
        raise RuntimeError('Refusing to overwrite the legacy fixture')
    with closing(sqlite3.connect(path)) as source:
        source.executescript(
            'CREATE TABLE notes(id INTEGER PRIMARY KEY, body TEXT);'
            "INSERT INTO notes VALUES (1, 'legacy orchard');"
            'CREATE VIRTUAL TABLE search USING fts5(body);'
            'INSERT INTO search(rowid,body) SELECT id,body FROM notes;'
        )
    print(json.dumps({'created_with_sqlite': sqlite3.sqlite_version}))
elif sys.argv[1] == 'restore':
    with tempfile.TemporaryDirectory() as directory:
        with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as source:
            with closing(sqlite3.connect(Path(directory) / 'restored.db')) as target:
                source.backup(target, pages=256)
                rows = target.execute('SELECT body FROM search WHERE search MATCH ?', ('orchard',)).fetchall()
                if rows != [('legacy orchard',)]:
                    raise RuntimeError('Legacy backup restore changed the search result')
                print(json.dumps({'restored_with_sqlite': sqlite3.sqlite_version, 'rows': rows}))
else:
    raise ValueError('Expected create or restore')
