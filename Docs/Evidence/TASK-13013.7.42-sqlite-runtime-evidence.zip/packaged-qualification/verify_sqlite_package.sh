#!/bin/sh
# Verify the exact package, allowing only Debian slim's four excluded docs.
set -eu
dpkg-query -W libsqlite3-0 libc6
test "$(dpkg-query -W -f='${Version}' libsqlite3-0)" = 3.53.4-2
grep -Fx 'path-exclude /usr/share/doc/*' /etc/dpkg/dpkg.cfg.d/docker
grep -Fx 'path-include /usr/share/doc/*/copyright' /etc/dpkg/dpkg.cfg.d/docker
verification=$(dpkg --verify libsqlite3-0)
expected='missing     /usr/share/doc/libsqlite3-0/README.Debian
missing     /usr/share/doc/libsqlite3-0/changelog.Debian.gz
missing     /usr/share/doc/libsqlite3-0/changelog.gz
missing     /usr/share/doc/libsqlite3-0/changelog.html.gz'
printf '%s\n' "$verification"
test "$verification" = "$expected"
test ! -e /sqlite-packages
test ! -e /sqlite.deb
printf '%s\n' 'package verification complete'
