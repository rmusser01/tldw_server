#!/bin/sh
set -eu
candidate_name=$1
candidate_subject=$2
artifact_dir=/private/tmp/task-13013-7-42-sqlite/packaged-qualification
case "$candidate_name" in app|worker|audio-worker) ;; *) exit 2 ;; esac
/bin/sh "$artifact_dir/verify_packaged.sh" "$candidate_name" "$candidate_subject"
for check in verify_sqlite_runtime runtime_binding legacy_compatibility; do
    case "$check" in
        verify_sqlite_runtime) source_file="$artifact_dir/context/Dockerfiles/tests/verify_sqlite_runtime.py"; argument= ;;
        runtime_binding) source_file="$artifact_dir/runtime_binding.py"; argument=verify-amd64 ;;
        legacy_compatibility) source_file="$artifact_dir/legacy_compatibility.py"; argument=restore ;;
    esac
    docker run --rm --pull never --platform linux/amd64 --network none --read-only --user 10001:10001 --cap-drop ALL --security-opt no-new-privileges --no-healthcheck --cpus 1 --memory 512m --pids-limit 32 --tmpfs /tmp:rw,noexec,nosuid,size=32m --mount "type=bind,source=$source_file,target=/checks/check.py,readonly" --mount "type=bind,source=$artifact_dir/legacy,target=/legacy,readonly" --entrypoint /opt/tldw-venv/bin/python "$candidate_subject" -I -B /checks/check.py ${argument:+"$argument"} > "$artifact_dir/evidence/$candidate_name-$check.txt" 2> "$artifact_dir/evidence/$candidate_name-$check.stderr"
done
docker run --rm --pull never --platform linux/amd64 --network none --read-only --user 10001:10001 --cap-drop ALL --security-opt no-new-privileges --no-healthcheck --entrypoint /bin/sh "$candidate_subject" -ec 'dpkg-query -W libsqlite3-0 libc6; test "$(dpkg-query -W -f='"'"'${Version}'"'"' libsqlite3-0)" = 3.53.4-2; verification=$(dpkg --verify libsqlite3-0); test -z "$verification"; test ! -e /sqlite-packages' > "$artifact_dir/evidence/$candidate_name-package-verification.txt" 2> "$artifact_dir/evidence/$candidate_name-package-verification.stderr"
