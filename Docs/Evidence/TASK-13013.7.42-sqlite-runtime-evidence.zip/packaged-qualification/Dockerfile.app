FROM scratch AS fixed_package
ADD --checksum=sha256:bbf13c9326764d05e37e6590debdaa6f33af6bd822e3ca1204789d9d1dc23b11 https://deb.debian.org/debian/pool/main/s/sqlite3/libsqlite3-0_3.53.4-2_amd64.deb /sqlite.deb

FROM baseline
USER root
RUN --mount=type=bind,from=fixed_package,source=/sqlite.deb,target=/sqlite.deb \
    dpkg -i /sqlite.deb \
    && python -I -S -c "import sqlite3; assert sqlite3.sqlite_version_info == (3, 53, 4)"
USER appuser
LABEL org.tldw.qualification="TASK-13013.7.42 fixed SQLite on TASK41 packaged code; not a canonical rebuild"
