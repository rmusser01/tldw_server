"""Exercise the one-off verifier with tiny synthetic OCI descriptor controls."""

import hashlib
import importlib.util
import json
import tempfile
from pathlib import Path

BASE = Path(__file__).parent
spec = importlib.util.spec_from_file_location("verify_oci", BASE / "verify_oci_layout.py")
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
results = []
for variant in (
    "valid",
    "wrong-algorithm",
    "trailing-junk",
    "wrong-size",
    "missing-blob",
    "bad-hash",
    "extra-file",
    "symlink",
    "rootfs-count",
    "manifest-media-type",
    "runtime-attestation",
):
    with tempfile.TemporaryDirectory(prefix="oci-control-", dir=BASE) as tmp:
        root = Path(tmp)
        payloads = {}

        def add(data, payloads=payloads):
            raw = json.dumps(data).encode()
            digest = hashlib.sha256(raw).hexdigest()
            payloads["blobs/sha256/" + digest] = raw
            return {"digest": "sha256:" + digest, "size": len(raw)}

        layer = add({"fixture": "benign data"})
        layer["mediaType"] = "application/vnd.oci.image.layer.v1.tar"
        if variant == "runtime-attestation":
            layer["mediaType"] = "application/vnd.in-toto+json"
        if variant == "wrong-algorithm":
            layer["digest"] = layer["digest"].replace("sha256:", "sha512:")
        elif variant == "trailing-junk":
            layer["digest"] += ":junk"
        if variant == "wrong-size":
            layer["size"] += 1
        config = add(
            {
                "rootfs": {"type": "layers", "diff_ids": ["sha256:" + "a" * 64]},
                "architecture": "amd64",
                "os": "linux",
                "config": {"Labels": {"org.opencontainers.image.revision": verifier.REVISION}},
            }
        )
        config["mediaType"] = "application/vnd.oci.image.config.v1+json"
        manifest_type = "application/vnd.oci.image.manifest.v1+json"
        index_type = "application/vnd.oci.image.index.v1+json"
        manifest = add(
            {
                "schemaVersion": 2,
                "mediaType": manifest_type,
                "config": config,
                "layers": [] if variant == "rootfs-count" else [layer],
            }
        )
        manifest["mediaType"] = "invalid" if variant == "manifest-media-type" else manifest_type
        manifest["platform"] = {"architecture": "amd64", "os": "linux"}
        subject = add({"schemaVersion": 2, "mediaType": index_type, "manifests": [manifest]})
        subject["mediaType"] = index_type
        payloads["index.json"] = json.dumps(
            {"schemaVersion": 2, "mediaType": index_type, "manifests": [subject]}
        ).encode()
        payloads["oci-layout"] = b'{"imageLayoutVersion":"1.0.0"}'
        layout = root / "app-layout"
        for path, data in payloads.items():
            target = layout / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        layer_path = layout / "blobs/sha256" / layer["digest"].removeprefix("sha256:")
        if variant == "missing-blob":
            layer_path.unlink()
        elif variant == "bad-hash":
            layer_path.write_bytes(b"changed benign bytes")
        elif variant == "extra-file":
            (layout / "unexpected").write_text("benign")
        elif variant == "symlink":
            layer_path.unlink()
            layer_path.symlink_to(layout / "oci-layout")
        (root / "app-build-metadata.json").write_text(json.dumps({"containerimage.digest": subject["digest"]}))
        verifier.ROOT = root
        try:
            verifier.main("app")
            if variant != "valid":
                raise RuntimeError("Invalid descriptor was accepted: " + variant)
            results.append({"variant": variant, "outcome": "accepted"})
        except ValueError as error:
            if variant == "valid":
                raise
            results.append({"variant": variant, "outcome": "rejected", "error": str(error)})
(BASE / "evidence/oci-layout-controls.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results))
