"""Verify task-owned OCI directories without executing image contents."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).parent
REVISION = "4c64af2c4612428408b749eb3b2fc304c83ee2f4"


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def main(name: str) -> None:
    require(name in {"app", "worker", "audio-worker"}, "Unexpected image")
    layout = ROOT / f"{name}-layout"
    require(layout.is_dir() and not layout.is_symlink(), "Missing OCI directory")
    inventory = {}
    for target in sorted(layout.rglob("*")):
        relative = target.relative_to(layout).as_posix()
        require(not target.is_symlink(), "Unexpected OCI symlink")
        if target.is_dir():
            require(relative in {"blobs", "blobs/sha256"}, "Unexpected OCI directory")
            continue
        require(target.is_file(), "Unexpected OCI entry type")
        require(
            relative in {"index.json", "oci-layout"} or bool(re.fullmatch(r"blobs/sha256/[a-f0-9]{64}", relative)),
            "Unexpected OCI path",
        )
        actual = sha256(target)
        if relative.startswith("blobs/"):
            require(actual == target.name, "OCI blob hash mismatch")
        inventory[relative] = {"sha256": actual, "bytes": target.stat().st_size}
    require(
        json.loads((layout / "oci-layout").read_text()) == {"imageLayoutVersion": "1.0.0"},
        "Unexpected OCI layout",
    )

    def blob(descriptor: dict) -> dict:
        value = descriptor["digest"]
        require(bool(re.fullmatch(r"sha256:[a-f0-9]{64}", value)), "Invalid digest")
        path = layout / "blobs" / "sha256" / value.split(":")[1]
        require(path.stat().st_size == descriptor["size"], "Descriptor size mismatch")
        return json.loads(path.read_text())

    index_type = "application/vnd.oci.image.index.v1+json"
    manifest_type = "application/vnd.oci.image.manifest.v1+json"
    config_type = "application/vnd.oci.image.config.v1+json"
    layer_types = {
        "application/vnd.oci.image.layer.v1.tar",
        "application/vnd.oci.image.layer.v1.tar+gzip",
        "application/vnd.oci.image.layer.v1.tar+zstd",
    }
    index = json.loads((layout / "index.json").read_text())
    require(index.get("schemaVersion") == 2 and index.get("mediaType") == index_type, "Invalid OCI index header")
    require(len(index["manifests"]) == 1, "Expected one subject")
    subject_descriptor = index["manifests"][0]
    require(subject_descriptor.get("mediaType") == index_type, "Invalid subject media type")
    subject = blob(subject_descriptor)
    require(subject.get("schemaVersion") == 2 and subject.get("mediaType") == index_type, "Invalid subject header")
    metadata = json.loads((ROOT / f"{name}-build-metadata.json").read_text())
    require(
        subject_descriptor["digest"] == metadata["containerimage.digest"],
        "Build subject mismatch",
    )
    manifests = [
        item for item in subject["manifests"] if item.get("platform") == {"architecture": "amd64", "os": "linux"}
    ]
    require(len(manifests) == 1, "Expected one linux/amd64 image")
    manifest_descriptor = manifests[0]
    manifest = blob(manifest_descriptor)
    config = blob(manifest["config"])
    require(
        config["architecture"] == "amd64" and config["os"] == "linux",
        "Config platform mismatch",
    )
    require(
        config["config"]["Labels"]["org.opencontainers.image.revision"] == REVISION,
        "Source label mismatch",
    )
    for item in subject["manifests"]:
        require(item.get("mediaType") == manifest_type, "Invalid manifest descriptor media type")
        child = blob(item)
        require(child.get("schemaVersion") == 2 and child.get("mediaType") == manifest_type, "Invalid manifest header")
        require(child["config"].get("mediaType") == config_type, "Invalid config media type")
        child_config = blob(child["config"])
        rootfs = child_config.get("rootfs", {})
        require(rootfs.get("type") == "layers" and isinstance(rootfs.get("diff_ids"), list), "Invalid config rootfs")
        require(len(rootfs["diff_ids"]) == len(child["layers"]), "Rootfs layer count mismatch")
        require(
            all(isinstance(d, str) and re.fullmatch(r"sha256:[a-f0-9]{64}", d) for d in rootfs["diff_ids"]),
            "Invalid rootfs diff ID",
        )
        if item["digest"] == manifest_descriptor["digest"]:
            allowed_layer_types = layer_types
        else:
            annotations = item.get("annotations", {})
            require(
                annotations.get("vnd.docker.reference.type") == "attestation-manifest"
                and annotations.get("vnd.docker.reference.digest") == manifest_descriptor["digest"],
                "Unrecognized attestation manifest",
            )
            allowed_layer_types = {"application/vnd.in-toto+json"}
        for layer in child["layers"]:
            require(layer.get("mediaType") in allowed_layer_types, "Invalid layer media type")
            require(
                bool(re.fullmatch(r"sha256:[a-f0-9]{64}", layer["digest"])),
                "Invalid layer digest",
            )
            path = "blobs/sha256/" + layer["digest"].split(":")[1]
            require(
                path in inventory and inventory[path]["bytes"] == layer["size"],
                "Missing or truncated layer",
            )
    result = {
        "component": "image-" + name,
        "source_commit": REVISION,
        "subject_digest": subject_descriptor["digest"],
        "platform_manifest_digest": manifest_descriptor["digest"],
        "config_digest": manifest["config"]["digest"],
        "platform": "linux/amd64",
        "runtime_config": config["config"],
        "build_metadata_sha256": sha256(ROOT / f"{name}-build-metadata.json"),
        "verified_layout_members": inventory,
    }
    (ROOT / f"{name}-identity.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "component",
                    "subject_digest",
                    "platform_manifest_digest",
                    "config_digest",
                )
            }
        )
    )


if __name__ == "__main__":
    main(sys.argv[1])
