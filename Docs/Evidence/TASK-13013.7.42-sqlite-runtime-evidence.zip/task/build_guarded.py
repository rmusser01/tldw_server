"""Build one canonical candidate with a strict host-disk reserve."""

from __future__ import annotations

import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).parent
DOCKERFILES = {"app": "Dockerfile.prod", "worker": "Dockerfile.worker", "audio-worker": "Dockerfile.audio_gpu_worker"}
name, revision = sys.argv[1:]
if name not in DOCKERFILES or not re.fullmatch(r"[a-f0-9]{40}", revision):
    raise ValueError("Invalid component or source revision")
if shutil.disk_usage(ROOT).free < 8 * 1024**3:
    raise RuntimeError("At least 8 GiB free is required to start this guarded build")
command = [
    "docker",
    "buildx",
    "build",
    "--platform",
    "linux/amd64",
    "--provenance=mode=max",
    "--sbom=true",
    "--label",
    "org.opencontainers.image.revision=" + revision,
    "--metadata-file",
    str(ROOT / f"{name}-build-metadata.json"),
    "--output",
    f"type=oci,dest={ROOT}/{name}-layout,tar=false",
    "-f",
    str(ROOT / "context/Dockerfiles" / DOCKERFILES[name]),
    "-t",
    f"tldw-task13013-7-42-{name}:{revision[:10]}",
    str(ROOT / "context"),
]
record = {
    "command": command,
    "started_at": datetime.now(timezone.utc).isoformat(),
    "minimum_free_bytes": shutil.disk_usage(ROOT).free,
    "disk_reserve_abort": False,
}
with (ROOT / f"{name}-build.log").open("wb") as log:
    # The reviewed argument list invokes only Docker; no shell or user commands.
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    while process.poll() is None:
        free = shutil.disk_usage(ROOT).free
        record["minimum_free_bytes"] = min(record["minimum_free_bytes"], free)
        if free < 6 * 1024**3:
            record["disk_reserve_abort"] = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
            break
        time.sleep(0.5)
    record["exit_code"] = process.wait()
record["finished_at"] = datetime.now(timezone.utc).isoformat()
(ROOT / f"{name}-build-record.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
raise SystemExit(1 if record["disk_reserve_abort"] else record["exit_code"])
