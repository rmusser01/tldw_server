"""Retain bounded canonical TASK42 evidence and bind every archive member."""

import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).parent
REPO = Path("/Users/macbook-dev/Documents/GitHub/tldw_server2/.worktrees/task-13013-7-supply-chain-design")
STEM = "Docs/Evidence/TASK-13013.7.42-sqlite-runtime"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    archive = REPO / (STEM + "-evidence.zip")
    summary_path = REPO / (STEM + ".json")
    if not (ROOT / "retained-interim.zip").exists():
        shutil.copyfile(archive, ROOT / "retained-interim.zip")
        shutil.copyfile(summary_path, ROOT / "interim-summary.json")
    summary = json.loads((ROOT / "interim-summary.json").read_text())
    original = (ROOT / "retained-interim.zip").read_bytes()
    assert digest(original) == summary["evidence_archive"]["sha256"]
    with zipfile.ZipFile(ROOT / "retained-interim.zip") as z:
        members = {name: z.read(name) for name in z.namelist()}
    for name, data in members.items():
        record = summary["evidence_archive"]["members"][name]
        assert record == {"sha256": digest(data), "bytes": len(data)}
    for name in ("worker-build.log", "worker-build-record.json"):
        members["historical-interim/" + name] = members.pop("task/" + name)
    for path in (ROOT / "evidence").iterdir():
        if not path.is_file() or path.name.startswith(("cache-", "build-cache-", "build-history-inventory")):
            continue
        if path.name in {"task39-app-build-record.json", "final-retention-review.md"}:
            continue
        members["evidence/" + path.name] = path.read_bytes()
    for name in (
        "evaluate_candidates.py",
        "run_canonical_checks.py",
        "scan_candidate.sh",
        "verify_oci_layout.py",
        "create_final_evidence.py",
        "candidate-verification.json",
        "policy-after.json",
        "scanner/db/metadata.json",
        "legacy/source.db",
    ):
        members["task/" + name] = (ROOT / name).read_bytes()
    for name in ("app", "worker", "audio-worker"):
        for suffix in (
            "build.log",
            "build-record.json",
            "build-metadata.json",
            "identity.json",
            "load.log",
            "image-inspect.json",
            "checks-complete.json",
            "check-run.log",
            "packaged-sqlite.json",
            "packaged-sqlite.stderr",
            "decision.json",
            "scan-started.txt",
            "scan-finished.txt",
            "json-scan.log",
            "cyclonedx-scan.log",
        ):
            members["canonical/" + name + "-" + suffix] = (ROOT / (name + "-" + suffix)).read_bytes()
        for report in ("trivy-image-" + name + ".json", "sbom-image-" + name + ".cdx.json"):
            members["canonical/scan-output/" + report] = (ROOT / "scan-output" / report).read_bytes()
        layout = ROOT / (name + "-layout")
        selected = {"index.json", "oci-layout"}

        def metadata_blob(descriptor: dict, layout: Path = layout, selected: set[str] = selected) -> dict:
            key = "blobs/sha256/" + descriptor["digest"].removeprefix("sha256:")
            selected.add(key)
            return json.loads((layout / key).read_text())

        index = json.loads((layout / "index.json").read_text())
        subject = metadata_blob(index["manifests"][0])
        for descriptor in subject["manifests"]:
            manifest = metadata_blob(descriptor)
            metadata_blob(manifest["config"])
            for layer in manifest["layers"]:
                if layer["mediaType"] == "application/vnd.in-toto+json":
                    metadata_blob(layer)
        identity = json.loads((ROOT / (name + "-identity.json")).read_text())
        for key in sorted(selected):
            data = (layout / key).read_bytes()
            assert identity["verified_layout_members"][key] == {"sha256": digest(data), "bytes": len(data)}
            members["canonical/" + name + "-layout/" + key] = data
    for name in ("app-source-sqlite.json", "app-source-sqlite.stderr"):
        members["canonical/" + name] = (ROOT / name).read_bytes()
    for name in (
        ".github/supply-chain/vulnerability-exceptions.json",
        "tldw_Server_API/tests/Supply_Chain/test_fixed_sqlite_dispositions.py",
        "tldw_Server_API/tests/Supply_Chain/test_fresh_mount_dispositions.py",
        "tldw_Server_API/tests/Supply_Chain/test_remaining_applicability_dispositions.py",
        "IMPLEMENTATION_PLAN_TASK_13013_7_42_sqlite_runtime.md",
    ):
        members["source/" + name] = (REPO / name).read_bytes()
    for name in members:
        assert not name.startswith("/") and ".." not in Path(name).parts
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, data in sorted(members.items()):
            z.writestr(name, data)
    records = {name: {"sha256": digest(data), "bytes": len(data)} for name, data in sorted(members.items())}
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(records)
        for name, record in records.items():
            data = z.read(name)
            assert record == {"sha256": digest(data), "bytes": len(data)}
    summary["status"] = "Done"
    summary["canonical_qualification_complete"] = True
    summary["storage_recovery"] = {
        "prior_blocker": summary.pop("blocker"),
        "resolved": True,
        "result": "All three guarded canonical builds succeeded after requester freed storage.",
    }
    compatibility = summary["packaged_compatibility"]
    compatibility["canonical_build_status_at_compatibility_checkpoint"] = compatibility.pop("canonical_build_status")
    compatibility["active_dispositions_at_compatibility_checkpoint"] = compatibility.pop("new_active_dispositions")
    summary["canonical_candidates"] = json.loads((ROOT / "candidate-verification.json").read_text())
    summary["canonical_checks"] = {
        "import_cases": 40,
        "sqlite_behavior_cases": 12,
        "legacy_restores": 3,
        "package_version": "3.53.4-2",
        "sqlite_version": "3.53.4",
        "native_library_sha256": "666b2574049ed1db068b4a70837171d327c1696bf0498e6538913711c1a28370",
        "all_success_receipts_verified": True,
    }
    summary["scanner"] = {
        "image": "ghcr.io/aquasecurity/trivy:0.74.0@sha256:62b1e65e8869bc4b4c6aa4fa2b21595256c7c2f6018a9d9ad61caf87187c1969",
        "database": json.loads((ROOT / "scanner/db/metadata.json").read_text()),
        "database_hashes_unchanged": True,
        "offline": True,
        "all_severities": True,
        "include_unfixed": True,
        "json_and_cyclonedx_per_candidate": True,
    }
    summary["focused_source_tests"] = {
        "passed": 292,
        "warnings": 0,
        "record": "evidence/focused-pytest-canonical-final.txt",
    }
    summary["policy"] = {
        **json.loads((ROOT / "evidence/policy-preservation.json").read_text()),
        "new_active_records": 6,
        "policy_tests": 31,
        "expires_on": "2026-09-17",
        "unexcepted_scanner_rows": {"app": 154, "worker": 0, "audio-worker": 154},
        "remaining_rows_are_confirmed_application_exploits": False,
        "remaining_preexisting_rows": {"restricted_ffmpeg_family": 306, "XML6653": 2},
    }
    summary["evidence_archive"] = {
        "path": str(archive.relative_to(REPO)),
        "sha256": digest(archive.read_bytes()),
        "bytes": archive.stat().st_size,
        "members": records,
    }
    summary["limits"] = [
        "Canonical qualification is linux/amd64. Supplemental small runtime tests cover amd64/arm64.",
        "No whole-release admission, full application startup, model workload, or native exploit reproduction is claimed.",
        "Full canonical OCI layers remain local; complete hashes and small metadata/attestations are archived.",
        "No push, publication, deployment, workflow dispatch, or merge.",
    ]
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    print(
        json.dumps({k: summary["evidence_archive"][k] for k in ("path", "sha256", "bytes")} | {"members": len(records)})
    )


if __name__ == "__main__":
    main()
