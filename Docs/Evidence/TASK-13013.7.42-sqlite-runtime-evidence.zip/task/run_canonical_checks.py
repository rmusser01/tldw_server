"""Record successful bounded checks only after every candidate check exits zero."""

import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).parent


def output_names(name: str) -> list[str]:
    names = [f"{name}-image-inspect.json", f"{name}-packaged-sqlite.json", f"{name}-packaged-sqlite.stderr"]
    if name == "app":
        names += ["app-source-sqlite.json", "app-source-sqlite.stderr"]
    for check in ("verify_sqlite_runtime", "runtime_binding", "legacy_compatibility", "package-verification"):
        names += [f"evidence/{name}-{check}.{suffix}" for suffix in ("txt", "stderr")]
    return names


def check_inputs() -> list[str]:
    return [
        "verify_candidate.sh",
        "verify_packaged.sh",
        "verify_sqlite_package.sh",
        "packaged_sqlite_probe.py",
        "runtime_binding.py",
        "legacy_compatibility.py",
        "context/Dockerfiles/tests/verify_sqlite_runtime.py",
        "legacy/source.db",
    ]


def hashes(names: list[str]) -> dict[str, str]:
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names}


def main(name: str, subject: str) -> None:
    if name not in {"app", "worker", "audio-worker"} or not re.fullmatch(r"sha256:[a-f0-9]{64}", subject):
        raise ValueError("Unexpected candidate identity")
    completion = ROOT / f"{name}-checks-complete.json"
    completion.unlink(missing_ok=True)
    inputs = hashes(check_inputs())
    started = datetime.now(timezone.utc).isoformat()
    command = ["/bin/sh", str(ROOT / "verify_candidate.sh"), name, subject]
    with (ROOT / f"{name}-check-run.log").open("wb") as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    if hashes(check_inputs()) != inputs:
        raise ValueError("Check input changed during execution")
    record = {
        "subject_digest": subject,
        "exit_code": result.returncode,
        "started_at": started,
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "command": command,
        "check_input_sha256": inputs,
        "output_sha256": hashes(output_names(name)),
    }
    completion.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"candidate": name, "subject_digest": subject, "exit_code": result.returncode}))


if __name__ == "__main__":
    main(*sys.argv[1:])
