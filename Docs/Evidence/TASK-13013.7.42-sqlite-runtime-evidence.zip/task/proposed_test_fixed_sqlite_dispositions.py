"""Keep fixed-package scanner dispositions separate from affected SQLite."""

from datetime import date
from pathlib import Path

import pytest
from Helper_Scripts.Supply_Chain.exception_policy import evaluate_trivy_report, load_policy

pytestmark = pytest.mark.unit
POLICY = Path(".github/supply-chain/vulnerability-exceptions.json")
COMPONENTS = ("image-app", "image-worker", "image-audio-worker")
CVES = ("CVE-2026-11822", "CVE-2026-11824")
PURL = "pkg:deb/debian/libsqlite3-0@3.53.4-2?arch=amd64&distro=debian-13.6"


def finding(cve: str, **overrides: object) -> dict:
    """Make one scanner row without changing its security-relevant identity."""
    return {
        "VulnerabilityID": cve,
        "PkgIdentifier": {"PURL": PURL},
        "InstalledVersion": "3.53.4-2",
        "Severity": "HIGH",
        **overrides,
    }


@pytest.mark.parametrize("component", COMPONENTS)
@pytest.mark.parametrize("cve", CVES)
@pytest.mark.parametrize("day,active", [(9, False), (10, True), (17, True), (18, False)])
def test_fixed_package_is_allowed_only_during_review_window(component: str, cve: str, day: int, active: bool) -> None:
    policy = load_policy(POLICY, today=date(2026, 9, 10))
    report = {"Results": [{"Target": "Debian", "Vulnerabilities": [finding(cve)]}]}
    decision = evaluate_trivy_report(report, component=component, policy=policy, today=date(2026, 9, day))
    assert (len(decision.excepted), len(decision.blocking)) == ((1, 0) if active else (0, 1))


@pytest.mark.parametrize("component", COMPONENTS)
@pytest.mark.parametrize("cve", CVES)
def test_fixed_package_allowance_cannot_cover_unreviewed_rows(component: str, cve: str) -> None:
    unreviewed = [
        finding(
            cve,
            InstalledVersion="3.46.1-7+deb13u1",
            PkgIdentifier={"PURL": PURL.replace("3.53.4-2", "3.46.1-7%2Bdeb13u1")},
        ),
        finding(cve, InstalledVersion="3.53.4-3"),
        finding(cve, Severity="CRITICAL"),
        finding("CVE-2099-99999"),
        finding(cve, PkgIdentifier={"PURL": PURL.replace("amd64", "arm64")}),
        finding(cve, PkgIdentifier={"PURL": PURL.replace("13.6", "13.7")}),
        finding(cve, PkgIdentifier={"PURL": PURL.replace("libsqlite3-0", "different-package")}),
    ]
    policy = load_policy(POLICY, today=date(2026, 9, 10))
    report = {"Results": [{"Target": "Debian", "Vulnerabilities": [finding(cve), *unreviewed]}]}
    decision = evaluate_trivy_report(report, component=component, policy=policy, today=date(2026, 9, 10))
    assert (len(decision.excepted), len(decision.blocking)) == (1, 7)
    other = evaluate_trivy_report(report, component="image-webui", policy=policy, today=date(2026, 9, 10))
    assert len(other.blocking) == 8 and not other.excepted
