"""Bind benign compatibility checks to SQLite-only derivatives of TASK41 images."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parent
QUAL = ROOT / "packaged-qualification"
BASE_REVISION = "08d232ef8cad33fbc2b27b6daa6006a6d3cd426a"
PACKAGE_SHA = "bbf13c9326764d05e37e6590debdaa6f33af6bd822e3ca1204789d9d1dc23b11"
LIBRARY_SHA = "666b2574049ed1db068b4a70837171d327c1696bf0498e6538913711c1a28370"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def read(path: Path):
    return json.loads(path.read_text())


def main() -> None:
    bases = read(ROOT / "evidence/retained-task41-image-inventory.json")
    source = read(ROOT / "source-bindings.json")["files"]
    results = []
    for name in ("app", "worker", "audio-worker"):
        baseline = next(i for i in bases if f"tldw-task13013-7-41-{name}:08d232ef8c" in i["RepoTags"])
        images = read(QUAL / f"{name}-image-inspect.json")
        require(len(images) == 1, "Unexpected image inspection count")
        derived = images[0]
        metadata = read(QUAL / f"{name}-build-metadata.json")
        require(derived["Id"] == metadata["containerimage.digest"], "Derived subject mismatch")
        require(derived["Architecture"] == "amd64" and derived["Os"] == "linux", "Unexpected platform")
        layers = baseline["RootFS"]["Layers"]
        require(derived["RootFS"]["Layers"][:-1] == layers, "Baseline layers changed or extra layers added")
        for field in ("Env", "Cmd", "Entrypoint", "WorkingDir", "Healthcheck"):
            require(derived["Config"].get(field) == baseline["Config"].get(field), "Runtime config changed: " + field)
        user = baseline["Config"].get("User") or "root"
        require(derived["Config"]["User"] == user, "Runtime user changed")
        labels = dict(derived["Config"]["Labels"])
        require("not a canonical rebuild" in labels.pop("org.tldw.qualification"), "Missing qualification limit")
        require(labels == baseline["Config"]["Labels"], "Baseline labels changed")
        require(labels["org.opencontainers.image.revision"] == BASE_REVISION, "Wrong packaged source revision")
        materials = metadata["buildx.build.provenance"]["materials"]
        require(
            any(
                m["uri"].startswith("pkg:oci/baseline?") and m["digest"] == {"sha256": baseline["Id"][7:]}
                for m in materials
            ),
            "Baseline material mismatch",
        )
        require(
            any(
                m["uri"] == "https://deb.debian.org/debian/pool/main/s/sqlite3/libsqlite3-0_3.53.4-2_amd64.deb"
                and m["digest"] == {"sha256": PACKAGE_SHA}
                for m in materials
            ),
            "Package material mismatch",
        )
        checks = [f"{name}-packaged-sqlite"] + (["app-source-sqlite"] if name == "app" else [])
        for stem in checks:
            probe = read(QUAL / (stem + ".json"))
            require(probe["sqlite_version"] == "3.53.4", "Wrong native SQLite version")
            require(len(probe["cases"]) == 10, "Missing import cases")
            require(
                not probe["blocked_import_attempts"] and not probe["loaded_model_modules"], "Unexpected model import"
            )
            require((QUAL / (stem + ".stderr")).stat().st_size == 0, "Unexpected import stderr")
            prefix = (
                "/app/"
                if stem == "app-source-sqlite"
                else f"/opt/tldw-venv/lib/python3.{12 if name == 'app' else 11}/site-packages/"
            )
            expected = {
                prefix + p: sha
                for p, sha in source.items()
                if p.endswith(("OpenWebUI_DB.py", "sqlite_schema_helpers.py", "apkg_importer.py"))
            }
            require(probe["source_sha256"] == expected, "Installed source hash mismatch")
            for case in probe["cases"]:
                require(not case["evaluated"] and not case["fts_index_searches"], "Unexpected view or MATCH evaluation")
                require(
                    (case["users"] == ["u1"] and case["files"] == ["example.txt"] and case["links"] == ["f1"])
                    if case["kind"] == "openwebui"
                    else (case["fronts"] == ["Question"] and case["errors"] == []),
                    "Incorrect imported content",
                )
        binding = read(QUAL / f"evidence/{name}-runtime_binding.txt")
        require(
            binding["sqlite_version"] == "3.53.4" and binding["mapped_library_sha256"] == LIBRARY_SHA,
            "Native payload mismatch",
        )
        legacy = read(QUAL / f"evidence/{name}-legacy_compatibility.txt")
        require(legacy == {"restored_with_sqlite": "3.53.4", "rows": [["legacy orchard"]]}, "Legacy restore mismatch")
        behavior = (QUAL / f"evidence/{name}-verify_sqlite_runtime.stderr").read_text()
        require(
            "Ran 4 tests in " in behavior and behavior.rstrip().endswith("OK"), "SQLite behavior checks did not pass"
        )
        package = (QUAL / f"evidence/{name}-package-verification.txt").read_text()
        expected_package = (
            "libc6:amd64\t2.41-12+deb13u3\n"
            "libsqlite3-0:amd64\t3.53.4-2\n"
            "path-exclude /usr/share/doc/*\n"
            "path-include /usr/share/doc/*/copyright\n"
            "missing     /usr/share/doc/libsqlite3-0/README.Debian\n"
            "missing     /usr/share/doc/libsqlite3-0/changelog.Debian.gz\n"
            "missing     /usr/share/doc/libsqlite3-0/changelog.gz\n"
            "missing     /usr/share/doc/libsqlite3-0/changelog.html.gz\n"
            "package verification complete\n"
        )
        require(package == expected_package, "Package verification did not complete exactly")
        for check in ("runtime_binding", "legacy_compatibility", "package-verification"):
            require((QUAL / f"evidence/{name}-{check}.stderr").stat().st_size == 0, "Unexpected check stderr")
        results.append(
            {
                "component": "image-" + name,
                "baseline_subject": baseline["Id"],
                "qualification_subject": derived["Id"],
                "platform": "linux/amd64",
                "runtime_user": user,
                "baseline_layer_count": len(layers),
                "added_layer_count": 1,
                "import_checks": 10 * len(checks),
                "sqlite_behavior_checks": 4,
                "legacy_restore_checks": 1,
                "package_version": "3.53.4-2",
                "native_library_sha256": LIBRARY_SHA,
                "dockerfile_sha256": hashlib.sha256((QUAL / f"Dockerfile.{name}").read_bytes()).hexdigest(),
            }
        )
    output = {
        "scope": "SQLite-only derivatives of verified TASK41 images; not canonical rebuilds",
        "packaged_source_revision": BASE_REVISION,
        "canonical_source_revision": "4c64af2c4612428408b749eb3b2fc304c83ee2f4",
        "canonical_build_status": "blocked by host storage",
        "new_active_dispositions": 0,
        "results": results,
    }
    (QUAL / "verification.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
