# TASK-13013.7.42 — canonical evidence pre-review

Reviewed `evaluate_candidates.py`, `verify_candidate.sh`, `verify_oci_layout.py`, and the six proposed SQLite dispositions. Also read the directly invoked `verify_packaged.sh` and current source bindings to establish how candidate checks are associated. No Docker, application/model, malformed-database, broad-test, or repository-edit activity was performed.

## [P2] Canonical aggregation omits TASK42 native/package qualification

`evaluate_candidates.py:73-121` validates the earlier import probes, and lines 122 onward bind scanner/SBOM identities. It never consumes the canonical `runtime_binding`, `package-verification`, four SQLite behavior-check, or legacy-restore records collected by `verify_candidate.sh`. The probe SQLite version is only reported at line 192, not required to equal 3.53.4. Thus successful evaluation alone does not establish that the reviewed native library was loaded or that the TASK42 checks completed.

Minimal correction: reuse the already reviewed checks from `verify_packaged_qualification.py` for each canonical candidate: exact probe/runtime SQLite 3.53.4; native SHA256 `666b2574049ed1db068b4a70837171d327c1696bf0498e6538913711c1a28370`; the exact accepted package transcript including its terminal success marker; expected empty stderr; four successful SQLite behavior tests; and the exact benign legacy-restore result. Retain these outcomes in the canonical verification result. Missing, changed, or partial records must reject qualification.

## [P2] Check completion is not independently bound to the canonical subject

`verify_candidate.sh:7-16` correctly passes one immutable subject to its commands and stops on failure, but outputs are named only by component. It emits no final subject-bound completion record. `verify_packaged.sh:13` updates image inspection before the checks; on a later failure, downstream records from an earlier attempt can remain. Merely adding checks of these existing files to the aggregator would still permit stale records to be associated with a newer inspected candidate.

Minimal correction: clear the component's prior completion record at the start, then emit a receipt only after all commands succeed. Bind that receipt to the requested immutable subject and preferably hashes of the checked outputs; require the receipt and matching subject/output hashes in final aggregation. An equivalently retained, subject-bound successful execution record from the coordinating runner is sufficient. No additional image execution is needed beyond the already authorized checks.

## Existing checks and disposition scope

- The OCI verifier now expects the correct canonical source revision `4c64af2c4612428408b749eb3b2fc304c83ee2f4`, matching source-bindings.json. Its previously reviewed path/hash/size, rootfs count/type, runtime layer type, and linked-attestation checks remain present. TASK41 compatibility derivatives retain a different source revision and cannot satisfy this canonical source check unchanged.
- The shell runner invokes `runtime_binding.py verify-amd64` and the corrected exact package verifier. The collection-side native/package checks are present; the gaps are final aggregation and completion association.
- The six proposed records still cover only the exact amd64 Debian 13.6 PURL, package 3.53.4-2, two HIGH SQLite CVEs, three named backend components, and the September 10–17 review window. They disclose the policy matcher's lack of image/native-hash enforcement and make no native-exploit reproduction claim. Their vendor-fixed rationale remains supported by the previously reviewed evidence.
- Activation must follow successful qualification and fresh scans of these canonical identities. Match each proposed allowance to the actual retained scan identity; do not broaden version, architecture, distro, or severity to make a new row fit. Preserve old-version blocking and the existing policy records.
- The evaluator currently reports blocking counts without failing on them. Treat its output as a report; the final closure decision must explicitly establish the intended SQLite disposition outcome and identify any unresolved blocker rather than treating exit zero alone as release approval. Its hardcoded September 10 evaluation date matches the current review date; update the evaluation date if qualification occurs on a later date.

## Assessment

Two bounded evidence-gating corrections are needed before the canonical verification result can truthfully close TASK42. No new recipe/OCI/disposition defect was identified in this pass. This review does not claim that the running canonical builds or their installed checks have completed.
