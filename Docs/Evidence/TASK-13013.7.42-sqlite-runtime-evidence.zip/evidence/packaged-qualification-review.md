# TASK-13013.7.42 — packaged-code qualification approach review

## Assessment

The three temporary recipes are suitable for testing the fixed SQLite package against the already packaged TASK41 code. No material recipe defect was identified. This approach does not qualify a rebuild of the updated canonical Dockerfiles, does not establish final canonical scan results, and cannot justify activating the proposed canonical-candidate dispositions while canonical qualification remains incomplete.

## Recipe review

Each recipe obtains the official amd64 libsqlite3-0 3.53.4-2 package with mandatory SHA256 `bbf13c9326764d05e37e6590debdaa6f33af6bd822e3ca1204789d9d1dc23b11`, stages it in a scratch image, and installs it through a read-only bind mount. No application, virtual environment, or source files are rebuilt or copied. The package archive mount is temporary. The installation necessarily updates normal dpkg/library metadata as well as the native library.

The app recipe restores `USER appuser`; both worker recipes restore root, consistent with the reviewed baseline recipes. All three preserve other inherited runtime configuration and carry an explicit label stating that they are not canonical rebuilds. Their build assertion checks exact SQLite 3.53.4 with isolated Python and site initialization disabled.

The reviewed worker metadata records the requested immutable OCI baseline digest `sha256:41ec9f517ca23a43a8c54c66017ccc0ba72e45eb86ad9b60a1a6b7a7aa402c05` and the expected Debian package digest as build materials. The baseline material selects linux/amd64. The separate provenance environment field describes the builder platform; it is not sufficient evidence of the output image architecture.

## Material checks before claiming packaged-code compatibility

1. Retain each component's exact baseline material digest, temporary recipe hash, derived subject/config digest, output architecture, user, and qualification label. Run checks against immutable derived identities. The digest pin resides in the build-context invocation, so verify it in each component's resulting metadata.
2. Use the copied virtual environment for `runtime_binding.py verify-amd64` and retain exact libsqlite3-0 3.53.4-2 identity, empty package verification output, SQLite 3.53.4, and the reviewed native payload SHA256. The build assertion alone is insufficient for this claim.
3. Retain the already defined benign packaged-code checks, FTS5 backup/restore, JSON, WAL, and legacy fixture restoration results. Preserve the fixture's original creation-version evidence. Exercise each actual packaged component and any separately retained app source copy covered by the claim.
4. Label any resulting scan, compatibility result, and summary as this derived TASK41 packaged-code candidate. Do not reuse these identities as canonical rebuild evidence or activate canonical-candidate dispositions on their basis.

No additional full application/model startup, malformed database, or unrelated vulnerability investigation is required for this bounded compatibility claim.

## Review limits

This review read the three temporary Dockerfiles and available worker build metadata. It performed no Docker or application/model execution and did not independently observe runtime-check success. Canonical rebuilding remains a separate unmet requirement under the coordinator's reported disk constraint. Repository files were not edited.
