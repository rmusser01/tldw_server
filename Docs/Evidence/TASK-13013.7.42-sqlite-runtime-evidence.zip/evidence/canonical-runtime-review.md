# TASK-13013.7.42 — actual canonical runtime evidence review

## Assessment

The actual canonical app, worker, and audio-worker records support the fixed SQLite native qualification. No material mismatch was found. This evidence supports the six narrowly scoped vendor-fixed dispositions once all three final scans are fresh, bound to these same canonical subjects/configs/source, and match the proposed finding identities. The worker scan satisfies those checks in this review; app/audio scans were not audited here.

## Canonical subjects audited

| Component | OCI subject digest |
| --- | --- |
| App | `sha256:e7365b35623a175c27808e3e33fc8f5d731b808c6faca4be204d0b43cbc7d54c` |
| Worker | `sha256:07f686b78d3614cd357170e66e3d9a0b7d6d80a8f65a6885e5318f73ca8e4869` |
| Audio worker | `sha256:b80e9da3ba66bed8aaadbb58c643e3c058b5d2ec23149f23018ee9ac61bccd05` |

All three identify source revision `4c64af2c4612428408b749eb3b2fc304c83ee2f4` and linux/amd64. They do not carry the temporary packaged-derivative qualification label.

## Independent metadata checks

- Verified build-metadata hashes against the retained identities and matched build subject digests. Independently hashed only the small OCI index/subject/manifest/config JSON files, matched their recorded identities, and compared loaded image identities and runtime configuration to those configs.
- Confirmed build provenance contains the official amd64 and arm64 Debian package URLs and their reviewed SHA256 values. Matched all 12 repository file bindings to source-bindings.json.
- Ran the reviewed native evidence validator against the actual canonical records in the task root. All three completion receipts have exit zero, the exact subject/command, ordered times, and current exact helper/fixture input and output hashes. The app receipt binds 13 outputs; each worker receipt binds 11.
- Exact package transcripts, expected empty relevant stderr, SQLite 3.53.4, and native-library SHA256 `666b2574049ed1db068b4a70837171d327c1696bf0498e6538913711c1a28370` all match. The four missing documentation entries remain precisely the Debian slim exclusions, with terminal package-verification success recorded.
- Rechecked actual installed-source hash mappings and every import case's recorded content/results. The canonical records support 40 import cases, 12 SQLite behavior checks, and three benign legacy restores: **55 compatibility checks**. The app's separate source copy is included. No model import attempts or loaded model modules are reported.

Exact per-component details are retained in `canonical-runtime-review-details.json`.

## Available worker scan

The completed worker report matches the audited subject, config digest, and source revision. Both scan timestamps fall within 24 hours after the recorded scanner database update. Its CVE-2026-11822 and CVE-2026-11824 rows are HIGH for the exact package version 3.53.4-2 and PURL `pkg:deb/debian/libsqlite3-0@3.53.4-2?arch=amd64&distro=debian-13.6`, matching the two proposed worker records.

The same scan/SBOM identity, freshness, and exact-row checks remain required for app and audio before the full six-record reconciliation is concluded. Preserve the existing policy and old-version blocking, and apply only the supported exact records within their valid review window. This review does not activate policy entries or claim that all final scans have completed.

## Limits

This was an independent audit of actual recorded canonical metadata and results, not a rerun of image contents. No Docker, application/model, or malformed-database work was executed, no giant OCI layer blobs were rehashed, and no repository files were edited. Full layer verification was supplied by the coordinator's unchanged strict OCI verifier; this pass checked its small metadata bindings and current runtime evidence.
