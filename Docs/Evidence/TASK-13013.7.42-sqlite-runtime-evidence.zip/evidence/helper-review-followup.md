# TASK-13013.7.42 — helper follow-up review

## Corrections verified

- `verify_oci_layout.py:67-105` now validates index/manifest/config headers and media types, rootfs type, DiffID syntax, and layer counts. Independently repeated both original false-success controls: an absent layer omitted from the manifest now fails with `Rootfs layer count mismatch`; an invalid manifest descriptor type now fails with `Invalid manifest descriptor media type`. The valid synthetic fixture still succeeds. The coordinator's separate ten-control result was also read.
- `runtime_binding.py:19-25` now rejects an unexpected verification mode and, in `verify-amd64` mode, requires SQLite version 3.53.4 and native-library SHA256 `666b2574049ed1db068b4a70837171d327c1696bf0498e6538913711c1a28370`.
- `verify_candidate.sh:11` invokes that verification mode. Its package check at line 16 explicitly requires libsqlite3-0 version 3.53.4-2 and empty `dpkg --verify` output. Static shell parsing confirmed the quoted `${Version}` format survives intact and the child command is syntactically valid. No Docker command was executed.

## Remaining [P2] runtime/attestation layer types are mixed

`verify_oci_layout.py:60-65,106-107` uses one layer-type allowlist for all manifests. That list includes `application/vnd.in-toto+json`, so the selected linux/amd64 runtime manifest can still claim an attestation payload as a root filesystem layer and receive an identity record. Independently confirmed with a synthetic runtime layer whose descriptor uses that type.

Restrict the selected runtime manifest to the supported OCI tar layer types. Permit in-toto payloads only for recognized attestation manifests. This is the remaining narrow descriptor-validation portion of the earlier OCI finding; the two original reported mutations are corrected. No claim of uncompressed DiffID verification is implied by the new format/count checks.

Reviewer control results are retained in `helper-review-followup-controls.json`.

## Qualification status

The exact-package/native-payload finding is closed at the helper-code level. OCI validation still needs the runtime/attestation type separation above. The coordinator confirmed revision label `6da7787415044607fea95e9c5ec9131067e3814f` was correct for the failed build attempts; future checks must use the identity of their actual build source.

Canonical app/worker builds reportedly failed during virtual-environment copying because host disk space was exhausted. No final canonical candidate success, runtime qualification, or active disposition is claimed. This review used source inspection, small synthetic OCI fixtures, and shell syntax checking only; no application/model, Docker, or malformed-database execution occurred, and no repository files were edited.
