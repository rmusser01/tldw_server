# TASK-13013.7.42 — bounded helper review

Reviewed `verify_oci_layout.py`, `runtime_binding.py`, `legacy_compatibility.py`, and `verify_candidate.sh`, plus the directly invoked `verify_packaged.sh`. No repository files were edited and no Docker, application/model, or database payload was executed.

## Findings

### [P2] OCI success does not establish a complete, correctly typed root filesystem

`verify_oci_layout.py:75-97` validates file hashes and the layers listed by a manifest, but never checks `config.rootfs` against that list. A synthetic layout with one `rootfs.diff_ids` entry, `layers: []`, and the actual layer blob absent is accepted and receives an identity record. A second fixture using an invalid child descriptor mediaType is also accepted; schema versions and descriptor media types are not validated anywhere.

This is a demonstrated false-success path for the requested OCI completeness/descriptor check. Validate the expected index/manifest/config types and schema versions, then require the runtime rootfs type, DiffID formats, and layer count to agree with the runtime manifest. Restrict those runtime checks appropriately so BuildKit attestation manifests remain supported. If full rootfs integrity is claimed, also bind ordered uncompressed layer digests or retain a separate validated-loader check; hashing compressed blobs alone does not establish that binding. The OCI specifications distinguish layer DiffIDs from stored layer digests and define the image manifest schema. [OCI configuration specification](https://github.com/opencontainers/image-spec/blob/main/config.md), [OCI manifest specification](https://github.com/opencontainers/image-spec/blob/main/manifest.md).

Synthetic outcomes are retained in `helper-review-synthetic.json`. Controls confirmed that missing explicitly referenced layer blobs, wrong descriptor sizes, wrong source labels, and symlinks are rejected.

### [P2 if used as the qualification gate] Candidate success does not enforce the exact reviewed package/native payload

`verify_candidate.sh:8-16` records `runtime_binding.py` output and prints `dpkg-query` information, but does not compare either against the reviewed values. The runtime test requires only SQLite >=3.53.2. Consequently, a different working SQLite package/library can complete this script successfully even though it falls outside the proposed exact 3.53.4-2 disposition.

Require package version `3.53.4-2`, SQLite runtime version `3.53.4`, and mapped-library SHA256 `666b2574049ed1db068b4a70837171d327c1696bf0498e6538913711c1a28370` for these amd64 candidates before declaring qualification. If a subsequent evidence aggregation step already enforces these comparisons and candidate identity, this is a limitation of this collection script rather than an end-to-end defect. That subsequent check was not supplied in this review scope. `runtime_binding.py` correctly describes itself as a recorder; the issue is treating the shell script's success as exact-package verification.

## Other observations

- Path names are restricted, symlinks and unexpected entry types/directories are rejected, all discovered blobs are hashed against their names, and referenced descriptors check sizes. A stable task-owned directory is assumed during verification.
- Source-label comparison is exact but hardcoded to `6da7787415044607fea95e9c5ec9131067e3814f`; the coordinator was asked to confirm this is the intended TASK42 context label. The label check does not independently prove checkout contents.
- `runtime_binding.py` rejects ambiguous/missing OS-library mappings and hashes the recorded mapping. `legacy_compatibility.py` opens the restore source read-only, checks its FTS result, refuses to overwrite a creation fixture, and fails on unsupported operations. The caller must retain the creation-version evidence to substantiate the pre-upgrade fixture claim.
- Shell `set -eu` propagates failed checks. `verify_candidate.sh` passed shell syntax checking. Python Ruff/Bandit success was supplied by the coordinator; it was not rerun here.

## Assessment

No critical findings. Address the OCI false-success gap and ensure exact package/library comparisons exist before using these outputs as qualification evidence. The synthetic checks used small ordinary JSON files and an empty tar layer only; no image contents were executed.
