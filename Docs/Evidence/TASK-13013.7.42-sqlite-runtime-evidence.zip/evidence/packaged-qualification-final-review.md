# TASK-13013.7.42 — final packaged-qualification review

## Assessment

The retained evidence is consistent with the stated, narrow qualification of SQLite-only derivatives of TASK41 packaged code. The requested identity/hash negative controls pass. One report-verifier gap remains below; it does not describe a mismatch in the three currently retained package transcripts. Canonical rebuild qualification remains outside this evidence.

## [P2] Final aggregation can accept a failed package-verification transcript

`verify_packaged_qualification.py:100-103` requires only the expected package-version substring and empty stderr. It does not require the package verifier's exact permitted output or a successful execution result. `verify_sqlite_package.sh:13-14` prints its verification output before rejecting an unexpected line, so a failed check can leave a stdout file that satisfies the aggregator.

Confirmed using metadata-only copies: appending `missing     /usr/share/doc/libsqlite3-0/copyright` to the app package-verification transcript still lets the final verifier succeed. Require the exact allowed package transcript/verification lines in the aggregator, or otherwise bind the success status of this check before emitting successful verification.json. Exact transcript validation is the simplest correction for this bounded workflow.

## Negative controls and evidence checked

Ran the verifier against temporary copies of its metadata and text inputs. No images, applications, models, or database payloads were executed. Results in `packaged-qualification-final-review-controls.json`:

- Unaltered retained evidence: accepted.
- Changed baseline material digest: rejected.
- Additional derived image layer: rejected.
- Changed native library hash: rejected.
- Changed installed source hash: rejected.
- Additional package-verification failure line: incorrectly accepted, as described above.

The verifier checks unchanged baseline layer prefixes with exactly one added layer, runtime configuration/user/labels, immutable baseline and package materials, and installed source/native-library hashes. The current retained result reports 40 import cases, 12 SQLite behavior checks, and three legacy fixture restores across the derivatives; the independent unaltered-input run accepted the supporting inputs. These are packaged-code compatibility results, not canonical build or exploit-reproduction results.

## Debian slim documentation correction

`verify_sqlite_package.sh` requires exact libsqlite3-0 version 3.53.4-2, the active `path-exclude /usr/share/doc/*` line, the copyright inclusion line, and exactly four missing documentation entries: README.Debian and the three changelog files. It rejects additional or different verification output and requires the temporary package paths to be absent. Shell syntax checking passed.

All three actual retained transcripts contain the expected configuration lines and only those four missing documentation entries. The separate native-library gate requires the reviewed SHA256 and SQLite version. Consequently, the earlier verifier failures for these excluded documents do not indicate an actual native-library defect. This is an exact match to the slim image's documented omission behavior, not a general relaxation of package integrity checking. The aggregator should enforce that same narrow result.

## Limits

No repository edits or Docker/application/model/malformed-database runs were performed. Ruff/Bandit cleanliness was supplied by the coordinator and was not rerun. No canonical-candidate success or new active disposition is asserted.
