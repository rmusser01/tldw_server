# TASK-13013.7.42 — canonical receipt/native-check follow-up

## Assessment

Both material findings in `canonical-evidence-pre-review.md` are resolved by the reviewed runner and evaluator changes. No new material finding was identified. This assessment covers the evidence helpers, not completion of the three canonical builds or their real installed checks.

## Corrections reviewed

`run_canonical_checks.py` constrains component and immutable subject syntax, removes the previous completion receipt before work, hashes the exact helper/fixture inputs, and invokes the fixed shell runner with `check=True`. It writes a receipt only after the runner succeeds, the inputs still match their initial hashes, and all expected output files can be hashed. The receipt records the subject, successful exit status, command, times, and complete input/output hash mappings.

`evaluate_candidates.py:47-79` requires that receipt to match the canonical subject, verifies complete current input/output mappings, then checks the exact native version and SHA256, legacy restore result, four successful SQLite behavior tests, exact package transcript with its terminal success marker, and clean relevant stderr. The main evaluation calls this validator and separately requires exact 3.53.4 in each packaged import probe. Existing loaded-image, source, report, and SBOM identity checks remain in place.

## Metadata-only controls

Ran `validate_native_checks` using temporary copies of the already retained benign compatibility outputs and synthetic receipts. The runner's subprocess path was not executed. Twelve controls behaved as expected:

- A valid fixture receipt was accepted.
- Missing receipt, stale subject, failed exit status, and incomplete output-hash map were rejected.
- Changed output or input content was rejected by receipt-hash comparison.
- Wrong native SHA256, partial package transcript, wrong legacy rows, failing SQLite tests, and unexpected relevant stderr were rejected even when the synthetic receipt's output hashes were recomputed to match the altered data. This verifies semantic checks independently of hash consistency.

Detailed outcomes are retained in `canonical-receipt-review-controls.json`.

## Limits

These controls do not substitute for running the successful receipt-producing wrapper against each actual canonical subject. No Docker, application/model, malformed-database, broad-test, or repository-edit activity occurred. Final policy activation and task completion still require the actual canonical checks and fresh bound scan evidence described in the prior review.
