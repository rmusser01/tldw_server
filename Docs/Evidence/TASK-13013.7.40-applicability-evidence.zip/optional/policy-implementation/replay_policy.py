"""Replay retained JSON through pure policy code; no application/runtime imports."""

from collections import Counter
from dataclasses import asdict
from datetime import date
import hashlib
import json
from pathlib import Path

from Helper_Scripts.Supply_Chain.dependency_review import derive_allow_ghsas, load_changes, validate_allow_ghsas
from Helper_Scripts.Supply_Chain.exception_policy import evaluate_trivy_report, load_policy

OUT = Path('/private/tmp/task-13013-7-40-optional/policy-implementation')
POLICY = Path('.github/supply-chain/vulnerability-exceptions.json')
TODAY = date(2026, 9, 10)
BASELINE = OUT / 'baseline-policy.json'
source = Path('/private/tmp/task-13013-7-28-chroma.tFu6fO/github-dependency-diff-pages.json')
baseline = load_policy(BASELINE, today=TODAY)
current = load_policy(POLICY, today=TODAY)
before_bytes = BASELINE.read_bytes()
after_bytes = POLICY.read_bytes()
old = json.loads(before_bytes)
new = json.loads(after_bytes)
added = [r for r in new['exceptions'] if r['id'].startswith('TASK-13013.7.40-')]
assert len(old['exceptions']) == 322 and len(added) == 14
assert new['exceptions'][:322] == old['exceptions']
suffix = b'\n  ],\n  "schema_version": 1\n}\n'
assert before_bytes.endswith(suffix)
assert after_bytes.startswith(before_bytes[:-len(suffix)])
results = {
    'baseline_policy_sha256': hashlib.sha256(before_bytes).hexdigest(),
    'policy_sha256': hashlib.sha256(after_bytes).hexdigest(),
    'baseline_record_count': 322,
    'final_record_count': len(new['exceptions']),
    'baseline_record_values_and_bytes_preserved': True,
    'evaluation_date_utc': str(TODAY),
    'supported_dispositions': added,
    'images': {},
}
for component, expected_removed, expected_blocking in (
    ('image-app', 4, 156), ('image-worker', 1, 2), ('image-audio-worker', 4, 156)
):
    path = Path('/private/tmp/task-13013-7-fresh-images/scan-output') / f'trivy-{component}.json'
    raw = path.read_bytes()
    report = json.loads(raw)
    before_serialized = json.dumps(report, sort_keys=True)
    prior = evaluate_trivy_report(report, component=component, policy=baseline, today=TODAY)
    actual = evaluate_trivy_report(report, component=component, policy=current, today=TODAY)
    removed = set(prior.blocking) - set(actual.blocking)
    assert len(removed) == expected_removed
    assert len(actual.blocking) == expected_blocking
    assert set(prior.excepted).issubset(actual.excepted)
    assert not actual.unmatched_exception_ids
    assert not (set(actual.blocking) - set(prior.blocking))
    assert json.dumps(report, sort_keys=True) == before_serialized
    assert path.read_bytes() == raw
    results['images'][component] = {
        'report_path': str(path), 'report_sha256': hashlib.sha256(raw).hexdigest(),
        'before_blocking': len(prior.blocking), 'after_blocking': len(actual.blocking),
        'before_excepted': len(prior.excepted), 'after_excepted': len(actual.excepted),
        'removed_exact_rows': [asdict(r) for r in sorted(removed, key=lambda r:(r.vulnerability_id,r.purl))],
        'unmatched_exception_ids': actual.unmatched_exception_ids,
        'prior_excepted_preserved': True, 'raw_report_unchanged': True,
    }
raw = source.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '3c6f6459322a9fd47293ee551a776737f5138131b94200b8eeb27aeb9ba9ccfb'
changes = load_changes(source, paginated=True)
assert len(changes) == 695
before_changes = json.dumps(changes, sort_keys=True)
prior_allowed = derive_allow_ghsas(changes, policy=baseline, today=TODAY)
allowed = derive_allow_ghsas(changes, policy=current, today=TODAY)
new_allowed = set(allowed) - set(prior_allowed)
expected_new = {'GHSA-2cp2-2r3c-7p7r', 'GHSA-9379-mwvr-7wxx', 'GHSA-hvjw-vp7g-39h5',
                'GHSA-m4jw-wgmf-889x', 'GHSA-v7v2-m736-cf3c'}
assert new_allowed == expected_new
validate_allow_ghsas(','.join(allowed), changes, policy=current, today=TODAY)
occurrences = Counter(v['advisory_ghsa_id'] for c in changes if c['change_type']=='added'
                      for v in c['vulnerabilities'] if v['severity'] in ('high','critical'))
assert json.dumps(changes, sort_keys=True) == before_changes
assert source.read_bytes() == raw
results['source'] = {
    'path': str(source), 'sha256': hashlib.sha256(raw).hexdigest(), 'change_count': len(changes),
    'prior_allowed_ghsas': prior_allowed, 'allowed_ghsas': allowed, 'added_ghsas': sorted(new_allowed),
    'added_high_critical_occurrence_counts': dict(sorted(occurrences.items())),
    'blocking_high_critical_occurrence_count': sum(n for k,n in occurrences.items() if k not in allowed),
    'each_added_occurrence_covered_by_canonical_record': True,
    'action_output_revalidation_passed': True, 'raw_changes_unchanged': True,
}
(OUT/'replay-results.json').write_text(json.dumps(results, indent=2, sort_keys=True)+'\n')
print(json.dumps({
    'policy_sha256': results['policy_sha256'],
    'final_record_count': results['final_record_count'],
    'image_counts': {k:(v['before_blocking'],v['after_blocking']) for k,v in results['images'].items()},
    'source_changes': len(changes), 'source_allowed_ghsas': allowed,
    'source_blocking_high_critical_occurrences': results['source']['blocking_high_critical_occurrence_count'],
}, indent=2))
