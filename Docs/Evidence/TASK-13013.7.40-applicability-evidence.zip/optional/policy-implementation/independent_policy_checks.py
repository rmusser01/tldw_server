"""Independent stdlib/pure-policy crosscheck; writes only retained tmp review output."""
import ast
import hashlib
import json
import re
import subprocess
import sys
from dataclasses import replace
from datetime import date
from pathlib import Path

from Helper_Scripts.Supply_Chain.dependency_review import derive_allow_ghsas, load_changes
from Helper_Scripts.Supply_Chain.exception_policy import load_policy

ROOT = Path.cwd()
OUT = Path('/private/tmp/task-13013-7-40-optional/policy-implementation')
POLICY = Path('.github/supply-chain/vulnerability-exceptions.json')
TODAY = date(2026, 9, 10)
sha = lambda b: hashlib.sha256(b).hexdigest()
base_bytes = subprocess.check_output(['git', 'show', 'HEAD:' + str(POLICY)])
current_bytes = POLICY.read_bytes()
assert base_bytes == (OUT / 'baseline-policy.json').read_bytes()
base, current = json.loads(base_bytes), json.loads(current_bytes)
assert len(base['exceptions']) == 322 and len(current['exceptions']) == 336
assert current['exceptions'][:322] == base['exceptions']
assert {k: v for k, v in current.items() if k != 'exceptions'} == {k: v for k, v in base.items() if k != 'exceptions'}

def raw_records(data):
    text = data.decode()
    pos = re.search(r'"exceptions"\s*:\s*\[', text).end()
    result = []
    decoder = json.JSONDecoder()
    while True:
        pos += len(text[pos:]) - len(text[pos:].lstrip(' \t\r\n,'))
        if text[pos] == ']':
            return result
        obj, end = decoder.raw_decode(text, pos)
        result.append((obj['id'], text[pos:end].encode()))
        pos = end

old_raw, new_raw = raw_records(base_bytes), raw_records(current_bytes)
assert old_raw == new_raw[:322]
assert current_bytes.startswith(base_bytes[:-len(b'\n  ],\n  "schema_version": 1\n}\n')])
added = current['exceptions'][322:]
assert all(r['id'].startswith('TASK-13013.7.40-') for r in added)
assert len(set(r['id'] for r in current['exceptions'])) == 336
identity = lambda r: (r['component'], r['purl'], r['installed_version'], r['vulnerability_id'], r['severity'])
assert len(set(map(identity, added))) == 14

paths = {
 'acl': Path('/private/tmp/task-13013-7-40-acl/assessment.json'),
 'decoder': Path('/private/tmp/task-13013-7-40-native-secondary/assessment.json'),
 'xml': Path('/private/tmp/task-13013-7-40-native/xml-assessment.json'),
 'optional': Path('/private/tmp/task-13013-7-40-optional/findings.json'),
}
evidence = {k: json.loads(p.read_text()) for k, p in paths.items()}
expected = set(map(identity, evidence['optional']['findings']))
expected.update(map(identity, evidence['xml']['proposed_exclusions']))
for row in evidence['acl']['exact_rows']:
    r = row['raw']
    expected.add((row['component'], r['PkgIdentifier']['PURL'], r['InstalledVersion'], r['VulnerabilityID'], r['Severity']))
for row in evidence['decoder']['rows']:
    expected.add(('image-' + row['component'], row['purl'], row['version'], row['cve'], row['severity']))
assert expected == set(map(identity, added))
assert all(r['created_on'] == '2026-09-10' and r['expires_on'] == '2026-09-17' and r['owner'] == 'rmusser01' for r in added)

def aliases(data):
    for node in ast.parse(data).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == '_ADVISORY_IDENTITIES' for t in node.targets):
            return ast.literal_eval(node.value)
    raise AssertionError('missing alias table')

module = Path('Helper_Scripts/Supply_Chain/dependency_review.py')
old_module = subprocess.check_output(['git', 'show', 'HEAD:' + str(module)])
old_alias, new_alias = aliases(old_module), aliases(module.read_bytes())
assert all(new_alias[k] == v for k, v in old_alias.items())
expected_alias = {r['ghsa']: (r['vulnerability_id'], r['package'], r['installed_version']) for r in evidence['optional']['findings']}
assert {k: v for k, v in new_alias.items() if k not in old_alias} == expected_alias

changes_path = Path(evidence['optional']['exact_row_origin']['original_comparison'])
changes_bytes = changes_path.read_bytes()
assert sha(changes_bytes) == evidence['optional']['exact_row_origin']['original_comparison_sha256']
changes = load_changes(changes_path, paginated=True)
policy = load_policy(POLICY, today=TODAY)
without = replace(policy, exceptions=tuple(r for r in policy.exceptions if not r.id.startswith('TASK-13013.7.40-')))
current_allow = derive_allow_ghsas(changes, policy=policy, today=TODAY)
prior_allow = derive_allow_ghsas(changes, policy=without, today=TODAY)
assert set(current_allow) - set(prior_allow) == set(expected_alias)
source_rows = []
for ghsa, (cve, name, version) in expected_alias.items():
    found = [(c,v) for c in changes if c['change_type'] == 'added' for v in c['vulnerabilities'] if v['advisory_ghsa_id'] == ghsa]
    assert found
    for c,v in found:
        assert c['manifest'] in ('uv.lock', 'pyproject.toml') and c['ecosystem'] == 'pip'
        assert c['name'] == name and c['version'] == version and c['package_url'] == f'pkg:pypi/{name}@{version}'
        assert ('source-python-root', c['package_url'], c['version'], cve, v['severity'].upper()) in expected
        source_rows.append({'ghsa': ghsa, **{k:c[k] for k in ['manifest','ecosystem','name','version','package_url']}, 'severity':v['severity']})
    assert ghsa not in derive_allow_ghsas(changes, policy=without, today=TODAY)
    for day in [9,18]:
        assert ghsa not in derive_allow_ghsas(changes, policy=policy, today=date(2026,9,day))
assert changes_path.read_bytes() == changes_bytes

files = [POLICY, module, Path('tldw_Server_API/tests/Supply_Chain/test_remaining_applicability_dispositions.py'), *[Path('tldw_Server_API/tests/Supply_Chain') / n for n in ['test_fresh_mount_dispositions.py','test_lightning_applicability_policy.py','test_os_package_dispositions.py']]]
loaded_modules = sorted(n for n in sys.modules if n.startswith(('Helper_Scripts.', 'tldw_Server_API.', 'torch', 'nemo', 'nltk', 'transformers', 'soundfile', 'PIL', 'lxml')))
assert not any(n.startswith(('tldw_Server_API.', 'torch', 'nemo', 'nltk', 'transformers', 'soundfile', 'PIL', 'lxml')) for n in loaded_modules)
result = {
 'reviewed_head': subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(),
 'baseline_sha256': sha(base_bytes),
 'baseline_byte_source': 'git show HEAD:.github/supply-chain/vulnerability-exceptions.json; equals retained baseline-policy.json',
 'preserved_prior_record_values': 322,
 'preserved_prior_raw_record_slices': 322,
 'original_file_prefix_preserved_through_last_record': True,
 'prior_top_level_metadata_unchanged': True,
 'added_records': 14,
 'total_records': 336,
 'exact_added_identities_match_four_assessments': True,
 'exact_added_ghsa_aliases': expected_alias,
 'source_comparison_sha256': sha(changes_bytes),
 'source_change_count': len(changes),
 'new_source_occurrences': source_rows,
 'new_advisories_require_separate_approval': True,
 'before_and_after_dates_deny_new_advisories': True,
 'prior_advisories_preserved': sorted(prior_allow),
 'reviewed_files': {str(p): sha(p.read_bytes()) for p in files},
 'assessment_files': {str(p): sha(p.read_bytes()) for p in paths.values()},
 'loaded_repository_or_sensitive_modules': loaded_modules,
}
(OUT/'independent-policy-checks.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))
