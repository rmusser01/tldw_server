"""Create static optional-loader evidence; never import reviewed package code."""

import ast
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('/Users/macbook-dev/Documents/GitHub/tldw_server2/.worktrees/task-13013-7-supply-chain-design')
OUT = Path('/private/tmp/task-13013-7-40-optional')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def evidence(path, ranges):
    lines = path.read_text().splitlines()
    return {
        'file': str(path), 'sha256': digest(path),
        'excerpts': [{'start': start, 'end': end, 'text': '\n'.join(lines[start-1:end])}
                     for start, end in ranges],
    }


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == '073eb4c4a350137736ae529b328dc3ae4202dc8b'
rows = json.loads(Path('/private/tmp/task-13013-7-optional-followup/exact-rows.json').read_text())
selected = [r for r in rows['normalized_advisory_rows'] if r['package'] in ('hydra-core', 'nemo-toolkit')]
assert len(selected) == 5
packages = {p['name']: p for p in rows['selected_locked_packages']}
wheel_bindings = []
for name, filename, prefix in [('nemo-toolkit', 'nemo_toolkit-2.0.0-py3-none-any.whl', 'nemo/'),
                               ('hydra-core', 'hydra_core-1.3.2-py3-none-any.whl', 'hydra/')]:
    wheel = OUT / filename
    wheel_info = packages[name]['wheels'][0]
    assert digest(wheel) == wheel_info['hash'].removeprefix('sha256:')
    with zipfile.ZipFile(wheel) as archive:
        members = [{'path': n, 'sha256': hashlib.sha256(archive.read(n)).hexdigest()}
                   for n in archive.namelist() if n.startswith(prefix) and n.endswith('.py')]
        metadata_name = next(n for n in archive.namelist() if n.endswith('.dist-info/METADATA'))
        (OUT / (name + '-METADATA.txt')).write_bytes(archive.read(metadata_name))
    source_dir = OUT / ('nemo-2.0.0-source' if name == 'nemo-toolkit' else 'hydra-1.3.2-source')
    assert all(digest(source_dir / m['path']) == m['sha256'] for m in members)
    wheel_bindings.append({'package': name, 'version': packages[name]['version'],
                           'wheel': str(wheel), 'sha256': digest(wheel),
                           'url': wheel_info['url'], 'python_members': members})
(OUT / 'package-source-manifests.json').write_text(json.dumps(wheel_bindings, indent=2) + '\n')

nemo_root = OUT / 'nemo-2.0.0-source'
parse_errors = []
torch_calls = []
pickle_calls = []
unsafe_overrides = []
for path in sorted(nemo_root.rglob('*.py')):
    try:
        tree = ast.parse(path.read_text(), filename=str(path))
    except SyntaxError as error:
        parse_errors.append({'file': str(path), 'error': str(error)})
        continue
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if not isinstance(func, ast.Attribute) or not isinstance(func.value, ast.Name):
            continue
        call_name = func.value.id + '.' + func.attr
        if call_name not in ('torch.load', 'pickle.load', 'pickle.loads'):
            continue
        call = {'file': str(path), 'sha256': digest(path), 'line': node.lineno,
                'call': ast.get_source_segment(path.read_text(), node)}
        if call_name == 'torch.load':
            torch_calls.append(call)
            if any(k.arg == 'weights_only' and isinstance(k.value, ast.Constant) and k.value.value is False
                   for k in node.keywords):
                unsafe_overrides.append(call)
        else:
            pickle_calls.append(call)
assert not parse_errors, parse_errors
assert not unsafe_overrides
package_scan = {'method': 'stdlib ast.parse only, never imports or executes NeMo/Hydra/PyTorch',
                'python_files': len(list(nemo_root.rglob('*.py'))), 'parse_errors': parse_errors,
                'torch_load_calls': torch_calls, 'pickle_load_calls': pickle_calls,
                'explicit_weights_only_false_calls': unsafe_overrides,
                'hf_checkpoint_io_module_present': (nemo_root / 'nemo/lightning/io/hf.py').exists(),
                'fsdp_dtensor_loader_present': any('_load_fsdp_dtensor_common_state' in p.read_text() for p in nemo_root.rglob('*.py')),
                'sortformer_symbol_present': any('SortformerEncLabelModel' in p.read_text() for p in nemo_root.rglob('*.py')),
                'speaker_tagged_asr_symbol_present': any('SpeakerTaggedASR' in p.read_text() for p in nemo_root.rglob('*.py'))}
(OUT / 'package-static-scan.json').write_text(json.dumps(package_scan, indent=2) + '\n')

repo_ranges = {
    'Docs/User_Guides/STT_Benchmark_User_Guide.md': [(62, 103)],
    'Docs/Development/STT_Benchmark_Protocol.md': [(7, 21), (240, 265)],
    'Docs/Development/STT_Adapter_Golden_Tests.md': [(84, 113)],
    'Helper_Scripts/Audio/generate_stt_golden.py': [(90, 119), (296, 310)],
    'Helper_Scripts/benchmarks/stt_bench.py': [(1337, 1399), (6977, 6985)],
    'tldw_Server_API/app/core/Ingestion_Media_Processing/Audio/Audio_Streaming_Unified.py': [(1285, 1305), (2719, 2730)],
    'tldw_Server_API/app/core/Ingestion_Media_Processing/Audio/Audio_Transcription_Nemo.py': [(309, 324), (374, 438), (456, 472), (487, 498), (539, 560), (588, 604)],
    'tldw_Server_API/app/core/Ingestion_Media_Processing/Audio/stt_provider_adapter.py': [(1075, 1085), (1194, 1247), (1305, 1314), (1381, 1401)],
    'tldw_Server_API/app/core/Ingestion_Media_Processing/Audio/Audio_Transcription_Lib.py': [(1161, 1167), (1237, 1249), (3361, 3380), (3646, 3659)],
    'tldw_Server_API/app/core/Ingestion_Media_Processing/Audio/Diarization_Nemo_Multitalk.py': [(184, 204), (207, 222)],
    'tldw_Server_API/app/core/Ingestion_Media_Processing/Audio/Diarization_Lib.py': [(182, 189)],
    'tldw_Server_API/app/core/config.py': [(759, 770), (4598, 4606)],
}
callers = [evidence(ROOT / path, ranges) for path, ranges in repo_ranges.items()]
previous = json.loads(Path('/private/tmp/task-13013-7-optional-followup/caller-evidence.json').read_text())
prior_checks = [{'file': e['file'], 'matches': digest(Path(e['file'])) == e['sha256']}
                for e in previous if '/Audio/' in e['file'] or '/endpoints/audio/' in e['file'] or e['file'].endswith('/config.py')]
assert all(r['matches'] for r in prior_checks)
(OUT / 'current-callers.json').write_text(json.dumps({'current': callers, 'prior_hash_checks': prior_checks}, indent=2) + '\n')

source_ranges = {
    'nemo-2.0.0-source/nemo/core/classes/modelPT.py': [(453, 477)],
    'nemo-2.0.0-source/nemo/core/classes/common.py': [(471, 534), (749, 778)],
    'nemo-2.0.0-source/nemo/core/connectors/save_restore_connector.py': [(143, 187), (258, 274), (676, 682)],
    'nemo-2.0.0-source/nemo/export/tensorrt_llm.py': [(853, 861)],
    'nemo-2.0.0-source/nemo/export/trt_llm/nemo_ckpt_loader/nemo_file.py': [(95, 106), (178, 197)],
    'nemo-2.0.0-source/nemo/collections/multimodal/speech_llm/modules/common/audio_text_generation_utils.py': [(150, 185)],
    'hydra-1.3.2-source/hydra/_internal/instantiate/_instantiate2.py': [(50, 97), (330, 348)],
    'torch-2.13.0-serialization.py': [(89, 91), (1474, 1513)],
}
(OUT / 'package-source-excerpts.json').write_text(json.dumps([evidence(OUT / path, ranges) for path, ranges in source_ranges.items()], indent=2) + '\n')

conditions = [
    'Current source-python-root graph: uv.lock hydra-core1.3.2 / nemo-toolkit2.0.0 / torch2.13.0 and reviewed first-party callers only.',
    'Fixed NVIDIA model sources and caches preserve integrity; request-controlled audio, text, labels, and speaker settings cannot replace model artifacts or configuration.',
    'Custom RNNT / diarization configuration is supplied by the server operator, not ordinary clients.',
    'Benchmark and golden targets are preinstalled and operator-verified, following STT_Benchmark_User_Guide.md:92-102. Verification includes trusting model code/configuration and associated files, not merely successful model execution or matching a self-computed hash.',
    'Model/config/cache locations and local CLI arguments are not controlled by lower-trust principals. No untrusted or semi-trusted .nemo artifacts are admitted under this disposition.',
    'No environment override disabling weights-only loading, custom unsafe deserializer, or unsafe global allowlist is added. The default PyTorch semantics are a source-graph observation, not a runtime attestation.',
    'No NeMo export, distributed generation/training, checkpoint-resume, arbitrary model-configuration, or adapter-checkpoint workflow is introduced.'
]
mechanisms = [
    {'id': 'hydra-target', 'operation': 'NeMo model YAML -> Serialization.from_config_dict -> hydra.utils.instantiate -> selected callable',
     'current_use': 'Active during model construction; attacker-control prerequisite absent under documented operator-verified target contract and fixed/trusted server selection.',
     'evidence': ['package-source-excerpts.json', 'current-callers.json'],
     'source': 'https://github.com/hydra-ecosystem/hydra/security/advisories/GHSA-2cp2-2r3c-7p7r'},
    {'id': 'torch-checkpoint', 'operation': 'SaveRestoreConnector._load_state_dict_from_disk -> torch.load(model_weights,map_location=cpu)',
     'current_use': 'Active ASR path; no weights_only=False or explicit pickle_module. Exact locked torch defaults to restricted loading. This does not secure the earlier configuration instantiation.',
     'source': 'https://github.com/NVIDIA-NeMo/NeMo/pull/15314'},
    {'id': 'hf-checkpoint-io', 'operation': 'HFCheckpointIO.load_checkpoint trainer.pt with weights_only=False (removed by upstream)',
     'current_use': 'Module and symbol absent in exact2.0.0 wheel, no first-party training/IO caller.',
     'source': 'https://github.com/NVIDIA-NeMo/NeMo/pull/15312'},
    {'id': 'fsdp-common-state', 'operation': 'MegatronStrategy._load_fsdp_dtensor_common_state common.pt unsafe torch loading',
     'current_use': 'Method absent in exact2.0.0 wheel; no first-party FSDP/Megatron training caller.',
     'source': 'https://github.com/NVIDIA-NeMo/NeMo/pull/15227'},
    {'id': 'export-pickle', 'operation': 'TensorRTLLM._load_prompt_tables -> pickle.load(prompt_tables.pkl); later export extra-state tensor -> pickle.loads',
     'current_use': 'prompt_tables.pkl raw pickle is present but no first-party NeMo TensorRT export/deploy caller. Later raw tensor pickle implementation is absent;2.0.0 extra-state uses plain torch.load.',
     'source': 'https://github.com/NVIDIA-NeMo/NeMo/pull/15266'},
    {'id': 'distributed-pickle', 'operation': 'receive_generate_info -> pickle.loads bytes from torch.distributed.broadcast',
     'current_use': 'Present speech-LLM helper but no first-party multimodal speech-LLM/distributed generation caller. ASR inference does not call this helper.',
     'source': 'https://github.com/NVIDIA-NeMo/NeMo/pull/15232'},
    {'id': 'legacy-nlp-pickle', 'operation': 'Legacy NLP dataset caches / retrieval services raw pickle loading removed with legacy NLP in2.6.1',
     'current_use': 'Present legacy package facilities, no first-party NeMo NLP/retrieval/training callers. They do not process current ASR audio inputs.',
     'source': 'https://github.com/NVIDIA-NeMo/NeMo/pull/15258'},
]
specific = {
    'CVE-2026-68508': 'Exact advisory operation directly mapped to the locked callable invocation. Reachable trusted model configuration is intentional; documented verified local targets and server-controlled model selection exclude attacker-controlled callable metadata. Local selection alone is insufficient; model trust is a required condition.',
    'CVE-2025-33245': 'Vendor identifies malicious-data deserialization; NVIDIA Curator additionally associates this pair with ASRModel.from_pretrained checkpoint loading. Conservative February-release union covers ASR torch loading, export raw pickle, distributed raw pickle, FSDP loading, and removed legacy NLP. Active ASR path is weights-only under the exact graph, metadata is trusted under stated conditions; remaining unsafe operations have no current caller.',
    'CVE-2025-33253': 'Vendor explicitly includes persuading a user to open a malicious file, so local operation alone is not an exclusion. The operator-verified-model condition is essential. Conservative February union is inactive for lower-trust input: ASR tensor load is restricted and raw-pickle export/distributed/NLP operations are outside current callers.',
    'CVE-2026-24157': 'Vendor and ZDI identify checkpoint parsing. The conservative2.6.2 fix union covers explicit unsafe torch.load in HF trainer, adapters, checkpoint callbacks and later models plus the required torch minimum. HF module is absent and zero explicit weights_only=False calls exist across exact2.0.0 Python source; active ASR connector uses locked torch2.13 restricted default. No untrusted checkpoint/configuration reaches supported current callers under stated conditions.',
    'CVE-2026-24159': 'Vendor identifies untrusted deserialization without naming a function. Apply the full2.6.2 checkpoint-fix union, not an invented HF-versus-ASR CVE mapping; every observed unsafe override is absent from2.0.0, and active ASR loading inherits restricted torch2.13 behavior. Raw-pickle and callable-config paths are separately covered by the broader conservative union and operator trust conditions.'
}
findings = []
for row in selected:
    findings.append({**row, 'proposed_disposition': 'not-applicable-within-explicit-current-use-scope',
                     'blanket_package_exclusion': False, 'confirmed_new_application_defect': False,
                     'basis': specific[row['vulnerability_id']], 'scope_conditions': conditions,
                     'assessment_method': 'direct mapping' if row['package'] == 'hydra-core' else 'conservative union of observed vendor security-release mechanisms; no invented one-to-one CVE/function mapping',
                     'reassess_on': ['changed package graph/callers', 'unverified custom model use', 'client-controlled model/config/checkpoint route', 'lower-trust model/cache writes', 'new export/training/adapter/resume use', 'weights-only controls disabled']})

acquisitions = {p.name: digest(p) for p in OUT.iterdir() if p.is_file() and p.name not in ('findings.json', 'findings.md')}
result = {
    'reviewed_head': head, 'worktree': str(ROOT), 'method': 'static source, public primary advisory and security-release review; no ML imports or execution',
    'conclusion': 'Five narrowly conditioned source-current-use exclusions supported. No newly confirmed lower-trust application boundary bypass. This is not a claim that arbitrary local .nemo files or the packages are safe.',
    'exact_row_origin': {'file': '/private/tmp/task-13013-7-optional-followup/exact-rows.json', 'sha256': digest(Path('/private/tmp/task-13013-7-optional-followup/exact-rows.json')), 'original_comparison': rows['comparison'], 'original_comparison_sha256': rows['comparison_sha256']},
    'findings': findings, 'mechanism_union': mechanisms,
    'source_bindings': {'uv.lock': digest(ROOT/'uv.lock'), 'pyproject.toml': digest(ROOT/'pyproject.toml'), 'prior_caller_checks': prior_checks},
    'verification': {'nemo_wheel_matches_lock': True, 'hydra_wheel_matches_lock': True, 'nemo_python_files_parsed': package_scan['python_files'], 'parse_errors': [], 'torch_load_call_count': len(torch_calls), 'raw_pickle_call_count': len(pickle_calls), 'explicit_weights_only_false_count': 0, 'no_repo_files_changed_by_this_agent': True},
    'acquisition_file_sha256': acquisitions,
    'limitations': ['Exact one-to-one assignment of four NeMo CVEs to functions is not present in retained NVIDIA CVE records, bulletins or patch PRs. The union is deliberately conservative.', 'No package/runtime compatibility or actual model bytes were qualified; locks and sources do not attest a deployment.', 'Operator model trust and cache integrity are external conditions; the exception evaluator cannot enforce them. Current no-download/hash checks prove identity/locality, not benign configuration.'],
}
source_urls = {
    'torch-2.13.0-serialization.py': 'https://raw.githubusercontent.com/pytorch/pytorch/v2.13.0/torch/serialization.py',
    'hydra-maintainer-advisory.json': 'https://api.github.com/repos/hydra-ecosystem/hydra/security-advisories/GHSA-2cp2-2r3c-7p7r',
    'curator-26.04-release-notes.html': 'https://docs.nvidia.com/nemo/curator/v26.04/about/release-notes',
    'zdi-26-429.html': 'https://www.zerodayinitiative.com/advisories/ZDI-26-429/',
    'compare-2.6.0-2.6.1.json': 'https://api.github.com/repos/NVIDIA-NeMo/NeMo/compare/v2.6.0...v2.6.1',
    'compare-2.6.1-2.6.2.json': 'https://api.github.com/repos/NVIDIA-NeMo/NeMo/compare/v2.6.1...v2.6.2',
}
for version in ('2.6.1', '2.6.2'):
    source_urls['release-' + version + '.json'] = 'https://api.github.com/repos/NVIDIA-NeMo/NeMo/releases/tags/v' + version
for number in ('15227', '15232', '15266', '15312', '15314'):
    source_urls['pr' + number + '-files.json'] = 'https://api.github.com/repos/NVIDIA-NeMo/NeMo/pulls/' + number + '/files'
for cve in ('CVE-2025-33245', 'CVE-2025-33253', 'CVE-2026-24157', 'CVE-2026-24159'):
    bulletin = '5762' if cve.startswith('CVE-2025') else '5800'
    source_urls[cve + '.json'] = 'https://raw.githubusercontent.com/NVIDIA/product-security/main/2026/' + bulletin + '/' + cve + '.json'
result['primary_sources'] = [{'url': url, 'file': str(OUT / name), 'sha256': digest(OUT / name)}
                             for name, url in source_urls.items()]
result['markdown_sha256'] = digest(OUT / 'findings.md')
(OUT/'findings.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result['verification'], indent=2))
