# TASK-13013.7.40 ACL applicability assessment

The three exact TASK39 libacl1 rows support current-default exclusions for
CVE-2026-54369. The reviewed execution paths do not expose the required
privileged pathname ACL operation. No application ACL defect or privilege
escalation has been confirmed, and no application patch is warranted by this
evidence.

Scope is HEAD `073eb4c4a350137736ae529b328dc3ae4202dc8b` and the three exact TASK39
amd64 candidates, with their committed entrypoints and default configuration.
The JSON companion preserves all three raw `libacl1 2.3.2-2+b1` High rows,
image identities, current caller hashes, previous image file-ownership facts,
and the exact Debian coreutils source/binary evidence. Current callers match
all ten TASK38 first-party hashes.

The [maintainer disclosure](https://seclists.org/oss-sec/2026/q2/1050) requires a
privileged call to a pathname ACL API while a less-trusted actor can replace
a component of that pathname. The old APIs retain their behavior; adopting the
new interfaces is a caller responsibility. Debian still marks the installed
Trixie source version affected. This is a usage assessment, not a patched-library
claim.

The final static inventory reads 1,706 app, 1,449 embedding-worker and 1,707
audio-worker ELF files across `/usr`, `/opt` and `/app`, with zero errors.
Each image has exactly seven libacl-linked consumers: `cp`, `mv`, `install`,
`sed`, `tar`, `useradd` and `usermod`. An independent search of undefined
`acl_*` symbols identifies no additional ELF consumer. All seven binaries and
their ancestors are root-owned mode 0755; none has a file capability. Their
bytes are identical across the three candidates. These normal executables do
not give a lower-privileged process elevated credentials on execution.

The account utilities are included in this conclusion. No reviewed runtime
path invokes `useradd` or `usermod`; the app recipe creates fixed `appuser`
during the build, before copying application-owned content. Exact OCI bytes
show both binaries importing `perm_copy_fd` and `attr_copy_fd`. Tagged
[Shadow 4.17.4 source](https://raw.githubusercontent.com/shadow-maint/shadow/4.17.4/lib/copydir.c)
opens source and destination relative to parent descriptors with `O_NOFOLLOW`
and supplies descriptors to `perm_copy_fd`. The exact Debian acl 2.3.2 source
and patch series confirm that this helper uses descriptor ACL operations and
`fchmod`; its path strings are for diagnostics. The source archive hashes
match the Debian `.dsc`; signatures were not independently verified.

The exact Debian coreutils 9.7-3 `cp`, `mv`, and `install` hashes in the fresh
candidates match the previously inspected official payload. The `qcopy_acl`
branch uses libattr copying. These executables do not import libacl getters.
The separate mode-setting branch can still reach pathname `acl_set_file`:
`copy.c:3237-3248` calls `set_owner` for selected existing directories, and
`copy.c:925-970`, `qset-acl.c:40-48`, and `set-permissions.c:487-520` implement
the restrictive ACL change. That utility branch is acknowledged; linkage alone
does not establish its invocation by this application.

| Current operation | Identity and pathname | ACL assessment |
| --- | --- | --- |
| App entrypoint `mv` | UID 10001; adjacent `mktemp` regular `.env` files in the default app-owned config directory | Same-parent rename in the default filesystem; ordinary regular-file fallback uses descriptors. No directory ownership-preserving operation is requested. |
| App diagnostic `sed` | UID 10001; fixed prefix expression and diagnostic input | No in-place editing or ACL-preservation operation. |
| Embedding worker | Root by image default; fixed chunking/embedding/storage/content handlers | No helper/native ACL-tool dispatch. Root is acknowledged, but supplies no missing operation. |
| Audio worker | Root by image default; `audio_transcribe` goes to the STT registry | No helper/native ACL-tool dispatch. Audio input is not itself an ACL operation. |
| Account utilities | Root-owned normal mode-0755 binaries, no file capabilities; no current runtime callers | Descriptor-copy API; fixed appuser creation occurs during build. |
| Production preflight | Root; read-only filesystem/mounts, capabilities dropped, no-new-privileges | Python configuration validation; no ACL utility dispatch. Controls are specific to preflight. |
| Backup/restore/upgrade helpers | Operator-invoked paths; absent from both worker images | No request/job caller. Upgrade needs git state before `cp -a`, and image builds do not retain a git checkout. Other helpers use ordinary file copies, same-parent directory moves, and tar without `--acls`. Privileged operator maintenance remains outside the exclusion. |

MCP shell-named aliases execute the virtual CLI, not a raw host shell. Its
native execution route is `sandbox.run`, and sandbox execution defaults off.
This conclusion does not clear operator-enabled subprocesses, custom MCP
runtimes, or additional host-execution paths.

An unprivileged local process is not dismissed because it can already execute
code. The relevant distinction is whether an ACL-capable executable raises its
credentials or whether a higher-privileged service invokes the vulnerable
operation on its behalf. Application tenants can also be less privileged than
the app service even though that service is not root. The current caller trace
supplies no such tenant-driven ACL invocation. Image ownership does not prove
ownership of operator bind-mounted data/configuration.

Changes to image/caller identity, privileged wrappers, file capabilities,
operator maintenance, `tar --acls`/`TAR_OPTIONS`, configurable native commands,
runtime identity or relevant mounted paths require reassessment. GNU tar's
[1.35 manual](https://www.gnu.org/software/tar/manual/tar.pdf) identifies ACL
preservation as opt-in; this is supporting context rather than a general tar
security claim. Existing deployed environments were not inspected.

No code fix is justified by the current ACL evidence. If a privileged
pathname-ACL operation is introduced, the remedy must address that caller and
its path ownership/descriptor handling; replacing libacl alone does not migrate
the caller. No repository files, image recipes, dependencies or policy records
were changed by this subagent. This subagent executed no native utility, image,
application/model, malformed input or race payload. Parent-supplied diagnostics ran only a read-only Python
ELF parser inside isolated exact candidates; their imposed diagnostic controls
are not production defaults. The full inventory, invocation and source hashes
are retained in the JSON companion.
