"""Benign nested FTS configuration views for TASK40 read-only review.

No malformed pages or native-impact payloads. SQL uses ordinary fixture text.
Run with the worktree/overlay root as argv[1]. Imports only the schema helper.
"""

import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

root = Path(sys.argv[1])
source = root / "tldw_Server_API/app/core/DB_Management/sqlite_schema_helpers.py"
spec = importlib.util.spec_from_file_location("review_sqlite_helpers", source)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
results = []

with tempfile.TemporaryDirectory(prefix="independent-sqlite-review-") as tmp:
    for marker in (False, True):
        db = Path(tmp) / ("marker.db" if marker else "builtin-only.db")
        value = "observed_config(v)" if marker else "v"
        with sqlite3.connect(db) as conn:
            conn.executescript("""
                CREATE TABLE col(crt INTEGER, models TEXT, decks TEXT);
                CREATE TABLE notes(id INTEGER, mid INTEGER, tags TEXT, flds TEXT);
                CREATE TABLE cards(id INTEGER, nid INTEGER);
                CREATE VIRTUAL TABLE seed USING fts5(body);
                INSERT INTO seed VALUES('ordinary text');
                CREATE VIRTUAL TABLE indexed_text USING fts5(body);
                INSERT INTO indexed_text VALUES('ordinary text');
                ALTER TABLE indexed_text_config RENAME TO saved_indexed_config;
            """)
            conn.execute(
                "CREATE VIEW indexed_text_config AS SELECT k, " + value + " AS v FROM saved_indexed_config "
                "WHERE EXISTS(SELECT 1 FROM seed WHERE seed MATCH 'ordinary')"
            )
            conn.executescript("""
                CREATE VIRTUAL TABLE auxiliary USING fts5(body);
                ALTER TABLE auxiliary_config RENAME TO saved_config;
                CREATE VIEW auxiliary_config AS SELECT k, v FROM saved_config
                    WHERE EXISTS(SELECT 1 FROM indexed_text WHERE indexed_text MATCH 'ordinary');
            """)
        for trusted_schema in (True, False):
            events = []
            evaluated = []
            conn = sqlite3.connect(db)
            try:
                if not trusted_schema:
                    conn.execute("PRAGMA trusted_schema=OFF")
                if marker:
                    conn.create_function("observed_config", 1, lambda value: evaluated.append(value) or value)
                guard = helper.sqlite_import_read_authorizer({"col", "notes", "cards"})

                def traced_guard(action, table, column, database, source):
                    decision = guard(action, table, column, database, source)
                    if action == sqlite3.SQLITE_READ or source:
                        events.append({"event": "authorize", "action": action, "table": table, "column": column,
                                       "database": database, "source": source, "decision": decision})
                    return decision

                conn.set_authorizer(traced_guard)
                conn.set_trace_callback(lambda sql: events.append({"event": "trace", "sql": sql}))
                tables = sorted(helper.ordinary_sqlite_table_names(conn))
                ordinary = conn.execute("SELECT crt, models, decks FROM col").fetchall()
                traces = [event["sql"] for event in events if event["event"] == "trace"]
                results.append({"marker": marker, "trusted_schema": trusted_schema,
                                "tables": tables, "ordinary_rows": ordinary, "evaluated": evaluated,
                                "fts_index_searches": [sql for sql in traces if "seed_idx" in sql],
                                "events": events})
            finally:
                conn.close()

print(json.dumps({"sqlite_version": sqlite3.sqlite_version,
                  "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "cases": results}, indent=2))
