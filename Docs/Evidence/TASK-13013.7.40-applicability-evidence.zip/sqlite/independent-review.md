# TASK-13013.7.40 independent review and authorized correction

The initial review found one blocking defect in the proposed read-authorizer-only
fix. A nested FTS5 configuration view executes a benign MATCH query while SQLite
skips authorizer callbacks during virtual-table initialization. All required
import tables remain ordinary. The outer read is denied only after the inner
configuration view has searched `seed_idx` and, in a separate marker variant,
evaluated the value `4`. This uses valid SQLite SQL and ordinary text, without
malformed pages or any native-corruption payload.

The initial finding targets the trust setup now at
`tldw_Server_API/app/core/DB_Management/OpenWebUI_DB.py:95-101` and
`tldw_Server_API/app/core/Flashcards/apkg_importer.py:287-293`, together with
`sqlite_schema_helpers.py:14-37`. The callback alone is not the required boundary.
The first single-view evidence remains useful but is insufficient to qualify
the authorizer-only implementation.

Parent authorized this reviewer to implement the correction under the existing
TASK40 Backlog task. Both owned importer connections now execute
`PRAGMA trusted_schema = OFF` and verify the readback is zero before metadata.
Failure, an ignored setting, or an unavailable readback rejects the import and
closes the connection. The existing persistent read authorizer is retained.
The generic metadata helper does not alter caller trust settings or authorizers.
The URI unit test now uses a real SQLite connection behind its path spy.

Two real-importer nested-view regressions use built-in SQL only, so disabling a
custom marker function cannot falsely satisfy them. Six additional cases cover
setting errors, ignored changes and unavailable readback in both importers.
All eight tests failed before the production correction. The complete focused
set subsequently passed: **93 passed, zero warnings**, with zero attempted or
loaded model imports. Ordinary, STRICT, WITHOUT ROWID, case-insensitive APKG,
hydration JSON helpers, caller authorizers and connection cleanup remain covered.

The first broader green attempt had 91 passes and two existing exporter tests
rejected scratch database paths outside the application's approved temporary
root. Moving the test base directory under the normal macOS temporary root
resolved that harness issue; no application path validation was changed.

The updated portable probe exercises the actual owned importer setup in ten
cases: nine OpenWebUI combinations (ordinary/STRICT/WITHOUT ROWID with no,
single or nested configuration views) and nested APKG. The host run on SQLite
3.49.1 has zero marker evaluations, zero nested FTS index searches and the
expected imported rows. Parent separately reproduced the standalone nested
bypass and trusted-schema correction on exact-candidate SQLite 3.46.1.
Final actual-importer candidate overlay/rebuild verification belongs to parent.

Ruff, AST/compilation and whitespace checks pass. Direct Black API checks with
project configuration find no new formatting edits; six baseline edits in
three files remain unchanged. Bandit finds zero production findings or scan
errors. Test scanning reports 53 B101 assertions only and no scan errors.

This correction prevents the demonstrated uploaded FTS-view/MATCH execution
path. It does not promise zero internal constructor SQL, validate arbitrary
malformed SQLite pages, rewrite existing image digests, or change administrator
whole-database restoration. No package installation, Docker/network operation,
model workload, unrelated worktree inspection, repository commit or publication
was performed by this reviewer.

Because the reviewer implemented the correction after finding the bypass, this
record is not an independent approval of the final patch. Parent has arranged
a separate final review. The JSON companion binds this record to the reviewed
source and retained diagnostics.
