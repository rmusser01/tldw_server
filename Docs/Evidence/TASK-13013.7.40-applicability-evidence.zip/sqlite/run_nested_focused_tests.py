"""Run focused SQLite import tests while preventing model-library imports."""
import importlib.abc
import json
from pathlib import Path
import sys

ROOT=Path('/Users/macbook-dev/Documents/GitHub/tldw_server2/.worktrees/task-13013-7-supply-chain-design')
OUT=Path('/private/tmp/task-13013-7-40-sqlite')
blocked={'torch','torchaudio','torchvision','transformers','sentence_transformers','nemo','nltk','tensorflow','jax','onnxruntime','faster_whisper','whisper'}
attempts=[]
class RejectModelImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.',1)[0] in blocked:
            attempts.append(fullname)
            raise ImportError('Model import disabled for focused SQLite tests')
        return None
sys.meta_path.insert(0, RejectModelImports())
sys.path.insert(0,str(ROOT))
import pytest
try:
    status=pytest.main(sys.argv[1:])
finally:
    (OUT/'nested-focused-import-audit.json').write_text(json.dumps({'blocked_import_attempts':attempts,'loaded_model_modules':sorted(name for name in sys.modules if name.split('.',1)[0] in blocked)},indent=2)+'\n')
raise SystemExit(status)
