# TASK-13013.7.40: finish unrestricted advisory applicability

## Stage 1: Bind remaining findings and advisory prerequisites
**Goal**: Use TASK39's exact candidates/reports and current locked source.
**Success Criteria**: Per-advisory upstream prerequisites for 17 native and five optional source rows; preserve all prior exclusions.
**Tests**: Verify input hashes and primary source mappings.
**Status**: Complete

## Stage 2: Complete caller and native-consumer traces
**Goal**: Establish supported actor/input/operation paths rather than infer impact from versions.
**Success Criteria**: Concrete per-advisory decision; benign tests for uncertain behavior, including SQLite metadata initialization.
**Tests**: Read-only ELF inventory, well-formed SQLite metadata trace, static source/permission assessment.
**Status**: Complete

## Stage 3: Handle evidence-supported changes
**Goal**: Fix confirmed defects or apply exact supported current-use exclusions.
**Success Criteria**: Minimal reviewed changes and no speculative suppression or unrelated work.
**Tests**: Failing regression first, focused compatibility/policy tests, lint/compile/Bandit.
**Status**: Complete

## Stage 4: Verify and retain final decisions
**Goal**: Preserve evidence and finish reviewable changes locally.
**Success Criteria**: Independent review, complete report replays, current Backlog and local commit; actual restrictions remain explicit.
**Tests**: Identity/hash checks, prior-policy preservation, relevant regression suite.
**Status**: Complete
