"""Retain TASK40 reviewed evidence and verify the archive without extraction."""
from pathlib import Path
import hashlib
import json
import zipfile

REPO = Path('/Users/macbook-dev/Documents/GitHub/tldw_server2/.worktrees/task-13013-7-supply-chain-design')
PREFIX = '/private/tmp/task-13013-7-40-'
ROOTS = {label: Path(PREFIX + label) for label in ('native', 'acl', 'optional', 'native-secondary', 'sqlite')}
OUTPUT = REPO / 'Docs/Evidence'
ARCHIVE = OUTPUT / 'TASK-13013.7.40-applicability-evidence.zip'
COMPANION = OUTPUT / 'TASK-13013.7.40-applicability.json'
TEXT_SUFFIXES = {'.json', '.md', '.log', '.txt', '.py', '.sh', '.c', '.h', '.rs', '.patch', '.html', '.dsc', '.stderr', '.ses'}
files = {}

def retain(path, member):
    path = Path(path)
    if path.is_file() and path.suffix in TEXT_SUFFIXES and path.stat().st_size <= 2_000_000:
        files[member] = path

for label, root in ROOTS.items():
    for path in root.iterdir():
        retain(path, label + '/' + path.name)
for path in (ROOTS['optional'] / 'policy-implementation').iterdir():
    retain(path, 'optional/policy-implementation/' + path.name)
for stage in ('first-authorizer-overlay', 'overlay'):
    for path in (ROOTS['sqlite'] / stage).rglob('*.py'):
        retain(path, 'sqlite/' + stage + '/' + str(path.relative_to(ROOTS['sqlite'] / stage)))

# Add explicitly source-bound text, not package code discovered by execution.
def source_paths(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {'file', 'path'} and isinstance(item, str) and item.startswith('/private/tmp/'):
                yield Path(item)
            if isinstance(key, str) and key.startswith('/private/tmp/'):
                yield Path(key)
            yield from source_paths(item)
    elif isinstance(value, list):
        for item in value:
            yield from source_paths(item)

assessments = {
    'acl': ROOTS['acl'] / 'assessment.json',
    'optional': ROOTS['optional'] / 'findings.json',
    'audio_tiff': ROOTS['native-secondary'] / 'assessment.json',
    'xml': ROOTS['native'] / 'xml-assessment.json',
    'sqlite_initial': ROOTS['sqlite'] / 'sqlite-applicability.json',
}
for p in assessments.values():
    for path in source_paths(json.loads(p.read_text())):
        if str(path).startswith(PREFIX):
            retain(path, 'bound-sources/' + str(path).removeprefix(PREFIX))
        elif str(path).startswith('/private/tmp/task-13013-7-next-native/xml-tiff-rng-sources/'):
            retain(path, 'bound-sources/xml-tiff/' + path.name)
retain('/private/tmp/task-13013-7-next-native/xml-tiff-rng-packages/xml-read-memory-calls.json', 'bound-sources/previous-native-parser-options.json')

current_code = [
    '.github/supply-chain/vulnerability-exceptions.json',
    'Helper_Scripts/Supply_Chain/dependency_review.py',
    'tldw_Server_API/app/core/DB_Management/sqlite_schema_helpers.py',
    'tldw_Server_API/app/core/DB_Management/OpenWebUI_DB.py',
    'tldw_Server_API/app/core/Flashcards/apkg_importer.py',
    'tldw_Server_API/tests/Chatbooks/test_openwebui_db_schema_security.py',
    'tldw_Server_API/tests/Chatbooks/test_openwebui_db_import_adapter.py',
    'tldw_Server_API/tests/Flashcards/test_apkg_schema_security.py',
    'tldw_Server_API/tests/Supply_Chain/test_remaining_applicability_dispositions.py',
    'tldw_Server_API/tests/Supply_Chain/test_fresh_mount_dispositions.py',
    'tldw_Server_API/tests/Supply_Chain/test_lightning_applicability_policy.py',
    'tldw_Server_API/tests/Supply_Chain/test_os_package_dispositions.py',
    'Docs/Design/TASK-13013.7.40-sqlite-metadata-validation.md',
    'Docs/Evidence/TASK-13013.7.40-applicability.md',
]
for rel in current_code:
    retain(REPO / rel, 'current-source/' + rel)

manifest = []
with zipfile.ZipFile(ARCHIVE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for member, path in sorted(files.items()):
        raw = path.read_bytes()
        # Fixed ZIP packaging timestamp only; source dates remain in raw records.
        info = zipfile.ZipInfo(member, date_time=(2026, 9, 10, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, raw)
        manifest.append({'member': member, 'original_path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == {r['member'] for r in manifest}
    for row in manifest:
        assert hashlib.sha256(archive.read(row['member'])).hexdigest() == row['sha256']

policy = json.loads((REPO / current_code[0]).read_text())
new_records = [r for r in policy['exceptions'] if r['id'].startswith('TASK-13013.7.40-')]
assert len(new_records) == 14 and len(policy['exceptions']) == 336
report = {
    'task': 'TASK-13013.7.40',
    'baseline_commit': '073eb4c4a350137736ae529b328dc3ae4202dc8b',
    'scope': 'Local SQLite importer correction, completed unrestricted caller assessment, fourteen exact exclusions, retained report replay. No release/deployment qualification claim.',
    'confirmed_defect': 'OpenWebUI/APKG pre-validation FTS query execution, including nested configuration views that bypass the initial read authorizer.',
    'final_correction': 'Disable and verify trusted_schema before metadata on owned connections; retain fixed source-read authorizers and fail-closed cleanup.',
    'historical_evidence_notice': 'sqlite/sqlite-applicability.*, *-fixed-import-probe.*, first-authorizer-overlay and initial GREEN logs describe the superseded authorizer-only attempt. The nested review, final-independent-review, candidate-final-verification and nested-pytest-green-final records are authoritative for the final fix.',
    'new_exclusions': new_records,
    'policy_verification': json.loads((ROOTS['optional'] / 'policy-implementation/verification.json').read_text()),
    'report_replay': json.loads((ROOTS['optional'] / 'policy-implementation/replay-results.json').read_text()),
    'historical_report_replay': json.loads((ROOTS['native'] / 'old-report-replay.json').read_text()),
    'candidate_sqlite_verification': json.loads((ROOTS['sqlite'] / 'candidate-final-verification.json').read_text()),
    'sqlite_implementation_verification': json.loads((ROOTS['sqlite'] / 'independent-review.json').read_text()),
    'final_reviews': {
        name: json.loads(path.read_text())
        for name, path in {
            'sqlite': ROOTS['sqlite'] / 'final-independent-review.json',
            'policy': ROOTS['optional'] / 'policy-implementation/independent-policy-review.json',
        }.items()
        if path.is_file()
    },
    'assessments': {name: {'original_path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in assessments.items()},
    'final_source_sha256': {rel: hashlib.sha256((REPO / rel).read_bytes()).hexdigest() for rel in current_code},
    'remaining_gate_rows': {'ffmpeg_family': 306, 'sqlite': 6, 'xml6653': 2, 'total': 314},
    'remaining_limits': [
        'FFmpeg source/history and NLTK installed-wheel/model-path qualification remain platform-restricted; no prohibited retry or success claim.',
        'Two XML6653 OS DOM-consumer rows remain unexcluded; native source feature presence is not represented as a confirmed remote application exploit.',
        'Six SQLite rows are not blanket-excluded. Exact candidate overlays verify the corrected source, not a changed installed image; malicious administrator-selected raw database restoration remains distinct.',
        'The fourteen current-use conditions are explicit assumptions for reviewed defaults; the policy evaluator does not enforce deployment trust, ownership, loaders or configuration.',
    ],
    'archive': {'path': str(ARCHIVE.relative_to(REPO)), 'bytes': ARCHIVE.stat().st_size, 'sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(), 'members': manifest},
    'verification': {
        'archive_crc_and_all_member_hashes_checked': True,
        'final_sqlite_tests_and_probes_blocked_model_imports': True,
        'optional_package_review_text_only': True,
        'review_method_exception': json.loads((ROOTS['optional'] / 'policy-implementation/independent-policy-method-exception.json').read_text()),
        'broad_review_suite_not_used_for_runtime_or_model_qualification': True,
        'no_malformed_database_or_media_payload_in_sqlite_fix_verification': True,
        'no_push_merge_publish_or_remote_dispatch': True,
    },
}
COMPANION.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'archive_members': len(manifest), 'archive_bytes': ARCHIVE.stat().st_size, 'archive_sha256': report['archive']['sha256'], 'companion_sha256': hashlib.sha256(COMPANION.read_bytes()).hexdigest()}))
