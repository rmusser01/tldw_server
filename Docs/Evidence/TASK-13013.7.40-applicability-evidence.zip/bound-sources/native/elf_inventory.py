"""Read ELF dependency/symbol metadata and file permissions without executing it."""

import hashlib
import json
import os
import stat
import struct
from pathlib import Path


def metadata(path):
    with path.open("rb") as stream:
        header = stream.read(64)
        if header[:4] != b"\x7fELF":
            return None
        if header[4:6] != b"\x02\x01":
            raise ValueError("ELF is not 64-bit little-endian")
        fields = struct.unpack_from("<HHIQQQIHHHHHH", header, 16)
        shoff, size, count = fields[5], fields[10], fields[11]
        if size != 64 or not count:
            raise ValueError("ELF section layout unavailable")
        stream.seek(shoff)
        table = stream.read(size * count)
        sections = [
            struct.unpack_from("<IIQQQQIIQQ", table, i * size) for i in range(count)
        ]

        def section_bytes(index):
            row = sections[index]
            stream.seek(row[4])
            return stream.read(row[5])

        def name_at(data, offset):
            return data[offset : data.index(b"\0", offset)].decode("utf-8")

        needed, symbols = [], []
        for i, row in enumerate(sections):
            if row[1] not in (6, 11):
                continue
            strings = section_bytes(row[6])
            raw = section_bytes(i)
            if row[1] == 6:
                for pos in range(0, len(raw), row[9]):
                    tag, value = struct.unpack_from("<qQ", raw, pos)
                    if tag == 1:
                        needed.append(name_at(strings, value))
            else:
                for pos in range(0, len(raw), row[9]):
                    name, _, _, shndx, _, _ = struct.unpack_from("<IBBHQQ", raw, pos)
                    if shndx == 0 and name:
                        symbol = name_at(strings, name)
                        if symbol.startswith(
                            ("acl_", "xml", "sf_", "TIFF", "gdk_pixbuf_")
                        ):
                            symbols.append(symbol)
        return {
            "needed": sorted(needed),
            "selected_undefined_symbols": sorted(set(symbols)),
        }


def permissions(path):
    info = path.stat()
    return {
        "uid": info.st_uid,
        "gid": info.st_gid,
        "mode": oct(stat.S_IMODE(info.st_mode)),
    }


results, errors = {}, []
for root in ("/usr", "/opt", "/app"):
    for directory, _, names in os.walk(root, followlinks=False):
        for name in names:
            path = Path(directory) / name
            if path.is_symlink() or not path.is_file():
                continue
            try:
                row = metadata(path)
                if row is None:
                    continue
                selected = row["selected_undefined_symbols"] or any(
                    n.startswith(
                        ("libacl", "libxml2", "libtiff", "libsndfile", "libgdk_pixbuf")
                    )
                    for n in row["needed"]
                )
                row["permissions"] = permissions(path)
                if selected:
                    row["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
                    row["ancestor_permissions"] = {
                        str(p): permissions(p) for p in path.parents
                    }
                    attrs = os.listxattr(path)
                    row["file_capability_hex"] = (
                        os.getxattr(path, "security.capability").hex()
                        if "security.capability" in attrs
                        else None
                    )
                results[str(path)] = row
            except (
                OSError,
                ValueError,
                struct.error,
                IndexError,
                ZeroDivisionError,
            ) as error:
                errors.append(
                    {
                        "path": str(path),
                        "type": type(error).__name__,
                        "error": str(error),
                    }
                )

packages = {}
for paragraph in Path("/var/lib/dpkg/status").read_text().split("\n\n"):
    fields = dict(
        line.split(": ", 1)
        for line in paragraph.splitlines()
        if ": " in line and not line[0].isspace()
    )
    if "Package" in fields:
        packages[fields["Package"]] = {
            key: fields.get(key) for key in ("Version", "Architecture", "Status")
        }
for listing in Path("/var/lib/dpkg/info").glob("*.list"):
    package = listing.name.removesuffix(".list").split(":", 1)[0]
    for path in listing.read_text().splitlines():
        if path in results:
            results[path]["package"] = {"name": package, **packages.get(package, {})}
print(
    json.dumps(
        {"roots": ["/usr", "/opt", "/app"], "elfs": results, "errors": errors},
        indent=2,
        sort_keys=True,
    )
)
