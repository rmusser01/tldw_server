# TASK-13013.7.40 — SQLite applicability and import fix

The investigation confirmed a specific missing execution boundary and fixed it
in source. `PRAGMA main.table_list` can evaluate an unrelated FTS5 configuration
view before the ordinary-table helper filters its rows. A harmless view executed
an FTS5 MATCH while the required APKG/OpenWebUI names were still ordinary tables.
The host probe observed SQLite 3.49.1; the parent independently replayed the same
probe in the exact TASK39 candidate and observed SQLite 3.46.1 with the same
marker value `[4]`. No malformed database pages or memory-corruption payload
were created or executed. The defect is demonstrated source-query execution;
CVE memory corruption is not claimed as reproduced.

The reviewed baseline is worktree HEAD
`073eb4c4a350137736ae529b328dc3ae4202dc8b`. The JSON companion records 40 baseline
source/evidence hashes, exact scanner rows/report identities, line references,
primary-source citations, diagnostic outputs, and implementation hashes.

## What the advisories actually require

SQLite groups CVE-2026-11822 and CVE-2026-11824 as the same FTS5 problem, fixed
in SQLite 3.53.2. Its arbitrary-SQL description includes defensive mode disabled
and FTS5 enabled. [SQLite vendor CVE table](https://www.sqlite.org/cves.html).

Debian separately describes the precrafted-file route: malformed FTS5 index data
must be processed by a MATCH query. CVE-2026-11822 covers leaf seeking and
continuation handling; CVE-2026-11824 overlaps the continuation-length underflow.
Debian explicitly identifies `3.46.1-7+deb13u1` as affected. Its minor/no-DSA label
is maintenance prioritization, not an application exemption.
[Debian 11822](https://security-tracker.debian.org/tracker/CVE-2026-11822),
[Debian 11824](https://security-tracker.debian.org/tracker/CVE-2026-11824).

Defensive mode prevents SQL operations that deliberately corrupt the database;
it does not validate pages supplied in an existing file. Opening a database
read-only also does not stop FTS search-time native reads.
[SQLite connection configuration](https://sqlite.org/c3ref/c_dbconfig_defensive.html).

TASK39 supplies the actual native binding: all three images use OS SQLite
3.46.1 with FTS5 enabled. This is stronger than a version-only scanner match.
Upstream 3.46.1 source connects schema initialization to index configuration
loading, and connects term searches to leaf seeking and position-list iteration.
[FTS5 initialization](https://raw.githubusercontent.com/sqlite/sqlite/version-3.46.1/ext/fts5/fts5_main.c),
[FTS5 index operations](https://raw.githubusercontent.com/sqlite/sqlite/version-3.46.1/ext/fts5/fts5_index.c).

## Source fix and verification

Both importers now install a persistent read authorizer on their own fresh
source connection before inspecting metadata. Reads are limited to the fixed
source table names and main-schema metadata; reads originating in uploaded
views/triggers are denied. OpenWebUI also permits the built-in `json_each`
reads used for hydration. FTS5 shadow reads remain denied even for a persisted
virtual table named `json_each`. The generic table-list helper does not replace
or clear an existing caller's authorizer. APKG closes its owned connection when
policy installation fails.

The red run reproduced four marker-evaluation failures. Separate regressions
reproduced a persisted `json_each` FTS read and a connection leak on failed
policy installation. After the fix, **85 focused checks pass** with
`--noconftest --import-mode=importlib -c /dev/null`. The import audit records zero
model import attempts and zero loaded model modules. Cases include ordinary,
STRICT and WITHOUT ROWID source tables; case-insensitive APKG names; unrelated
benign FTS objects; required view/virtual rejection; ordinary row import; repeated
hydration validation; and JSON-backed attachment queries.

Ruff, AST/compilation and whitespace checks pass. Bandit reports zero production
findings and zero scan errors; 49 test findings are B101 assertions only. The
Black CLI could not start its multiprocessing manager in the sandbox, including
with one worker. Direct Black API checking uses the project configuration and
confirms zero new formatting edits. Six pre-existing formatter edits across
three touched files are unchanged. No unrelated production refactor was made.

A portable seven-case importer diagnostic also passes on the host. The parent
owns exact-candidate overlay verification. An overlay probe does not change the
existing image digest or make its old source fixed; no new image was built here.

## Input-path dispositions for both CVEs

| Path | Actual operation and conclusion |
| --- | --- |
| APKG user upload | Native metadata then fixed `col`/`notes`/`cards` SELECTs. Baseline metadata executes the demonstrated FTS view; the new source read policy blocks its reads. Both advisories' FTS execution prerequisite is prevented on this guarded import path. |
| OpenWebUI user upload | Read-only database, native metadata, fixed source SELECTs. Same demonstrated baseline defect and same guarded-path conclusion. |
| OpenWebUI local-root hydration | Uses the same guarded connection for `file`/`chat_file` validation and SELECTs. Attachment bytes are copied to per-user media storage, not installed as live databases. |
| Admin bundle restoration | Parent router requires administrator role. Supplied manifest/file hashes establish consistency, not trusted origin. Restoration executes busy-timeout/checkpoint and the SQLite backup API, not MATCH itself. It preserves pages; later flashcard and Media searches explicitly execute MATCH. Malicious admin-selected database applicability is supported, without asserting an authorization defect or reproduced native impact. |
| Existing backup or migration rollback | Selects a confined existing backup; no raw database upload occurs here. Normal server-created backups do not acquire malformed FTS pages from logical text. Operator replacement/selection of external backup bytes brings the same privileged restore condition. |
| SQLite-to-PostgreSQL CLI migration | Operator explicitly selects a SQLite path. Metadata and row queries can initialize virtual tables or evaluate source views. This intentional operator-selected source is outside the import fix; normal first-party databases do not meet the malicious-page prerequisite. |
| Native chatbook / logical record imports | Reconstruct JSON/text records through server DB methods. Copied artifacts do not replace live database files. No raw SQLite page ingestion in the reviewed path. |
| Text2SQL | Single read-only SELECT/WITH on the dependency-resolved user Media DB, with target ACL. It cannot create arbitrary FTS shadow bytes. A previously malicious admin-restored database remains within the privileged restore scenario. |
| Browser cookie utility | Copies a fixed local browser profile and issues bound cookie SELECTs; no application caller of this utility was found. The web API uses a separate cookie manager. Malicious replacement requires local profile authority, not ordinary HTTP cookie values. |
| Other internal database openers | Use configured server/owner database state rather than SQLite upload bytes. Direct operator filesystem/configuration replacement is a distinct database trust condition. |

## Six exact scanner rows

Each listed image has one High row for each CVE in `libsqlite3-0`
`3.46.1-7+deb13u1`, PURL
`pkg:deb/debian/libsqlite3-0@3.46.1-7%2Bdeb13u1?arch=amd64&distro=debian-13.6`.

| Role | Exact image digest | Disposition |
| --- | --- | --- |
| App | `sha256:2043d986c0057b7652927bc15c4fc3d9104bdb1ed70f39f5ad241cf9f4d8161f` | Baseline source has confirmed pre-validation FTS execution. Source fix does not alter this existing image. Admin raw-restore applicability is separate. No blanket image exception proposed. |
| Embedding worker | `sha256:a1d4844fbde5a2cb544c3348453972736a291ac8a5c8bdc80591a92f9a77a70e` | Default Redis stages accept IDs/logical content and read/update Media records; no import/MATCH interface. Ordinary job inputs with server-created schemas do not meet either advisory prerequisite. Arbitrary admin-restored Media views/triggers are outside that scoped conclusion. |
| Audio worker | `sha256:34a467a6ce0a0dc5044feaf92eec7a78177cc43061021b177d3741db5a47bc23` | Default worker handles only transcription jobs and predefined Jobs/AuthNZ quota SQL; no SQLite upload/MATCH interface. Ordinary job inputs with server-created schemas do not meet either advisory prerequisite. Arbitrary admin-restored AuthNZ triggers and changed commands are outside that scoped conclusion. |

No policy exception, commit, Backlog change, deployment, publication, or merge
was made by this agent. The concrete import fix and role-specific conclusions
must not be turned into a claim that arbitrary SQLite database restoration is
safe or that an administrator already has native-code authority.
