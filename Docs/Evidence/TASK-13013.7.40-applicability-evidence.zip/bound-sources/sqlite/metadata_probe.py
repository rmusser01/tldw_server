"""Tiny valid SQLite schemas only: observe whether metadata evaluates FTS views."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path('/Users/macbook-dev/Documents/GitHub/tldw_server2/.worktrees/task-13013-7-supply-chain-design')
helper = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'tldw_Server_API/app/core/DB_Management/sqlite_schema_helpers.py'
spec = importlib.util.spec_from_file_location('scoped_sqlite_schema_helpers', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

out = {'sqlite_version': sqlite3.sqlite_version, 'python_version': sys.version, 'helper_sha256': hashlib.sha256(helper.read_bytes()).hexdigest(), 'cases': []}
for selected in ('baseline', 'auxiliary_config_view'):
    source = sqlite3.connect(':memory:')
    source.executescript('''
        CREATE TABLE col(crt INTEGER, models TEXT, decks TEXT);
        CREATE TABLE notes(id INTEGER, mid INTEGER, tags TEXT, flds TEXT);
        CREATE TABLE cards(id INTEGER, nid INTEGER, did INTEGER, ord INTEGER);
        CREATE VIRTUAL TABLE seed USING fts5(body);
        INSERT INTO seed(body) VALUES ('alpha beta');
        CREATE VIRTUAL TABLE auxiliary USING fts5(body);
    ''')
    if selected == 'auxiliary_config_view':
        source.executescript('''
            CREATE TABLE saved_config(k PRIMARY KEY, v) WITHOUT ROWID;
            INSERT INTO saved_config SELECT k, v FROM auxiliary_config;
            DROP TABLE auxiliary_config;
            CREATE VIEW auxiliary_config AS
              SELECT k, observed_config(v) AS v FROM saved_config
              WHERE EXISTS (SELECT 1 FROM seed WHERE seed MATCH 'alpha');
        ''')
    source.commit()
    target = sqlite3.connect(':memory:')
    source.backup(target)
    traces, authorizer, evaluated = [], [], []
    target.set_trace_callback(traces.append)
    def observe(value):
        evaluated.append(value)
        return value
    target.create_function('observed_config', 1, observe)
    def authorize(action, arg1, arg2, database, context):
        authorizer.append({'action': action, 'arg1': arg1, 'arg2': arg2, 'database': database, 'context': context})
        return sqlite3.SQLITE_OK
    target.set_authorizer(authorize)
    try:
        tables = sorted(module.ordinary_sqlite_table_names(target))
        result = {'tables': tables, 'error': None}
    except Exception as exc:
        result = {'tables': None, 'error': f'{type(exc).__name__}: {exc}'}
    out['cases'].append({'case': selected, 'result': result, 'traces': traces, 'authorizer': authorizer, 'evaluated_config_values': evaluated})
    target.close()
    source.close()
print(json.dumps(out, indent=2))
