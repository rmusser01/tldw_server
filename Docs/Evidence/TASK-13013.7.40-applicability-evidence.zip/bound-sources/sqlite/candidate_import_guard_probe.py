"""Validate importer source-read guards with tiny well-formed SQLite fixtures."""
import importlib.abc
import importlib.util
import io
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import zipfile
import hashlib

ROOT=Path(sys.argv[1])
sys.path.insert(0,str(ROOT))
blocked={'torch','torchaudio','torchvision','transformers','sentence_transformers','nemo','nltk','tensorflow','jax','onnxruntime','faster_whisper','whisper'}
attempts=[]
class RejectModelImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.',1)[0] in blocked:
            attempts.append(fullname)
            raise ImportError('Model imports disabled in SQLite guard probe')
        return None
sys.meta_path.insert(0,RejectModelImports())
files={}
def load(name,path):
    path=ROOT/path
    files[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod
helper=load('tldw_Server_API.app.core.DB_Management.sqlite_schema_helpers','tldw_Server_API/app/core/DB_Management/sqlite_schema_helpers.py')
reader=load('tldw_Server_API.app.core.DB_Management.OpenWebUI_DB','tldw_Server_API/app/core/DB_Management/OpenWebUI_DB.py')
apkg=load('tldw_Server_API.app.core.Flashcards.apkg_importer','tldw_Server_API/app/core/Flashcards/apkg_importer.py')
original_connect=sqlite3.connect
observed=[]
traces=[]
def observed_connect(*args,**kwargs):
    conn=original_connect(*args,**kwargs)
    conn.create_function('observed_config',1,lambda value: observed.append(value) or value)
    conn.set_trace_callback(traces.append)
    return conn

def extra(conn,view):
    conn.executescript('''
      CREATE VIRTUAL TABLE indexed_text USING fts5(body);
      INSERT INTO indexed_text VALUES('ordinary text');
      CREATE VIRTUAL TABLE auxiliary USING fts5(body);
    ''')
    if view:
        conn.executescript('''
          ALTER TABLE auxiliary_config RENAME TO saved_config;
          CREATE VIEW auxiliary_config AS
            SELECT k, observed_config(v) AS v FROM saved_config
            WHERE EXISTS(SELECT 1 FROM indexed_text WHERE indexed_text MATCH 'ordinary');
        ''')

out={'sqlite_version':sqlite3.sqlite_version,'source_sha256':files,'cases':[]}
with tempfile.TemporaryDirectory(prefix='sqlite-guard-') as tmp:
    for suffix in ('','STRICT','WITHOUT ROWID'):
        for view in (False,True):
            path=Path(tmp)/'openwebui.db'
            if path.exists(): path.unlink()
            with original_connect(path) as conn:
                schemas=reader.REQUIRED_SCHEMA|reader.HYDRATION_FILE_SCHEMA|reader.HYDRATION_CHAT_FILE_SCHEMA
                for name,columns in schemas.items():
                    defs=', '.join('"'+c+'" TEXT'+(' PRIMARY KEY' if c=='id' else '') for c in sorted(columns))
                    conn.execute('CREATE TABLE "'+name+'" ('+defs+') '+suffix)
                conn.executescript('''
                  INSERT INTO user(id,name) VALUES('u1','Example');
                  INSERT INTO file(id,user_id,filename) VALUES('f1','u1','example.txt');
                  INSERT INTO chat_file(id,chat_id,file_id,user_id) VALUES('cf1','c1','f1','u1');
                ''')
                extra(conn,view)
            observed.clear(); traces.clear(); sqlite3.connect=observed_connect
            try:
                with reader.open_validated_openwebui_db(path) as conn:
                    reader.validate_openwebui_file_schema(conn)
                    users=[row['id'] for row in reader.load_openwebui_users(conn)]
                    files_read=[row['filename'] for row in reader.load_openwebui_file_rows_for_ids(conn,['f1'],'u1')]
                    links=[row['file_id'] for row in reader.load_openwebui_chat_file_rows_for_chats(conn,['c1'],'u1')]
                result={'kind':'openwebui','suffix':suffix,'config_view':view,'evaluated':list(observed),'users':users,'files':files_read,'links':links,'traces':list(traces)}
                assert result['evaluated']==[] and users==['u1'] and files_read==['example.txt'] and links==['f1']
                out['cases'].append(result)
            finally:
                sqlite3.connect=original_connect
    path=Path(tmp)/'collection.anki2'
    with original_connect(path) as conn:
        conn.executescript('''
          CREATE TABLE col(crt INTEGER, models TEXT, decks TEXT);
          INSERT INTO col VALUES(0,'{"1":{"name":"basic","type":0}}','{"1":{"name":"Example"}}');
          CREATE TABLE notes(id INTEGER, mid INTEGER, tags TEXT, flds TEXT);
          CREATE TABLE cards(id INTEGER, nid INTEGER, did INTEGER, ord INTEGER, type INTEGER, queue INTEGER, due INTEGER, ivl INTEGER, factor INTEGER, reps INTEGER, lapses INTEGER);
          INSERT INTO cards VALUES(1,1,1,0,0,0,0,0,2500,0,0);
        ''')
        conn.execute('INSERT INTO notes VALUES(1,1,?,?)',('', 'Question\x1fAnswer'))
        extra(conn,True)
    archive=io.BytesIO()
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('collection.anki2',path.read_bytes())
    observed.clear(); traces.clear(); sqlite3.connect=observed_connect
    try:
        rows,errors=apkg.import_rows_from_apkg_bytes(archive.getvalue(),max_notes=10,max_field_length=8192)
        result={'kind':'apkg','evaluated':list(observed),'fronts':[r['front'] for r in rows],'errors':errors,'traces':list(traces)}
        assert not observed and result['fronts']==['Question'] and errors==[]
        out['cases'].append(result)
    finally:
        sqlite3.connect=original_connect
out['blocked_import_attempts']=attempts
out['loaded_model_modules']=sorted(name for name in sys.modules if name.split('.',1)[0] in blocked)
assert not attempts and not out['loaded_model_modules']
print(json.dumps(out,indent=2))
