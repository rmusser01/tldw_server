# TASK-13013.7.40 — OS libsndfile and TIFF current-use assessment

The four exact OS scanner rows below support current-default-use exclusions. The libraries remain installed and source-affected. No current first-party application defect or necessary application patch was established. These conclusions apply to the verified candidates and reviewed defaults; the conditions below require reassessment.

| Candidate | Package | CVE | Proposed disposition |
|---|---|---|---|
| app | libsndfile1 1.2.2-2+deb13u1 | CVE-2026-37555 | Not affected in current default use |
| app | libtiff6 4.7.0-3+deb13u3 | CVE-2026-36849 | Not affected in current default use |
| audio-worker | libsndfile1 1.2.2-2+deb13u1 | CVE-2026-37555 | Not affected in current default use |
| audio-worker | libtiff6 4.7.0-3+deb13u3 | CVE-2026-36849 | Not affected in current default use |

App subject: `sha256:2043d986c0057b7652927bc15c4fc3d9104bdb1ed70f39f5ad241cf9f4d8161f`. Audio worker subject: `sha256:34a467a6ce0a0dc5044feaf92eec7a78177cc43061021b177d3741db5a47bc23`. Exact package PURLs, report hashes, source versions and selected ELF hashes are in [assessment.json](assessment.json). The source worktree remained at `073eb4c4a350137736ae529b328dc3ae4202dc8b`.

OS libsndfile has one direct installed consumer, PulseAudio `libpulsecommon-17.0.so`. Full inventories cover 1,706 app, 1,449 worker and 1,707 audio-worker ELFs across `/usr`, `/opt`, and `/app`, with zero errors. None imports `sf_open`, `sf_open_fd`, or `sf_open_virtual`. The worker has neither affected OS package.

Pulse17 source separates its installed client path from file decoding. `src/meson.build:68` includes shared `sndfile-util.c` helpers, which consume existing SNDFILE handles or enumerate formats. The actual file-open callers belong to daemon `sound-file.c`/`sound-file-stream.c` or `pacat`/`pactl`; those native consumers are absent. All client `src/pulse/*.c` files contain no `sf_*` or `pa_sndfile*` calls. `simple.c:206–211,272–346` connects playback/record streams and transfers sample bytes through stream APIs. Therefore installed SDL2/libavdevice/libsphinxad client links do not feed a WAV file into the OS IMA-ADPCM decoder. This conclusion uses Pulse source and exact ELF inventory; no FFmpeg source was inspected. [Pulse17 source](https://sources.debian.org/src/pulseaudio/17.0%2Bdfsg1-2/src/pulse/simple.c)

The advertised libsndfile trigger is multiplication overflow in the WAV IMA-ADPCM open/close calculations. Debian currently links an unrelated SDS byterate patch as its fix. The correct PR1123 head, `cdadf9a65fdc1f28da9d235eb443d5f5e57010d2`, casts the two IMA products and is retained separately. Neither a differing bundled library nor this attribution correction clears the vulnerability. TASK39 maps ordinary SoundFile to its bundled library; its separate trigger/size-bound assessment belongs to the parent TASK40 evidence. [Upstream notice](https://www.openwall.com/lists/oss-security/2026/04/30/7), [correct source patch](https://github.com/libsndfile/libsndfile/commit/cdadf9a65fdc1f28da9d235eb443d5f5e57010d2)

OS TIFF has one direct installed consumer, GdkPixbuf’s TIFF loader. That plugin really imports `TIFFClientOpen` and `TIFFReadRGBAImageOriented`; the parser is present. Its sole installed nonplugin GdkPixbuf consumer is librsvg2.60. Exact librsvg imports only pixel access/allocation APIs. Its `document.rs:592–655` decodes image bytes through Rust `image::ImageReader` and builds a `SharedImageSurface`, including the guessed-format route. It does not invoke a GdkPixbuf file/stream loader. The other installed GdkPixbuf plugins do not establish an ordinary caller. [Exact Debian librsvg source](https://sources.debian.org/src/librsvg/2.60.0%2Bdfsg-1/rsvg/src/document.rs)

Current first-party Python has no GI/GdkPixbuf/direct TIFF binding or direct Pillow internal decoder bypass. The checked source roots are app, first-party scripts, helpers and MCP source. Native-loader matches concern eSpeak discovery and optional curl-cffi HTTP transport. Exact SBOMs have no PyGObject/python-GI component, and full ELF inventories contain no GI extension. Ordinary image paths use Pillow, whose extension links its bundled TIFF. These are current-use observations, not claims about arbitrary injected code.

Pillow12.3’s ordinary open/load route calls Python `_setup` before native libtiff decoding. The source-derived maximum effective SamplesPerPixel is six. There is an exception: separate planes with unspecified extra components can discard those extras before the check, so raw SamplesPerPixel is not universally capped. [Pillow TIFF setup](https://github.com/python-pillow/Pillow/blob/12.3.0/src/PIL/TiffImagePlugin.py)

That exception does not restore the reported raw-SamplesPerPixel buffer multiplier: separate-plane strip and tile sizes omit it. Pillow reads output planes individually and compares buffers with its output layout. Its YCbCr RGBA path selects libtiff’s separate path for separate rawSPP>1; `gtStripSeparate` allocates three/four single-plane strips. It **does** call `_TIFFReadEncodedStripAndAllocBuffer`; absence of that helper is not the rationale. This is a source-only qualification of the advertised large-SPP allocation amplification, not a guarantee against every TIFF resource-exhaustion case or alternate decoder API. [Pillow decoder](https://github.com/python-pillow/Pillow/blob/12.3.0/src/libImaging/TiffDecode.c), [libtiff4.7.1 strip sizing](https://gitlab.com/libtiff/libtiff/-/blob/v4.7.1/libtiff/tif_strip.c), [RGBA decoder](https://gitlab.com/libtiff/libtiff/-/blob/v4.7.1/libtiff/tif_getimage.c)

The TIFF advisory concerns large SamplesPerPixel allocation. Do not inherit the unrelated PixarLog CVE paragraph appended to the scanner description. The retained upstream fix adds compression-ratio allocation bounds. [Upstream notice](https://www.openwall.com/lists/oss-security/2026/06/17/1), [fix](https://gitlab.com/libtiff/libtiff/-/commit/eedba405d3695b52faae65994c5904f228eca0bf)

Reassess when any candidate digest, package, binding, entrypoint or native loader path changes, especially:

- Adding/running Pulse daemon, pacat/pactl, libpulsecore consumer or OS sndfile native/CFFI/ctypes decoder requires reassessment.
- Removing/failing the bundled SoundFile library and using OS fallback requires reassessment.
- Adding GI/PyGObject, GdkPixbuf loader/file APIs, other GdkPixbuf consumers or dynamic TIFF bindings requires reassessment.
- Changing Pillow setup/plane validation or calling its internal native decoder directly requires reassessment.

Validation: all four report subjects match the candidate identities; native scans have zero errors; source archive SHA256 values match the Debian DSC; source hashes are retained; the effective Pillow maximum was computed from its AST without importing Pillow. DSC signatures were not verified. No repository edits, image rebuilds, native/application/model execution or malformed input were performed.
