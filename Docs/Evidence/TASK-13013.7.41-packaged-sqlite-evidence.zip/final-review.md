# TASK-13013.7.41 final bounded evidence review

No remaining actionable findings in the reviewed packaging evidence. The retained results support the stated local packaged-importer correction. They do not establish whole-release admission, native SQLite patching, or model/application qualification.

## Earlier findings reconciled

1. **Layer digest validation: resolved.** `verify_oci.py` validates the complete `sha256:[a-f0-9]{64}` layer digest before lookup. Retained controls show the valid case accepted and wrong-algorithm/trailing-junk cases rejected. Independent JSON inspection also validated every current layer descriptor against its content-addressed retained blob.
2. **Historical report binding: resolved.** `evaluate_candidates.py` now reads the committed TASK39 archive, verifies the archive hash and each report's byte count/hash, and records the exact archive/member/hash in every candidate result. Both prior evidence files are source-bound. Independent ZIP inspection reproduced the unchanged finding-identity/multiplicity comparison for all three reports.
3. **Missing review retention: resolved.** `retain_evidence.py` checks for both named reviews before any output writes. Its retained negative control records rejection when `final-review.md` is absent. This review provides the final required record; final archive creation remains parent-owned.

## Integrity checks performed

Read-only standard-library hashing and JSON/ZIP inspection passed for the completed evidence. The inspection code and 191 reviewed-file hash records are retained as `final-review-inspect.py` and `final-review-hashes.json`. No repository code or policy module was imported by the inspection.

- The source archive hash matches `source-bindings.json`. All 14 bound repository files and their clean-build-context copies match, including unchanged recipes, dependency inputs, the 336-record policy, evaluator, production importers, and historical baseline evidence. The diagnostic hash matches the retained TASK40 probe exactly.
- All 61 current OCI layout files were independently rehashed: app 25, worker 18, audio-worker 18. Inventory membership, blob content addresses, descriptor sizes, selected linux/amd64 manifests, configurations, revision labels and BuildKit metadata agree. Loaded Docker identities and recorded probe/scan invocations identify the same subjects. Current TASK41 cleanup records match the verified inventories and original archive hash/size records.
- All four actual probe outputs contain the exact ten-case matrix: nine OpenWebUI combinations and one nested-view APKG case. All 40 cases retain correct imported/hydration data, no observed view markers or MATCH index-search traces, and no guarded model imports. The three source hashes and expected installed paths match in every run; SQLite is 3.46.1 and all stderr files are empty. The runner mounts only the diagnostic, overrides application startup, and uses isolated Python with the selected in-image source root.
- All six full JSON/CycloneDX reports bind to the expected subjects/configurations. The JSON reports' rootfs identities agree with OCI configuration. The pinned scanner inspection matches the recorded digest. Current database bytes and metadata match the pre-scan hashes; every scan completed less than seven hours after the recorded database update.
- Every reported High/Critical row appears exactly once in the retained blocking/excepted decision partitions, with the same target and package/advisory identity. Excepted identities match the unchanged active component policy; blocking identities have no matching active exception. Historical all-severity identities and multiplicities are unchanged. All existing scoped image exceptions match.

| Candidate | Probe cases | Raw all-severity rows | Blocking High/Critical rows | Excepted rows |
| --- | ---: | ---: | ---: | ---: |
| App | 20 | 635 | 156 | 78 |
| Embedding worker | 10 | 180 | 2 | 57 |
| Audio worker | 10 | 635 | 156 | 78 |

The retained build/load/scan records and log endings agree with successful completion. The documented focused-test result and warning distinction agree with the retained logs. Bandit reports retain the eight classified diagnostic-only findings without scan errors. Three SQLite rows for each of CVE-2026-11822 and CVE-2026-11824, plus two XML6653 rows, remain blocking as documented.

## Scope and remaining handoff

The current evidence Markdown accurately describes the inspected scope and limits. Existing findings were reconciled against corrected helper code and actual outputs. No Docker operation, new probe, model/application workload, broad test, FFmpeg/NLTK qualification, other-worktree inspection, or source/history investigation was performed by this review. Prior deleted tar payloads cannot be independently rehashed after deletion; current TASK41 complete OCI layouts were rehashed, and historical cleanup assertions remain explicitly ledger evidence.

The final evidence ZIP does not yet exist. Parent must create it with the reviewed retainer, confirm its CRC/member SHA256 bindings and companion archive hash, and perform Backlog/commit finalization. This report approves the bounded evidence method and existing outputs, not those subsequent actions as already completed.
