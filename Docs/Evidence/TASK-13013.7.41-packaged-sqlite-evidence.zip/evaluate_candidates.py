"""Bind local candidate scans and bounded import checks to retained OCI identities."""

from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from collections import Counter
from dataclasses import asdict
from datetime import date, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).parent
REPO = Path(sys.argv[1])
sys.path.insert(0, str(REPO))
from Helper_Scripts.Supply_Chain.exception_policy import (
    evaluate_trivy_report,
    load_policy,
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def read(name: str) -> dict:
    return json.loads((ROOT / name).read_text())


def signature(report: dict) -> Counter:
    return Counter(
        (
            row["VulnerabilityID"],
            row["PkgIdentifier"]["PURL"],
            row["InstalledVersion"],
            row["Severity"],
        )
        for result in report["Results"]
        for row in result.get("Vulnerabilities") or []
    )


def main() -> None:
    bindings = read("source-bindings.json")
    for path, sha in bindings["files"].items():
        require(
            hashlib.sha256((REPO / path).read_bytes()).hexdigest() == sha,
            "Source changed: " + path,
        )
    policy = load_policy(
        REPO / ".github/supply-chain/vulnerability-exceptions.json",
        today=date(2026, 9, 10),
    )
    database = read("scanner/db/metadata.json")
    updated = datetime.fromisoformat(database["UpdatedAt"].replace("Z", "+00:00"))
    results = []
    for name in ("app", "worker", "audio-worker"):
        identity = read(name + "-identity.json")
        inspected = read(name + "-image-inspect.json")
        require(len(inspected) == 1, "Expected one loaded image")
        require(
            inspected[0]["Id"]
            in {identity["subject_digest"], identity["config_digest"]},
            "Loaded image identity mismatch",
        )
        require(
            inspected[0]["Config"]["Labels"]["org.opencontainers.image.revision"]
            == bindings["source_commit"],
            "Loaded revision mismatch",
        )
        checks = [name + "-packaged-sqlite.json"]
        if name == "app":
            checks.append("app-source-sqlite.json")
        for check in checks:
            probe = read(check)
            require(len(probe["cases"]) == 10, "Missing SQLite checks")
            require(
                not probe["blocked_import_attempts"]
                and not probe["loaded_model_modules"],
                "Unexpected model import",
            )
            require(
                (ROOT / check.replace(".json", ".stderr")).stat().st_size == 0,
                "Probe stderr not empty",
            )
            expected_root = (
                "/app/"
                if check == "app-source-sqlite.json"
                else "/opt/tldw-venv/lib/python3."
                + ("12" if name == "app" else "11")
                + "/site-packages/"
            )
            expected_sources = {
                expected_root + path: sha
                for path, sha in bindings["files"].items()
                if path.endswith(
                    ("OpenWebUI_DB.py", "sqlite_schema_helpers.py", "apkg_importer.py")
                )
            }
            require(
                probe["source_sha256"] == expected_sources, "Installed source mismatch"
            )
            for case in probe["cases"]:
                require(
                    not case["evaluated"] and not case["fts_index_searches"],
                    "Unexpected view or MATCH execution",
                )
                if case["kind"] == "openwebui":
                    require(
                        case["users"] == ["u1"]
                        and case["files"] == ["example.txt"]
                        and case["links"] == ["f1"],
                        "Import data mismatch",
                    )
                else:
                    require(
                        case["fronts"] == ["Question"] and case["errors"] == [],
                        "APKG data mismatch",
                    )
        report = read("scan-output/trivy-image-" + name + ".json")
        sbom = read("scan-output/sbom-image-" + name + ".cdx.json")
        require(
            report["ArtifactName"] == "/input@" + identity["subject_digest"],
            "Report subject mismatch",
        )
        require(
            report["Metadata"]["ImageID"] == identity["config_digest"],
            "Report config mismatch",
        )
        require(
            report["Metadata"]["ImageConfig"]["config"]["Labels"][
                "org.opencontainers.image.revision"
            ]
            == bindings["source_commit"],
            "Report source mismatch",
        )
        require(
            sbom["metadata"]["component"]["name"] == report["ArtifactName"],
            "SBOM subject mismatch",
        )
        props = sbom["metadata"]["component"]["properties"]
        require(
            [p["value"] for p in props if p["name"] == "aquasecurity:trivy:ImageID"]
            == [identity["config_digest"]],
            "SBOM config mismatch",
        )
        for event in ("started", "finished"):
            scanned = datetime.fromisoformat(
                (ROOT / f"{name}-scan-{event}.txt")
                .read_text()
                .strip()
                .replace("Z", "+00:00")
            )
            require(
                timedelta() <= scanned - updated <= timedelta(hours=24),
                "Scanner database age exceeded",
            )
        decision = evaluate_trivy_report(
            report, component="image-" + name, policy=policy, today=date(2026, 9, 10)
        )
        (ROOT / (name + "-decision.json")).write_text(
            json.dumps(asdict(decision), indent=2) + "\n"
        )
        prior_evidence = json.loads(
            (REPO / "Docs/Evidence/TASK-13013.7.39-fresh-candidates.json").read_text()
        )["raw_reports"]
        prior_archive = REPO / prior_evidence["archive"]
        require(
            hashlib.sha256(prior_archive.read_bytes()).hexdigest()
            == prior_evidence["sha256"],
            "Baseline archive hash mismatch",
        )
        prior_member = "trivy-image-" + name + ".json"
        with zipfile.ZipFile(prior_archive) as archive:
            prior_bytes = archive.read(prior_member)
        prior_record = prior_evidence["members"][prior_member]
        require(
            len(prior_bytes) == prior_record["bytes"]
            and hashlib.sha256(prior_bytes).hexdigest() == prior_record["sha256"],
            "Baseline report hash mismatch",
        )
        baseline = json.loads(prior_bytes)
        before, after = signature(baseline), signature(report)
        added, removed = after - before, before - after
        results.append(
            {
                "name": name,
                "identity": identity["subject_digest"],
                "config_digest": identity["config_digest"],
                "sqlite_version": read(checks[0])["sqlite_version"],
                "probe_cases": 10 * len(checks),
                "all_severity_rows": sum(after.values()),
                "blocking_scanner_rows": len(decision.blocking),
                "excepted_rows": len(decision.excepted),
                "unmatched_exception_ids": decision.unmatched_exception_ids,
                "baseline": {
                    "archive": prior_evidence["archive"],
                    "archive_sha256": prior_evidence["sha256"],
                    "member": prior_member,
                    **prior_record,
                },
                "added_scanner_rows": [
                    {"finding": list(k), "count": v} for k, v in added.items()
                ],
                "removed_scanner_rows": [
                    {"finding": list(k), "count": v} for k, v in removed.items()
                ],
            }
        )
    (ROOT / "candidate-verification.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
