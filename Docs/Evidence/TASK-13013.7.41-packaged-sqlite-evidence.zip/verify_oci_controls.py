"""Exercise the one-off verifier with tiny synthetic OCI descriptor controls."""

import hashlib
import importlib.util
import io
import json
import tarfile
import tempfile
from pathlib import Path

BASE = Path(__file__).parent
spec = importlib.util.spec_from_file_location("verify_oci", BASE / "verify_oci.py")
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
results = []
for variant in ("valid", "wrong-algorithm", "trailing-junk"):
    with tempfile.TemporaryDirectory(prefix="oci-control-", dir=BASE) as tmp:
        root = Path(tmp)
        payloads = {}

        def add(data, payloads=payloads):
            raw = json.dumps(data).encode()
            digest = hashlib.sha256(raw).hexdigest()
            payloads["blobs/sha256/" + digest] = raw
            return {"digest": "sha256:" + digest, "size": len(raw)}

        layer = add({"fixture": "benign data"})
        if variant == "wrong-algorithm":
            layer["digest"] = layer["digest"].replace("sha256:", "sha512:")
        elif variant == "trailing-junk":
            layer["digest"] += ":junk"
        config = add(
            {
                "architecture": "amd64",
                "os": "linux",
                "config": {
                    "Labels": {"org.opencontainers.image.revision": verifier.REVISION}
                },
            }
        )
        manifest = add({"config": config, "layers": [layer]})
        manifest["platform"] = {"architecture": "amd64", "os": "linux"}
        subject = add({"manifests": [manifest]})
        payloads["index.json"] = json.dumps({"manifests": [subject]}).encode()
        payloads["oci-layout"] = b'{"imageLayoutVersion":"1.0.0"}'
        with tarfile.open(root / "app.oci.tar", "w") as archive:
            for path, data in payloads.items():
                member = tarfile.TarInfo(path)
                member.size = len(data)
                archive.addfile(member, io.BytesIO(data))
        (root / "app-build-metadata.json").write_text(
            json.dumps({"containerimage.digest": subject["digest"]})
        )
        verifier.ROOT = root
        try:
            verifier.main("app")
            if variant != "valid":
                raise RuntimeError("Invalid descriptor was accepted: " + variant)
            results.append({"variant": variant, "outcome": "accepted"})
        except ValueError as error:
            if variant == "valid" or str(error) != "Invalid layer digest":
                raise
            results.append(
                {"variant": variant, "outcome": "rejected", "error": str(error)}
            )
(BASE / "oci-verifier-controls.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results))
