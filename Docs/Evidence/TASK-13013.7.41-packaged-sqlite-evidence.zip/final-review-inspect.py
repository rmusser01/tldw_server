"""Read-only, standard-library inspection of the completed packaging evidence."""
import hashlib
import json
import re
import zipfile
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path('/private/tmp/task-13013-7-41-images')
REPO = Path('/Users/macbook-dev/Documents/GitHub/tldw_server2/.worktrees/task-13013-7-supply-chain-design')
hashes = {}


def check(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    path = Path(path)
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    hashes[str(path)] = {'sha256': value, 'bytes': path.stat().st_size}
    return value


def read(path):
    path = Path(path)
    digest(path)
    return json.loads(path.read_text())


def report_rows(report):
    return [(row, result['Target']) for result in report['Results'] for row in result.get('Vulnerabilities') or []]


def row_key(row):
    return row['VulnerabilityID'], row['PkgIdentifier']['PURL'], row['InstalledVersion'], row['Severity']


def decision_key(row):
    return row['vulnerability_id'], row['purl'], row['installed_version'], row['severity']


def stamp(path):
    digest(path)
    return datetime.fromisoformat(path.read_text().strip().replace('Z', '+00:00'))


bindings = read(ROOT / 'source-bindings.json')
check(digest(ROOT / 'source-08d232ef8c.tar') == bindings['source_archive_sha256'], 'Source archive hash')
for name, expected in bindings['files'].items():
    check(digest(REPO / name) == expected, 'Repository binding: ' + name)
    check(digest(ROOT / 'context' / name) == expected, 'Clean context binding: ' + name)
check(digest(ROOT / 'packaged_sqlite_probe.py') == '4715ff76afd1d16e921f7c4b6ecf919dc3352f9e6f97a6a959cbf4d7b221fad4', 'TASK40 probe identity')
verification = read(ROOT / 'candidate-verification.json')
check([item['name'] for item in verification] == ['app', 'worker', 'audio-worker'], 'Candidate set')
runs = read(ROOT / 'run-records.json')
invocations = read(ROOT / 'runtime-and-scan-invocations.json')
builds = read(ROOT / 'build-invocations.json')
cleanup = read(ROOT / 'duplicate-export-cleanup.json')
policy = read(REPO / '.github/supply-chain/vulnerability-exceptions.json')['exceptions']
check(len(policy) == 336, 'Policy record count')
prior = read(REPO / 'Docs/Evidence/TASK-13013.7.39-fresh-candidates.json')['raw_reports']
check(digest(REPO / prior['archive']) == prior['sha256'], 'Historical archive hash')
scanner = read(ROOT / 'scanner-image-inspect.json')[0]
check('ghcr.io/aquasecurity/trivy@sha256:62b1e65e8869bc4b4c6aa4fa2b21595256c7c2f6018a9d9ad61caf87187c1969' in scanner['RepoDigests'], 'Pinned scanner identity')
database = read(ROOT / 'scanner/db/metadata.json')
updated = datetime.fromisoformat(database['UpdatedAt'].replace('Z', '+00:00'))
digest(ROOT / 'scanner-db-before.sha256')
for line in (ROOT / 'scanner-db-before.sha256').read_text().splitlines():
    expected, name = line.split(maxsplit=1)
    path = Path(name.strip())
    check(path.parent == ROOT / 'scanner/db', 'DB hash scope')
    check(digest(path) == expected, 'Scanner DB unchanged: ' + str(path))
summaries = []
for item in verification:
    name = item['name']
    identity = read(ROOT / (name + '-identity.json'))
    layout = ROOT / (name + '-layout')
    inventory = identity['verified_archive_members']
    actual = {str(path.relative_to(layout)) for path in layout.rglob('*') if path.is_file()}
    check(actual == set(inventory), name + ' layout inventory')
    for member, record in inventory.items():
        path = layout / member
        check(path.is_file() and not path.is_symlink(), name + ' file type')
        check(digest(path) == record['sha256'] and path.stat().st_size == record['bytes'], name + ' OCI member ' + member)
        if member.startswith('blobs/sha256/'):
            check(path.name == record['sha256'], name + ' OCI content address')

    def blob(descriptor):
        value = descriptor['digest']
        check(re.fullmatch(r'sha256:[a-f0-9]{64}', value) is not None, name + ' descriptor digest')
        path = layout / 'blobs/sha256' / value.split(':')[1]
        check(path.stat().st_size == descriptor['size'], name + ' descriptor size')
        return json.loads(path.read_text())

    index = read(layout / 'index.json')
    check(len(index['manifests']) == 1, name + ' single OCI subject')
    subject_descriptor = index['manifests'][0]
    check(subject_descriptor['digest'] == identity['subject_digest'] == item['identity'], name + ' subject binding')
    subject = blob(subject_descriptor)
    platform_descriptors = [entry for entry in subject['manifests'] if entry.get('platform') == {'architecture': 'amd64', 'os': 'linux'}]
    check(len(platform_descriptors) == 1, name + ' selected platform')
    check(platform_descriptors[0]['digest'] == identity['platform_manifest_digest'], name + ' platform binding')
    manifest = blob(platform_descriptors[0])
    config = blob(manifest['config'])
    check(manifest['config']['digest'] == identity['config_digest'] == item['config_digest'], name + ' config binding')
    check(config['architecture'] == 'amd64' and config['os'] == 'linux', name + ' config platform')
    check(config['config']['Labels']['org.opencontainers.image.revision'] == bindings['source_commit'] == identity['source_commit'], name + ' source revision')
    for child_descriptor in subject['manifests']:
        child = blob(child_descriptor)
        blob(child['config'])
        for layer in child['layers']:
            check(re.fullmatch(r'sha256:[a-f0-9]{64}', layer['digest']) is not None, name + ' layer digest')
            entry = inventory['blobs/sha256/' + layer['digest'].split(':')[1]]
            check(entry['bytes'] == layer['size'], name + ' layer size')
    metadata_path = ROOT / (name + '-build-metadata.json')
    metadata = read(metadata_path)
    check(metadata['containerimage.digest'] == identity['subject_digest'], name + ' BuildKit subject')
    check(hashes[str(metadata_path)]['sha256'] == identity['build_metadata_sha256'], name + ' BuildKit metadata hash')
    inspected = read(ROOT / (name + '-image-inspect.json'))
    check(len(inspected) == 1 and inspected[0]['Id'] == identity['subject_digest'], name + ' loaded subject')
    check(inspected[0]['Config']['Labels']['org.opencontainers.image.revision'] == bindings['source_commit'], name + ' loaded revision')
    invocation = next(row for row in invocations if row['component'] == name)
    check(invocation['subject_digest'] == identity['subject_digest'], name + ' invocation subject')
    for runner in ('probe_runner', 'scan_runner'):
        check(invocation[runner][-2:] == [name, identity['subject_digest']], name + ' runner args')
    check(set(runs[name]) == {'build_exit_code', 'oci_verifier_exit_code', 'load_and_packaged_probe_exit_code', 'json_and_cyclonedx_scan_exit_code'} and all(code == 0 for code in runs[name].values()), name + ' execution status')
    ledger = next(row for row in cleanup if row['removed_duplicate'] == str(ROOT / (name + '.oci.tar')))
    check(ledger['archive_sha256'] == identity['archive_sha256'] and ledger['archive_bytes'] == identity['archive_bytes'] and ledger['matched_file_members'] == len(inventory), name + ' cleanup binding')
    cases = 0
    probe_files = [name + '-packaged-sqlite.json'] + (['app-source-sqlite.json'] if name == 'app' else [])
    for filename in probe_files:
        probe = read(ROOT / filename)
        check(probe['sqlite_version'] == '3.46.1' and not probe['blocked_import_attempts'] and not probe['loaded_model_modules'], name + ' interpreter/model guard')
        root = '/app/' if filename == 'app-source-sqlite.json' else '/opt/tldw-venv/lib/python3.' + ('12' if name == 'app' else '11') + '/site-packages/'
        expected_sources = {root + path: sha for path, sha in bindings['files'].items() if path.endswith(('OpenWebUI_DB.py', 'sqlite_schema_helpers.py', 'apkg_importer.py'))}
        check(probe['source_sha256'] == expected_sources, filename + ' source binding')
        expected_cases = Counter([('openwebui', suffix, view) for suffix in ('', 'STRICT', 'WITHOUT ROWID') for view in (False, True, 'nested')] + [('apkg', None, 'nested')])
        check(Counter((case['kind'], case.get('suffix'), case['config_view']) for case in probe['cases']) == expected_cases, filename + ' full case coverage')
        for case in probe['cases']:
            check(not case['evaluated'] and not case['fts_index_searches'] and not any('seed_idx' in trace for trace in case['traces']), filename + ' view/MATCH behavior')
            if case['kind'] == 'openwebui':
                check(case['users'] == ['u1'] and case['files'] == ['example.txt'] and case['links'] == ['f1'], filename + ' hydration rows')
            else:
                check(case['fronts'] == ['Question'] and case['errors'] == [], filename + ' APKG rows')
        cases += len(probe['cases'])
        stderr = ROOT / filename.replace('.json', '.stderr')
        digest(stderr)
        check(stderr.stat().st_size == 0, filename + ' stderr')
    check(cases == item['probe_cases'], name + ' case summary')
    report = read(ROOT / ('scan-output/trivy-image-' + name + '.json'))
    sbom = read(ROOT / ('scan-output/sbom-image-' + name + '.cdx.json'))
    check(report['ArtifactName'] == '/input@' + identity['subject_digest'], name + ' report subject')
    check(report['Metadata']['ImageID'] == identity['config_digest'], name + ' report config')
    check(report['Metadata']['ImageConfig']['rootfs'] == config['rootfs'], name + ' report rootfs')
    check(report['Metadata']['ImageConfig']['config']['Labels']['org.opencontainers.image.revision'] == bindings['source_commit'], name + ' report revision')
    component = sbom['metadata']['component']
    check(component['name'] == report['ArtifactName'], name + ' SBOM subject')
    check([prop['value'] for prop in component['properties'] if prop['name'] == 'aquasecurity:trivy:ImageID'] == [identity['config_digest']], name + ' SBOM config')
    started = stamp(ROOT / (name + '-scan-started.txt'))
    finished = stamp(ROOT / (name + '-scan-finished.txt'))
    check(updated <= started <= finished <= updated + timedelta(hours=24), name + ' database freshness')
    baseline = item['baseline']
    check(baseline['archive_sha256'] == prior['sha256'] and baseline['archive'] == prior['archive'], name + ' baseline archive')
    check(prior['members'][baseline['member']] == {key: baseline[key] for key in ('sha256', 'bytes')}, name + ' baseline member record')
    with zipfile.ZipFile(REPO / baseline['archive']) as archive:
        raw = archive.read(baseline['member'])
    check(len(raw) == baseline['bytes'] and hashlib.sha256(raw).hexdigest() == baseline['sha256'], name + ' baseline member hash')
    previous = Counter(row_key(row) for row, target in report_rows(json.loads(raw)))
    current = Counter(row_key(row) for row, target in report_rows(report))
    check(previous == current and not item['added_scanner_rows'] and not item['removed_scanner_rows'], name + ' unchanged all-severity identities')
    decision = read(ROOT / (name + '-decision.json'))
    high = Counter((*row_key(row), target) for row, target in report_rows(report) if row['Severity'] in ('HIGH', 'CRITICAL'))
    partition = Counter((*decision_key(row), row['target']) for category in ('blocking', 'excepted') for row in decision[category])
    check(high == partition, name + ' decision covers every High/Critical row exactly')
    active = [record for record in policy if record['component'] == 'image-' + name and record['created_on'] <= '2026-09-10' <= record['expires_on']]
    allowed = {decision_key(record) for record in active}
    check(all(decision_key(row) in allowed for row in decision['excepted']), name + ' exception identity')
    check(all(decision_key(row) not in allowed for row in decision['blocking']), name + ' blocking identity')
    check(not decision['unmatched_exception_ids'] and not item['unmatched_exception_ids'], name + ' unmatched exceptions')
    check(len(decision['blocking']) == item['blocking_scanner_rows'] and len(decision['excepted']) == item['excepted_rows'] and sum(current.values()) == item['all_severity_rows'], name + ' summary counts')
    summaries.append({'name': name, 'subject': identity['subject_digest'], 'verified_oci_files': len(inventory), 'verified_oci_bytes': sum(record['bytes'] for record in inventory.values()), 'probe_cases': cases, 'all_severity_rows': sum(current.values()), 'blocking_rows': len(decision['blocking']), 'excepted_rows': len(decision['excepted']), 'database_age_at_scan_finish_seconds': (finished - updated).total_seconds()})
    print(json.dumps(summaries[-1]), flush=True)

for path in ROOT.iterdir():
    if path.is_file() and path.suffix in {'.py', '.sh', '.json', '.txt', '.log', '.md', '.stderr', '.sha256'}:
        digest(path)
digest(REPO / 'Docs/Evidence/TASK-13013.7.41-packaged-sqlite.md')
result = {'task': 'TASK-13013.7.41', 'status': 'all integrity checks passed', 'inspection': 'Read-only standard-library hashing/JSON/ZIP inspection; no image execution or policy module imports.', 'candidates': summaries, 'reviewed_files': hashes}
(ROOT / 'final-review-hashes.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'hashed_files': len(hashes), 'total_probe_cases': sum(item['probe_cases'] for item in summaries)}), flush=True)
