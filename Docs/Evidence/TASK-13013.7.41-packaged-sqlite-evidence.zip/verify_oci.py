"""Verify and unpack task-owned OCI archives without executing image contents."""

from __future__ import annotations

import hashlib
import json
import re
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).parent
REVISION = "08d232ef8cad33fbc2b27b6daa6006a6d3cd426a"


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def main(name: str) -> None:
    require(name in {"app", "worker", "audio-worker"}, "Unexpected image")
    archive = ROOT / f"{name}.oci.tar"
    layout = ROOT / f"{name}-layout"
    layout.mkdir(exist_ok=False)
    inventory = {}
    with tarfile.open(archive) as source:
        for member in source:
            if member.isdir():
                require(
                    member.name in {"blobs", "blobs/sha256"}, "Unexpected directory"
                )
                continue
            require(member.isfile(), "Unexpected archive entry type")
            require(
                member.name in {"index.json", "oci-layout"}
                or bool(re.fullmatch(r"blobs/sha256/[a-f0-9]{64}", member.name)),
                "Unexpected archive path",
            )
            require(member.name not in inventory, "Duplicate archive entry")
            target = layout / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            with source.extractfile(member) as payload, target.open(
                "xb"
            ) as destination:
                while data := payload.read(1024 * 1024):
                    digest.update(data)
                    destination.write(data)
            actual = digest.hexdigest()
            if member.name.startswith("blobs/"):
                require(actual == target.name, "OCI blob hash mismatch")
            inventory[member.name] = {"sha256": actual, "bytes": target.stat().st_size}
            require(target.stat().st_size == member.size, "Archive size mismatch")
    require(
        json.loads((layout / "oci-layout").read_text())
        == {"imageLayoutVersion": "1.0.0"},
        "Unexpected OCI layout",
    )

    def blob(descriptor: dict) -> dict:
        value = descriptor["digest"]
        require(bool(re.fullmatch(r"sha256:[a-f0-9]{64}", value)), "Invalid digest")
        path = layout / "blobs" / "sha256" / value.split(":")[1]
        require(path.stat().st_size == descriptor["size"], "Descriptor size mismatch")
        return json.loads(path.read_text())

    index = json.loads((layout / "index.json").read_text())
    require(len(index["manifests"]) == 1, "Expected one subject")
    subject_descriptor = index["manifests"][0]
    subject = blob(subject_descriptor)
    metadata = json.loads((ROOT / f"{name}-build-metadata.json").read_text())
    require(
        subject_descriptor["digest"] == metadata["containerimage.digest"],
        "Build subject mismatch",
    )
    manifests = [
        item
        for item in subject["manifests"]
        if item.get("platform") == {"architecture": "amd64", "os": "linux"}
    ]
    require(len(manifests) == 1, "Expected one linux/amd64 image")
    manifest_descriptor = manifests[0]
    manifest = blob(manifest_descriptor)
    config = blob(manifest["config"])
    require(
        config["architecture"] == "amd64" and config["os"] == "linux",
        "Config platform mismatch",
    )
    require(
        config["config"]["Labels"]["org.opencontainers.image.revision"] == REVISION,
        "Source label mismatch",
    )
    for item in subject["manifests"]:
        child = blob(item)
        blob(child["config"])
        for layer in child["layers"]:
            require(
                bool(re.fullmatch(r"sha256:[a-f0-9]{64}", layer["digest"])),
                "Invalid layer digest",
            )
            path = "blobs/sha256/" + layer["digest"].split(":")[1]
            require(
                path in inventory and inventory[path]["bytes"] == layer["size"],
                "Missing or truncated layer",
            )
    result = {
        "component": "image-" + name,
        "source_commit": REVISION,
        "archive_sha256": sha256(archive),
        "archive_bytes": archive.stat().st_size,
        "subject_digest": subject_descriptor["digest"],
        "platform_manifest_digest": manifest_descriptor["digest"],
        "config_digest": manifest["config"]["digest"],
        "platform": "linux/amd64",
        "runtime_config": config["config"],
        "build_metadata_sha256": sha256(ROOT / f"{name}-build-metadata.json"),
        "verified_archive_members": inventory,
    }
    (ROOT / f"{name}-identity.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "component",
                    "subject_digest",
                    "platform_manifest_digest",
                    "config_digest",
                )
            }
        )
    )


if __name__ == "__main__":
    main(sys.argv[1])
