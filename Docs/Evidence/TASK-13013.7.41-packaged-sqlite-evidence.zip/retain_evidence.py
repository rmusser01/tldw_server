"""Retain task-owned packaging evidence, excluding multi-gigabyte image payloads."""

from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).parent
REPO = Path(sys.argv[1])
DEST = REPO / "Docs/Evidence"
STEM = "TASK-13013.7.41-packaged-sqlite"


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> None:
    for review in ("probe-review.md", "final-review.md"):
        if not (ROOT / review).is_file():
            raise ValueError("Missing required review: " + review)
    verification = json.loads((ROOT / "candidate-verification.json").read_text())
    if [item["name"] for item in verification] != ["app", "worker", "audio-worker"]:
        raise ValueError("Candidate verification incomplete")
    files = {}
    allowed = {".py", ".sh", ".json", ".txt", ".log", ".md", ".stderr", ".sha256"}
    for path in ROOT.iterdir():
        if path.is_file() and path.suffix in allowed:
            files[path.name] = path
    for path in sorted((ROOT / "scan-output").glob("*.json")):
        files["scan-output/" + path.name] = path
    if len([name for name in files if name.startswith("scan-output/")]) != 6:
        raise ValueError("Expected six full scanner reports")
    files["scanner/db/metadata.json"] = ROOT / "scanner/db/metadata.json"
    for name in ("app", "worker", "audio-worker"):
        layout = ROOT / (name + "-layout")
        inventory = {layout / "index.json", layout / "oci-layout"}
        index = json.loads((layout / "index.json").read_text())
        subject_path = (
            layout / "blobs/sha256" / index["manifests"][0]["digest"].split(":")[1]
        )
        inventory.add(subject_path)
        subject = json.loads(subject_path.read_text())
        for entry in subject["manifests"]:
            path = layout / "blobs/sha256" / entry["digest"].split(":")[1]
            inventory.add(path)
            manifest = json.loads(path.read_text())
            inventory.add(
                layout / "blobs/sha256" / manifest["config"]["digest"].split(":")[1]
            )
            if (
                entry.get("annotations", {}).get("vnd.docker.reference.type")
                == "attestation-manifest"
            ):
                for layer in manifest["layers"]:
                    inventory.add(
                        layout / "blobs/sha256" / layer["digest"].split(":")[1]
                    )
        for path in inventory:
            files[f"oci/{name}/" + str(path.relative_to(layout))] = path
    records = {
        name: {"sha256": sha256(path), "bytes": path.stat().st_size}
        for name, path in sorted(files.items())
    }
    archive = DEST / (STEM + "-evidence.zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, path in sorted(files.items()):
            output.write(path, name)
    with zipfile.ZipFile(archive) as saved:
        if saved.testzip() is not None:
            raise ValueError("Archive CRC failed")
        for name, record in records.items():
            data = saved.read(name)
            if (
                len(data) != record["bytes"]
                or hashlib.sha256(data).hexdigest() != record["sha256"]
            ):
                raise ValueError("Archive binding failed: " + name)
    companion = {
        "task": "TASK-13013.7.41",
        "source_commit": "08d232ef8cad33fbc2b27b6daa6006a6d3cd426a",
        "scope": "Local packaging verification only; no source overlay, model qualification, publication or whole-release admission.",
        "archive": {
            "path": str(archive.relative_to(REPO)),
            "sha256": sha256(archive),
            "bytes": archive.stat().st_size,
            "members": records,
        },
        "candidates": verification,
        "source_bindings": json.loads((ROOT / "source-bindings.json").read_text()),
        "review": "probe-review.md and final-review.md within the archive",
        "verification": {
            "focused_tests": 242,
            "focused_test_warnings": 0,
            "synthetic_oci_controls": 3,
            "sqlite_probe_cases": sum(item["probe_cases"] for item in verification),
        },
        "limits": "The six SQLite rows retain the privileged raw-restore boundary; packaged importer correction does not patch SQLite. Existing FFmpeg and XML6653 limits remain. No new vulnerability exclusion is added.",
    }
    (DEST / (STEM + ".json")).write_text(json.dumps(companion, indent=2) + "\n")
    print(
        json.dumps(
            {
                "archive_sha256": companion["archive"]["sha256"],
                "archive_bytes": archive.stat().st_size,
                "members": len(records),
            }
        )
    )


if __name__ == "__main__":
    main()
