#!/bin/sh
# Scan immutable local OCI content with the pinned scanner and retained current DB.
set -eu
case "$1" in app|worker|audio-worker) ;; *) exit 2 ;; esac
candidate_name=$1
candidate_subject=$2
artifact_dir=/private/tmp/task-13013-7-41-images
mkdir -p "$artifact_dir/trivy-$candidate_name-tmp"
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/$candidate_name-scan-started.txt"
for scan_format in json cyclonedx; do
  case "$scan_format" in
    json) report_file="trivy-image-$candidate_name.json" ;;
    cyclonedx) report_file="sbom-image-$candidate_name.cdx.json" ;;
  esac
  docker run --rm --pull never --name "tldw-task13013-7-41-$candidate_name-$scan_format" --platform linux/amd64 --user 501:20 --network none --cap-drop ALL --security-opt no-new-privileges:true --read-only --cpus 4 --memory 4g --pids-limit 128 --volume "$artifact_dir/trivy-$candidate_name-tmp:/tmp:rw" --volume "$artifact_dir/scan-output:/work:rw" --volume "$artifact_dir/scanner:/trivy-cache:rw" --volume "$artifact_dir/$candidate_name-layout:/input:ro" --workdir /work ghcr.io/aquasecurity/trivy:0.74.0@sha256:62b1e65e8869bc4b4c6aa4fa2b21595256c7c2f6018a9d9ad61caf87187c1969 image --timeout 20m --platform linux/amd64 --cache-dir /trivy-cache --skip-db-update --scanners vuln --ignore-unfixed=false --format "$scan_format" --output "$report_file" --input "/input@$candidate_subject" > "$artifact_dir/$candidate_name-$scan_format-scan.log" 2>&1
done
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/$candidate_name-scan-finished.txt"
