# TASK-13013.7.41: packaged SQLite correction

Continue the approved release remediation by building the existing backend recipes
from committed source 08d232ef8cad33fbc2b27b6daa6006a6d3cd426a. Preserve the
policy, dependencies, production recipes and unrelated handoff. Reuse TASK40's
benign SQLite checks on actual installed files. No model or application startup,
restricted NLTK/FFmpeg qualification, publication or merge is included.

## Stage 1: Build immutable local candidates
**Goal**: Package the committed correction in all three backend images.
**Success Criteria**: Clean source archive; three successful unchanged recipe builds; OCI identity and source revision verified.
**Tests**: Archive and OCI blob hashes; build exit status and configuration labels.
**Status**: Complete

## Stage 2: Verify installed correction
**Goal**: Establish behavior of each candidate's own packaged importer.
**Success Criteria**: Exact source hashes; tiny ordinary/STRICT/WITHOUT ROWID, single/nested view, hydration and APKG checks pass without a source overlay or model imports.
**Tests**: Reuse the reviewed TASK40 ten-case diagnostic with offline, read-only, unprivileged execution; include app source-tree copy separately.
**Status**: Complete

## Stage 3: Retain scan and verification evidence
**Goal**: Bind complete scanner reports and existing policy decisions to each candidate.
**Success Criteria**: Pinned scanner and current database; complete JSON/CDX reports; exact image/report linkage; policy unchanged; evidence review and local commit complete.
**Tests**: Existing identity/policy validators; explicit focused tests only; scope-appropriate lint/Bandit and archive integrity.
**Status**: Complete
