from pathlib import Path
from datetime import datetime, timezone, timedelta
import subprocess, json, hashlib
root=Path(__file__).parent
image_trivy="ghcr.io/aquasecurity/trivy:0.74.0@sha256:62b1e65e8869bc4b4c6aa4fa2b21595256c7c2f6018a9d9ad61caf87187c1969"
image_cdx="docker.io/cyclonedx/cyclonedx-cli:0.33.1@sha256:252c2e26f468c25fea1e63ecde1bc3198ad6e9dbb57f5ed3236bddcb2281b3a7"
commands=[]
def run(name,args):
    with (root/name).open("w") as log:
        result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    commands.append({"log":name,"argv":args,"exit_code":result.returncode})
    (root/"commands.json").write_text(json.dumps(commands,indent=2)+"\n")
    assert result.returncode==0,(name,result.returncode)
    print(name+": passed",flush=True)
common=["docker","run","--rm","--platform","linux/amd64","--network","none","--cap-drop","ALL","--security-opt","no-new-privileges:true","--read-only","--tmpfs","/tmp:rw,nosuid,nodev,size=512m","--volume",str(root/"evidence")+":/work:rw","--workdir","/work"]
cdx=common+[image_cdx]
run("cyclonedx-version.log",cdx+["--version"])
assert (root/"cyclonedx-version.log").read_text().strip().startswith("0.33.1")
for component in ("python-root","apps-workspace","admin-ui"):
    run("validate-"+component+".log",cdx+["validate","--input-file","sbom-"+component+".cdx.json"])
run("merge.log",cdx+["merge","--input-files","sbom-python-root.cdx.json","sbom-apps-workspace.cdx.json","sbom-admin-ui.cdx.json","--output-file","sbom-source-aggregate.cdx.json"])
run("validate-aggregate.log",cdx+["validate","--input-file","sbom-source-aggregate.cdx.json"])
trivy=common+["--volume",str(root/"trivy-cache")+":/trivy-cache:rw",image_trivy]
run("trivy-version.log",trivy+["--version"])
assert "Version: 0.74.0" in (root/"trivy-version.log").read_text()
def dbcheck():
    meta=json.loads((root/"trivy-cache/db/metadata.json").read_text())
    assert meta["Version"]==2
    now=datetime.now(timezone.utc)
    age=now-datetime.fromisoformat(meta["UpdatedAt"].replace("Z","+00:00"))
    assert timedelta(minutes=-5)<=age<=timedelta(hours=24),age
    with (root/"trivy-cache/db/trivy.db").open("rb") as f: digest=hashlib.file_digest(f,"sha256").hexdigest()
    return {"checked_at":now.isoformat(),"age_seconds":age.total_seconds(),"metadata":meta,"sha256":digest}
before=dbcheck()
for component in ("python-root","apps-workspace","admin-ui"):
    run("scan-"+component+".log",trivy+["sbom","--cache-dir","/trivy-cache","--skip-db-update","--scanners","vuln","--ignore-unfixed=false","--format","json","--output","/work/trivy-source-"+component+".json","/work/sbom-"+component+".cdx.json"])
after=dbcheck()
assert before["sha256"]==after["sha256"]
(root/"database-check.json").write_text(json.dumps({"before":before,"after":after},indent=2)+"\n")
