# TASK-13013.7.44 — bounded source-admission review

Reviewed source baseline `65eab8b46442ea158f72630364db628a6f0e09cf`, retained/current source inputs, and the final working-tree optional-dependency scope correction.

**No unresolved actionable findings. Ready for local commit after evidence/task finalization.**

- Input binding: all 20 baseline input hashes match the recorded revision. The unchanged producer workflow/CDXGEN pin and options, both Bun locks, root manifests, and all four declared workspace manifests support reusing the two exact verified Bun SBOMs. The declared workspace expansion matches the inventory, and none of the eight tracked JS manifest/lock paths changed. Reused files match their retained origin hashes.
- Python export: fresh and retained exports each contain 293 components; their full component records, identities, dependency arrays, root metadata component, and tool metadata are identical. The fresh file matches its recorded hash. The initially stale Python origin label was corrected and verified; the retained file is now identified separately as the comparison source.
- Policy correction: independently compared all 342 records against the baseline. Exactly the six intended records change only `component`, from `source-python-root` to `dependency-review-python-root`. The other 336 records, including all 16 Chroma records, are unchanged. Approvals, identities, dates, rationale, and mitigation remain intact in all six moved records.
- Matching remains strict: the adapter accepts the two Python scopes but still requires exactly one matching approval across them and preserves manifest/ecosystem/package/version/severity/date and all-occurrence checks. Required-source and image matching remain component-exact, and unmatched required-source approvals still reject admission. Historical snapshot tests reconstruct only the intended component values; the new full-policy preservation test constrains those adjustments.
- Recorded results: all 15 finding identities are unchanged from the retained scan (6 Python, 8 apps, 1 Admin). The five excepted High/Critical findings are identical before/after. The correction changes Python unmatched approvals from six to zero; all three final decisions have zero blocking findings and zero unmatched approvals. Four schema validations succeeded. Retained regression logs show 9 expected pre-fix failures and 809 passing final checks. `git diff --check` passes.
- The 695-change dependency-review replay retains the same 11 allowances and is explicitly historical, not a current remote comparison. Local source admission does not establish fresh image or release admission.

Reviewed corrected SHA-256 values:

- Policy: `835c71df894b511380083ad18117217479ac98491b04695ad7fa47164c3288aa`
- Evaluator: `f597774f9bd75cf37ef8f9ac7d9887f478284002236d5085c36c39b29febb145`
- Dependency-review adapter: `1bb17bb60b2a9d6831306d82e34c2dd1a35bd888e5694fd1129c0ff6498366b8`

The original policy hash in the baseline input record intentionally describes the pre-correction revision, not the final policy. Final evidence must retain that distinction. This review used file comparisons, static code review, and retained logs; no package, application, model, native, security, container, or network workload was executed and no repository file was edited.
