import json
from collections import Counter
from dataclasses import asdict
from datetime import date
from pathlib import Path

from Helper_Scripts.Supply_Chain.exception_policy import (
    evaluate_trivy_report,
    load_policy,
)

evidence = Path("evidence")
policy = load_policy(
    Path(".github/supply-chain/vulnerability-exceptions.json"),
    today=date.today(),
)
failed_components = []
for component in ("python-root", "apps-workspace", "admin-ui"):
    report_path = evidence / f"trivy-source-{component}.json"
    report = json.loads(report_path.read_text(encoding="utf-8"))
    decision = evaluate_trivy_report(
        report,
        component=f"source-{component}",
        policy=policy,
        today=date.today(),
    )
    severity_counts = Counter()
    for result in report.get("Results", []):
        for finding in result.get("Vulnerabilities") or []:
            severity_counts[str(finding.get("Severity", "UNKNOWN"))] += 1
    payload = {
        "component": decision.component,
        "raw_severity_counts": dict(sorted(severity_counts.items())),
        "blocking": [asdict(item) for item in decision.blocking],
        "excepted": [asdict(item) for item in decision.excepted],
        "unmatched_exception_ids": list(decision.unmatched_exception_ids),
    }
    output = evidence / f"scan-decision-source-{component}.json"
    output.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    if decision.blocking or decision.unmatched_exception_ids:
        failed_components.append(f"source-{component}")
if failed_components:
    raise SystemExit(
        "vulnerability policy failed: " + ", ".join(failed_components)
    )
